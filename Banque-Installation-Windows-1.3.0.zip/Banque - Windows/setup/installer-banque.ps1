﻿# ─────────────────────────────────────────────────────────────
#  Installe Banque sous Windows 10 / 11 (logiciel à part, hors de la suite Lanterne Spectacle).
#  1. moteur Electron : celui d'un logiciel Lanterne déjà installé, sinon téléchargé depuis GitHub (44.7.0) et vérifié
#  2. assemble « Banque.exe » dans %LOCALAPPDATA%\Programs\Banque
#  3. raccourcis Bureau et menu Démarrer, désinstallation dans Paramètres › Applications
#  Aucun droit administrateur n'est demandé. -Quiet : sans fenêtre.  -Uninstall : désinstaller.
# ─────────────────────────────────────────────────────────────
param([switch]$Quiet, [switch]$Uninstall, [switch]$Force)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$Version = '1.3.0'
$ElectronFixe = '44.7.0'
$Name = 'Banque'
$OnWindows = [Environment]::OSVersion.Platform -eq 'Win32NT'
if (-not $OnWindows) { $Quiet = $true }
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Programs = Join-Path $env:LOCALAPPDATA 'Programs'
$Dest = Join-Path $Programs $Name
$Suite = Join-Path $Programs 'Lanterne Spectacle'
$LogDir = Join-Path $env:LOCALAPPDATA 'Banque'
$Log = Join-Path $LogDir 'installation-banque.log'
$Work = Join-Path ([IO.Path]::GetTempPath()) ('lanterne-tb-' + [Guid]::NewGuid().ToString('N').Substring(0, 8))
$Arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'x64' }

if ($OnWindows) { Add-Type -AssemblyName System.Windows.Forms }
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
if ($OnWindows) { try { Get-ChildItem -LiteralPath $Here -Recurse -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue } catch {} }
"--- $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $Name $Version" | Out-File -FilePath $Log -Encoding utf8 -Append
function Say([string]$t) { Write-Host ''; Write-Host "> $t" -ForegroundColor Yellow; "> $t" | Out-File $Log -Encoding utf8 -Append }
function Ok([string]$t)  { Write-Host "  OK  $t" -ForegroundColor Green; "  OK $t" | Out-File $Log -Encoding utf8 -Append }
function Ask([string]$text, [string]$buttons = 'OKCancel', [string]$icon = 'Information') {
  if ($Quiet) { return 'OK' }
  return [string][System.Windows.Forms.MessageBox]::Show($text, $Name, $buttons, $icon)
}
function Fail([string]$t) {
  "ERREUR : $t" | Out-File $Log -Encoding utf8 -Append
  Write-Host ''; Write-Host "ERREUR : $t" -ForegroundColor Red
  [void](Ask "L'installation s'est arrêtée.`n`n$t`n`nLe journal est ici :`n$Log" 'OK' 'Error')
  if (Test-Path $Work) { Remove-Item -Recurse -Force $Work -ErrorAction SilentlyContinue }
  exit 1
}
$Lnks = @()
if ($OnWindows) {
  $Lnks = @((Join-Path ([Environment]::GetFolderPath('Desktop')) "$Name.lnk"), (Join-Path ([Environment]::GetFolderPath('Programs')) "$Name.lnk"))
}
$UninstKey = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\Banque'

# ── désinstallation ──
if ($Uninstall) {
  if ((Ask "Désinstaller $Name ?`n`nTa banque (le dossier de fichiers) n'est pas touchée." 'OKCancel' 'Question') -ne 'OK') { exit 0 }
  Get-Process -Name $Name -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
  Start-Sleep -Milliseconds 500
  if (Test-Path $Dest) { Remove-Item -Recurse -Force $Dest -ErrorAction SilentlyContinue }
  foreach ($l in $Lnks) { if (Test-Path $l) { Remove-Item -Force $l -ErrorAction SilentlyContinue } }
  if ($OnWindows) { Remove-Item -Path $UninstKey -Recurse -Force -ErrorAction SilentlyContinue }
  [void](Ask "$Name est désinstallé." 'OK' 'Information')
  exit 0
}

if ((Ask "Installer $Name $Version ?`n`nÉchange de fichiers entre les ordinateurs du réseau local : une banque principale où chacun prend des fichiers, et l'envoi direct d'un ordinateur à l'autre.`n`nInternet est nécessaire si aucun logiciel Lanterne n'est encore installé sur ce PC.") -ne 'OK') { exit 0 }
Get-Process -Name $Name -ErrorAction SilentlyContinue | ForEach-Object { try { $_.CloseMainWindow() | Out-Null } catch {} }
Start-Sleep -Seconds 1
Get-Process -Name $Name -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue

New-Item -ItemType Directory -Force -Path $Work | Out-Null
$Engine = Join-Path $Work 'engine'

# ── 1. moteur Electron : celui d'un logiciel Lanterne déjà installé, sinon téléchargé ──
$found = $null
if (-not $Force) {
  $cands = @(@{ Dir = $Dest; Exe = $Name }, @{ Dir = (Join-Path $Programs 'Lanterne Tableau de bord'); Exe = 'Lanterne Tableau de bord' })
  foreach ($n in @('Lanterne Launcher', 'Lanterne Player', 'Lanterne FDR', 'Lanterne Timer', 'Lanterne Son', 'Lanterne Prompteur', 'Lanterne VP', 'Lanterne Titrage', 'Lanterne Infodécor', 'Lanterne PPT', 'Lanterne Rec et Stream', 'Lanterne Cam', 'Lanterne Mélangeur')) { $cands += @{ Dir = (Join-Path $Suite $n); Exe = $n } }
  foreach ($c in $cands) {
    if (-not $found -and (Test-Path (Join-Path $c.Dir "$($c.Exe).exe")) -and (Test-Path (Join-Path $c.Dir 'resources'))) { $found = $c }
  }
}
if ($env:LS_ENGINE_DIR) { $found = @{ Dir = $env:LS_ENGINE_DIR; Exe = 'electron' } }   # essais : moteur fourni
if ($found) {
  Say "Moteur déjà présent ($($found.Dir)) : installation rapide, sans téléchargement…"
  Copy-Item -Recurse -Path $found.Dir -Destination $Engine
  Remove-Item -Recurse -Force (Join-Path $Engine 'resources\app') -ErrorAction SilentlyContinue
  Get-ChildItem $Engine -Filter '*.ico' | Remove-Item -Force -ErrorAction SilentlyContinue
  Get-ChildItem $Engine -Filter '*.ps1' | Remove-Item -Force -ErrorAction SilentlyContinue
  if ($found.Exe -ne 'electron') { Rename-Item (Join-Path $Engine "$($found.Exe).exe") 'electron.exe' }
  Ok 'Moteur réutilisé'
} else {
  [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
  $V = if ($env:ELECTRON_VERSION) { $env:ELECTRON_VERSION } else { $ElectronFixe }
  $Zip = "electron-v$V-win32-$Arch.zip"
  $Url = "https://github.com/electron/electron/releases/download/v$V"
  Say "Téléchargement du moteur Electron $V ($Arch, environ 120 Mo)…"
  $curl = if ($OnWindows) { Join-Path $env:SystemRoot 'System32\curl.exe' } else { 'curl' }
  $sums = Join-Path $Work 'SHASUMS256.txt'; $zipPath = Join-Path $Work $Zip
  if (-not $OnWindows -or (Test-Path $curl)) {
    & $curl -fsSL -o $sums "$Url/SHASUMS256.txt"; if ($LASTEXITCODE) { Fail "Impossible de joindre GitHub. Vérifie la connexion Internet et relance." }
    & $curl -fL --progress-bar -o $zipPath "$Url/$Zip"; if ($LASTEXITCODE) { Fail "Le téléchargement d'Electron a échoué. Vérifie la connexion Internet et relance." }
  } else {
    $wc = New-Object Net.WebClient
    $wc.DownloadFile("$Url/SHASUMS256.txt", $sums)
    $wc.DownloadFile("$Url/$Zip", $zipPath)
  }
  $expected = (Get-Content $sums | Where-Object { $_ -match ('[ *]' + [Regex]::Escape($Zip) + '$') } | Select-Object -First 1) -split '\s+' | Select-Object -First 1
  $actual = (Get-FileHash -Algorithm SHA256 $zipPath).Hash.ToLower()
  if (-not $expected -or $expected.ToLower() -ne $actual) { Fail "Le fichier téléchargé ne correspond pas à l'empreinte officielle d'Electron. Relance l'installation." }
  Ok 'Téléchargement vérifié'
  New-Item -ItemType Directory -Force -Path $Engine | Out-Null
  $done = $false
  if ($OnWindows) { $tar = Join-Path $env:SystemRoot 'System32\tar.exe'; if (Test-Path $tar) { & $tar -xf $zipPath -C $Engine; $done = ($LASTEXITCODE -eq 0) } }
  if (-not $done) { Expand-Archive -Path $zipPath -DestinationPath $Engine -Force }
  if (-not (Test-Path (Join-Path $Engine 'electron.exe'))) { Fail "Le moteur Electron est incomplet après décompression." }
  Remove-Item -Force $zipPath
  Ok 'Moteur prêt'
}

# ── 2. assemblage ──
Say "Assemblage de $Name…"
$stage = Join-Path $Work 'stage'
Copy-Item -Recurse -Path $Engine -Destination $stage
Remove-Item -Force (Join-Path $stage 'resources\default_app.asar') -ErrorAction SilentlyContinue
Copy-Item -Recurse -Path (Join-Path $Here 'banque') -Destination (Join-Path $stage 'resources\app')
$ico = "$Name.ico"
Copy-Item -Path (Join-Path $Here $ico) -Destination (Join-Path $stage $ico)
Copy-Item -Path (Join-Path $Here 'installer-banque.ps1') -Destination (Join-Path $stage 'uninstall-banque.ps1')
Rename-Item (Join-Path $stage 'electron.exe') "$Name.exe"
$exe = Join-Path $stage "$Name.exe"
$rcedit = Join-Path $Here 'rcedit-x64.exe'
if ($OnWindows -and (Test-Path $rcedit)) {
  & $rcedit $exe --set-icon (Join-Path $stage $ico) --set-version-string 'ProductName' $Name --set-version-string 'FileDescription' $Name --set-version-string 'CompanyName' 'Lanterne' --set-version-string 'OriginalFilename' "$Name.exe" --set-version-string 'InternalName' $Name --set-file-version $Version --set-product-version $Version 2>&1 | Out-File $Log -Encoding utf8 -Append
}
if (Test-Path $Dest) {
  $old = "$Dest.ancien"
  if (Test-Path $old) { Remove-Item -Recurse -Force $old }
  Rename-Item $Dest (Split-Path $old -Leaf)
  Move-Item $stage $Dest
  Remove-Item -Recurse -Force $old -ErrorAction SilentlyContinue
} else {
  New-Item -ItemType Directory -Force -Path $Programs | Out-Null
  Move-Item $stage $Dest
}
Ok "$Name $Version installé dans $Dest"

# ── 3. raccourcis et désinstallation ──
if ($OnWindows) {
  $sh = New-Object -ComObject WScript.Shell
  foreach ($l in $Lnks) {
    try {
      $s = $sh.CreateShortcut($l); $s.TargetPath = Join-Path $Dest "$Name.exe"; $s.WorkingDirectory = $Dest
      $s.IconLocation = (Join-Path $Dest $ico); $s.Description = 'Échange de fichiers sur le réseau local'; $s.Save()
    } catch { "  raccourci : $($_.Exception.Message)" | Out-File $Log -Encoding utf8 -Append }
  }
  try {
    New-Item -Path $UninstKey -Force | Out-Null
    $ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    Set-ItemProperty -Path $UninstKey -Name 'DisplayName' -Value $Name
    Set-ItemProperty -Path $UninstKey -Name 'DisplayVersion' -Value $Version
    Set-ItemProperty -Path $UninstKey -Name 'Publisher' -Value 'Lanterne'
    Set-ItemProperty -Path $UninstKey -Name 'DisplayIcon' -Value (Join-Path $Dest $ico)
    Set-ItemProperty -Path $UninstKey -Name 'InstallLocation' -Value $Dest
    Set-ItemProperty -Path $UninstKey -Name 'UninstallString' -Value "`"$ps`" -NoProfile -ExecutionPolicy Bypass -File `"$(Join-Path $Dest 'uninstall-banque.ps1')`" -Uninstall"
    Set-ItemProperty -Path $UninstKey -Name 'NoModify' -Value 1 -Type DWord
    Set-ItemProperty -Path $UninstKey -Name 'NoRepair' -Value 1 -Type DWord
  } catch { "  désinstallation : $($_.Exception.Message)" | Out-File $Log -Encoding utf8 -Append }
  Ok 'Raccourcis sur le Bureau et dans le menu Démarrer'
}
if (Test-Path $Work) { Remove-Item -Recurse -Force $Work -ErrorAction SilentlyContinue }
if (-not $Quiet) {
  if ((Ask "$Name est installé, avec un raccourci sur le Bureau.`n`nAu premier lancement, Windows demande d'autoriser Banque sur le réseau : coche « Réseaux privés » et accepte, sinon les autres ordinateurs ne le verront pas.`n`nL'ouvrir maintenant ?" 'YesNo' 'Information') -eq 'Yes') {
    Start-Process -FilePath (Join-Path $Dest "$Name.exe") -WorkingDirectory $Dest
  }
}
exit 0
