@echo off
rem Ecran Hall : desinstallation (la suite Lanterne Spectacle n est pas touchee).
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup\installer-ecranhall.ps1" -Uninstall
