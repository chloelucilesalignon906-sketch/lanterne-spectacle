@echo off
rem Ecran Hall : installation sous Windows (double-clic). Aucun droit administrateur requis.
title Installation de Ecran Hall
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup\installer-ecranhall.ps1" %*
if errorlevel 1 (
  echo.
  echo L installation ne s est pas terminee. Le journal est dans %LOCALAPPDATA%\Lanterne Spectacle\installation-ecranhall.log
  pause
)
