'use strict';
// Écran Hall 1.2.0 (vidéos : 1.3.0) — boîtiers Qeedji sous Gekkota OS (SMA300…), qui ne font pas tourner d'appli Android.
// Le diaporama y est déposé comme une « appli » Gekkota : lecteur qeedji-lecteur.html (devient app.html), diaporama.json,
// etat.json, images JPEG et manifest.xml (format RDF de Gekkota : dépôt public github.com/Qeedji/gekkota-os, SDK-G4).
//  - envoi direct : WebDAV du boîtier, dossier http://<ip>/.playout/ (PUT / PROPFIND / DELETE), identifiant de la console
//    d'administration (authentification Basic ou Digest, selon ce que demande le boîtier) ;
//  - en secours : un fichier .tar à glisser dans la console du boîtier (Configuration › App › Dépôt local), essayé le 23/11/2026.
// Écran noir et mire : seul etat.json est réécrit, le lecteur le relit toutes les 3 s (pas de rechargement).
// 1.3.0 : vidéos (MP4…) envoyées telles quelles, nommées d'après leur contenu (v<empreinte>.mp4) : une vidéo déjà sur le
// boîtier (même nom, même taille) n'est pas renvoyée ; envoi par morceaux (jamais toute la vidéo en mémoire).
// 1.4.0 : écrans Samsung Smart Signage (page web ouverte par l'écran) : même lecteur et mêmes fichiers, gardés dans un dossier de
// cet ordinateur (c.dossier) et servis par Écran Hall (main.js, port 7613).
// Tout le réseau se fait ici, dans le processus principal (règle macOS « Réseau local »).
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const DOSSIER = '/.playout/';
const IMG = /^(e[0-9a-z]+-\d{3}\.jpg|v[0-9a-f]{12}\.(mp4|m4v|mov|webm))$/;   // images et vidéos déposées par Écran Hall (les autres fichiers ne sont jamais effacés)
const VID = /\.(mp4|m4v|mov|webm)$/i;
// empreinte d'une vidéo : taille + début + fin du fichier (rapide même pour 2 Go)
function empreinte(chemin) {
  const fd = fs.openSync(chemin, 'r');
  try {
    const t = fs.fstatSync(fd).size, n = Math.min(t, 4 << 20), h = crypto.createHash('sha1').update(String(t));
    const b = Buffer.alloc(n);
    fs.readSync(fd, b, 0, n, 0); h.update(b);
    fs.readSync(fd, b, 0, n, Math.max(0, t - n)); h.update(b);
    return h.digest('hex').slice(0, 12);
  } finally { fs.closeSync(fd); }
}

/* ---------- paquet ---------- */
function xml(s) { return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' }[c])); }
function manifeste(fichiers, version, taille) {
  return `<?xml version="1.0" encoding="UTF-8"?>
<RDF xmlns="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
    <Description about="ns.innes.gekkota.manifest#metadata"
        xmlns:cms="ns.innes.custom"
        xmlns:pzpm="ns.innes.gekkota.manifest">
        <cms:app-name>Ecran Hall</cms:app-name>
        <cms:app-version>${xml(version)}</cms:app-version>
        <pzpm:publish-size>${taille}</pzpm:publish-size>
        <pzpm:publish-generator>Ecran Hall ${xml(version)}</pzpm:publish-generator>
        <pzpm:publish-date>${new Date().toISOString()}</pzpm:publish-date>
    </Description>
    <Description about="ns.innes.gekkota.manifest#cache">
        <Bag>
${fichiers.map(f => `            <li${f === 'etat.json' ? ' refresh="none"' : ''}>${xml(f)}</li>`).join('\n')}
        </Bag>
    </Description>
    <Description about="ns.innes.gekkota.manifest#launcher"
        xmlns:gktm="ns.innes.gekkota.manifest">
        <gktm:bootstrap>app.html</gktm:bootstrap>
    </Description>
</RDF>
`;
}

// diapos : [{ chemin, n, d, video, r }] ; reglages : { orientation, transition, fond, ajuste, son }
// → { id, diaporama (objet), fichiers: [{ nom, chemin | data, taille }] } ; manifest.xml en dernier
function paquet({ titre, diapos, reglages, version, etat }) {
  const id = Date.now().toString(36);
  const images = diapos.map((d, i) => ({ nom: d.video ? `v${empreinte(d.chemin)}.${path.extname(d.chemin).slice(1).toLowerCase()}` : `e${id}-${String(i + 1).padStart(3, '0')}.jpg`,
    chemin: d.chemin, n: d.n, d: d.d, video: !!d.video, r: d.r || 0 }));
  const diaporama = { type: 'ecranhall', version, id, titre: String(titre || '').slice(0, 120), orientation: reglages.orientation,
    transition: reglages.transition, fond: reglages.fond, ajuste: 'contenir', son: reglages.son === true,
    diapos: images.map(x => Object.assign({ f: x.nom, d: x.d, n: x.n }, x.video ? { v: 1, r: x.r } : {})) };
  const lecteur = fs.readFileSync(path.join(__dirname, 'qeedji-lecteur.html'));
  const vus = new Set();
  const fichiers = [
    ...images.filter(x => !vus.has(x.nom) && vus.add(x.nom)).map(x => ({ nom: x.nom, chemin: x.chemin, video: x.video })),
    { nom: 'app.html', data: lecteur },
    { nom: 'etat.json', data: Buffer.from(JSON.stringify(etat || { noir: false, mire: 0, orientation: reglages.orientation })) },
    { nom: 'diaporama.json', data: Buffer.from(JSON.stringify(diaporama, null, 1)) },
  ];
  for (const f of fichiers) f.taille = f.data ? f.data.length : fs.statSync(f.chemin).size;
  const taille = fichiers.reduce((a, f) => a + f.taille, 0);
  const man = Buffer.from(manifeste(fichiers.map(f => f.nom), version, taille));
  fichiers.push({ nom: 'manifest.xml', data: man, taille: man.length });
  return { id, diaporama, fichiers, taille };
}

/* ---------- .tar (format ustar, accepté par Gekkota) ---------- */
function enteteTar(nom, taille, mtime) {
  const h = Buffer.alloc(512, 0);
  const ecr = (s, off, len) => h.write(s, off, Math.min(len, Buffer.byteLength(s)), 'utf8');
  const oct = (n, len) => n.toString(8).padStart(len - 1, '0') + '\0';
  ecr(nom, 0, 100);
  ecr(oct(0o644, 8), 100, 8);
  ecr(oct(0, 8), 108, 8);
  ecr(oct(0, 8), 116, 8);
  ecr(oct(taille, 12), 124, 12);
  ecr(oct(mtime, 12), 136, 12);
  h.fill(' ', 148, 156);           // somme de contrôle comptée avec des espaces
  ecr('0', 156, 1);
  ecr('ustar\0', 257, 6);
  ecr('00', 263, 2);
  ecr('root', 265, 32); ecr('root', 297, 32);
  let somme = 0; for (const b of h) somme += b;
  ecr(somme.toString(8).padStart(6, '0') + '\0 ', 148, 8);
  return h;
}
function ecrireTar(p) {
  const mtime = Math.floor(Date.now() / 1000);
  const morceaux = [];
  for (const f of p.fichiers) {
    const data = f.data || fs.readFileSync(f.chemin);
    morceaux.push(enteteTar(f.nom, data.length, mtime), data);
    const reste = (512 - (data.length % 512)) % 512;
    if (reste) morceaux.push(Buffer.alloc(reste, 0));
  }
  morceaux.push(Buffer.alloc(1024, 0));
  return Buffer.concat(morceaux);
}
// 1.3.0 : .tar écrit par morceaux dans un fichier (vidéos lourdes), puis renommé d'un coup
async function ecrireTarFichier(p, dest) {
  const mtime = Math.floor(Date.now() / 1000), tmp = dest + '.tmp';
  const out = fs.createWriteStream(tmp);
  const ecr = b => new Promise((ok, ko) => { out.write(b, err => (err ? ko(err) : ok())); });
  try {
    for (const f of p.fichiers) {
      const taille = f.data ? f.data.length : fs.statSync(f.chemin).size;
      await ecr(enteteTar(f.nom, taille, mtime));
      if (f.data) await ecr(f.data);
      else for await (const b of fs.createReadStream(f.chemin, { highWaterMark: 1 << 20 })) await ecr(b);
      const reste = (512 - (taille % 512)) % 512;
      if (reste) await ecr(Buffer.alloc(reste, 0));
    }
    await ecr(Buffer.alloc(1024, 0));
    await new Promise((ok, ko) => { out.on('error', ko); out.end(ok); });
    await fs.promises.rename(tmp, dest);
  } catch (e) { out.destroy(); await fs.promises.rm(tmp, { force: true }); throw e; }
}

/* ---------- WebDAV du boîtier ---------- */
const md5 = s => crypto.createHash('md5').update(s).digest('hex');
const sha256 = s => crypto.createHash('sha256').update(s).digest('hex');
function lireDefi(h) {
  if (!h) return null;
  const l = Array.isArray(h) ? h : [h];
  const dig = l.find(x => /^\s*digest/i.test(x)), bas = l.find(x => /^\s*basic/i.test(x));
  if (dig) {
    const o = { schema: 'digest' };
    dig.replace(/^\s*digest\s+/i, '').replace(/(\w+)\s*=\s*(?:"([^"]*)"|([^,\s]*))/g, (_m, k, a, b) => { o[k.toLowerCase()] = a != null ? a : b; return ''; });
    o.nc = 0;
    return o;
  }
  return bas ? { schema: 'basic' } : null;
}
function autorisation(c, methode, uri) {
  const d = c.defi;
  if (!d || !c.user) return null;
  if (d.schema === 'basic') return 'Basic ' + Buffer.from(`${c.user}:${c.mdp}`).toString('base64');
  const algo = String(d.algorithm || 'MD5').toUpperCase();
  const H = algo.startsWith('SHA-256') ? sha256 : md5;
  let ha1 = H(`${c.user}:${d.realm}:${c.mdp}`);
  const cnonce = crypto.randomBytes(8).toString('hex');
  if (algo.endsWith('-SESS')) ha1 = H(`${ha1}:${d.nonce}:${cnonce}`);
  const ha2 = H(`${methode}:${uri}`);
  const qop = d.qop ? (d.qop.split(',').map(x => x.trim()).includes('auth') ? 'auth' : d.qop.split(',')[0].trim()) : '';
  d.nc++;
  const nc = d.nc.toString(16).padStart(8, '0');
  const rep = qop ? H(`${ha1}:${d.nonce}:${nc}:${cnonce}:${qop}:${ha2}`) : H(`${ha1}:${d.nonce}:${ha2}`);
  let s = `Digest username="${c.user}", realm="${d.realm}", nonce="${d.nonce}", uri="${uri}", response="${rep}"`;
  if (d.algorithm) s += `, algorithm=${d.algorithm}`;
  if (d.opaque != null) s += `, opaque="${d.opaque}"`;
  if (qop) s += `, qop=${qop}, nc=${nc}, cnonce="${cnonce}"`;
  return s;
}
// 1.4.0 : écrans Samsung (page ouverte par l'écran) : le même dossier, mais sur cet ordinateur ({ dossier }), servi par
// Écran Hall sur le port 7613. Mêmes opérations que le WebDAV du boîtier ; une vidéo est liée (pas recopiée) quand c'est possible.
async function requeteLocale(c, methode, nom, corps) {
  const rep = (status, b) => ({ status, headers: {}, corps: b || Buffer.alloc(0) });
  if (nom && !/^[\w.-]+$/.test(nom)) return rep(400);
  const p = path.join(c.dossier, nom);
  if (methode === 'GET') { try { return rep(200, await fs.promises.readFile(p)); } catch (e) { return rep(404); } }
  if (methode === 'DELETE') { await fs.promises.rm(p, { force: true }); return rep(204); }
  if (methode === 'PROPFIND') {
    const l = await fs.promises.readdir(c.dossier).catch(() => []);
    let x = '<?xml version="1.0"?><D:multistatus xmlns:D="DAV:">';
    for (const n of l) { const st = await fs.promises.stat(path.join(c.dossier, n)).catch(() => null); if (st && st.isFile()) x += `<D:response><D:href>${DOSSIER}${encodeURIComponent(n)}</D:href><D:propstat><D:prop><D:getcontentlength>${st.size}</D:getcontentlength></D:prop></D:propstat></D:response>`; }
    return rep(207, Buffer.from(x + '</D:multistatus>'));
  }
  if (methode !== 'PUT') return rep(405);
  await fs.promises.mkdir(c.dossier, { recursive: true });
  const tmp = p + '.tmp';
  await fs.promises.rm(tmp, { force: true });
  if (corps && corps.chemin) {
    try { await fs.promises.link(corps.chemin, tmp); }
    catch (e) { await fs.promises.copyFile(corps.chemin, tmp, fs.constants.COPYFILE_FICLONE); }
    if (corps.progres) corps.progres(corps.taille);
  } else await fs.promises.writeFile(tmp, corps || Buffer.alloc(0));
  await fs.promises.rename(tmp, p);
  return rep(201);
}
// une requête vers le boîtier ; 401 → on lit le défi et on réessaie une fois avec l'identifiant
function requete(c, methode, nom, corps, entetes, ms = 20000) {
  if (c.dossier) return requeteLocale(c, methode, nom, corps);
  const uri = DOSSIER + nom.split('/').map(encodeURIComponent).join('/');
  const une = () => new Promise((ok, ko) => {
    const h = Object.assign({}, entetes || {});
    const a = autorisation(c, methode, uri); if (a) h.Authorization = a;
    const flux = corps && corps.chemin;   // 1.3.0 : fichier envoyé par morceaux { chemin, taille, progres }
    if (corps != null) h['Content-Length'] = flux ? corps.taille : corps.length;
    const r = http.request({ host: c.ip, port: c.port || 80, method: methode, path: uri, headers: h, agent: false }, res => {
      const l = []; res.on('data', b => l.push(b)); res.on('end', () => ok({ status: res.statusCode, headers: res.headers, corps: Buffer.concat(l) }));
      res.on('error', ko);
    });
    r.setTimeout(ms, () => r.destroy(new Error(`le boîtier ne répond pas (${c.ip})`)));
    r.on('error', e => ko(e.code === 'ECONNREFUSED' || e.code === 'EHOSTUNREACH' || e.code === 'ENETUNREACH' ? new Error(`boîtier injoignable (${c.ip})`) : e));
    if (flux) {
      const lu = fs.createReadStream(corps.chemin, { highWaterMark: 1 << 20 });
      lu.on('data', b => { if (corps.progres) corps.progres(b.length); });
      lu.on('error', e => r.destroy(e));
      lu.pipe(r);
    } else if (corps != null) r.end(corps); else r.end();
  });
  return une().then(async r => {
    if (r.status !== 401) return r;
    const d = lireDefi(r.headers['www-authenticate']);
    if (!d || !c.user) return r;
    const relance = !c.defi || (d.schema === 'digest' && (!c.defi.nonce || /true/i.test(d.stale || '') || c.defi.nonce !== d.nonce));
    c.defi = d;
    return relance || c.defi.schema === 'basic' ? une() : r;
  });
}
function erreurHttp(r, quoi) {
  if (r.status === 401) { const e = new Error('identifiant ou mot de passe refusé par le boîtier'); e.code = 'mdp'; return e; }
  if (r.status === 403 || r.status === 405) return new Error(`${quoi} refusé par le boîtier (${r.status}). Dans sa console (Configuration › App), choisis « Push Webdav », ou utilise le fichier .tar.`);
  if (r.status === 507) return new Error('plus de place sur le boîtier');
  return new Error(`${quoi} : erreur ${r.status} du boîtier`);
}
async function lireJson(c, nom) {
  const r = await requete(c, 'GET', nom, null, { 'Cache-Control': 'no-cache' }, 5000);
  if (r.status === 404) return null;
  if (r.status !== 200) throw erreurHttp(r, `lecture de ${nom}`);
  try { return JSON.parse(r.corps.toString('utf8')); } catch (e) { return null; }
}
async function poser(c, nom, data, type) {
  const r = await requete(c, 'PUT', nom, data, { 'Content-Type': type || 'application/octet-stream' }, data && data.chemin ? 300000 : 120000);
  if (![200, 201, 204].includes(r.status)) throw erreurHttp(r, `dépôt de ${nom}`);
}
// fichiers du dossier : Map nom → taille (null si le boîtier ne répond pas à PROPFIND)
async function liste(c) {
  const corps = Buffer.from('<?xml version="1.0" encoding="utf-8"?><propfind xmlns="DAV:"><prop><getcontentlength/></prop></propfind>');
  const r = await requete(c, 'PROPFIND', '', corps, { Depth: '1', 'Content-Type': 'application/xml; charset=utf-8' }, 10000);
  if (r.status !== 207) return null;
  const noms = new Map();
  for (const bloc of r.corps.toString('utf8').split(/<\/(?:\w+:)?response>/i)) {
    const h = /<(?:\w+:)?href>([^<]*)<\/(?:\w+:)?href>/i.exec(bloc); if (!h) continue;
    let p = h[1].replace(/^https?:\/\/[^/]+/i, ''); try { p = decodeURIComponent(p); } catch (e) {}
    const n = p.replace(/\/+$/, '').split('/').pop();
    if (!n || p.replace(/\/+$/, '') === DOSSIER.replace(/\/+$/, '')) continue;
    const t = /<(?:\w+:)?getcontentlength>\s*(\d+)\s*</i.exec(bloc);
    noms.set(n, t ? +t[1] : -1);
  }
  return noms;
}
const TYPES = { jpg: 'image/jpeg', html: 'text/html; charset=utf-8', json: 'application/json; charset=utf-8', xml: 'application/xml; charset=utf-8',
  mp4: 'video/mp4', m4v: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm' };

// état d'un boîtier : { enLigne, titre, n, noir, ecranHall } ; erreur 'mdp' si l'identifiant est refusé
async function etat(c) {
  const dia = await lireJson(c, 'diaporama.json');
  const et = dia ? await lireJson(c, 'etat.json').catch(() => null) : null;
  return { enLigne: true, ecranHall: !!(dia && dia.type === 'ecranhall'), titre: dia && dia.titre || '', n: dia && dia.diapos ? dia.diapos.length : 0, noir: !!(et && et.noir) };
}

// envoi complet : nouvelles images et vidéos, lecteur, état, diaporama, manifeste ; puis effacement des anciennes images Écran Hall
async function envoyer(c, p, progres) {
  const deja = await liste(c).catch(() => null);
  const nImg = p.fichiers.filter(x => IMG.test(x.nom)).length;
  let fait = 0, k = 0;
  for (const f of p.fichiers) {
    const quoi = VID.test(f.nom) ? `Vidéo ${++k} / ${nImg}` : IMG.test(f.nom) ? `Image ${++k} / ${nImg}` : f.nom;
    if (f.video && deja && deja.get(f.nom) === f.taille) { fait += f.taille; progres(fait / p.taille, `${quoi} déjà sur le boîtier`); continue; }
    if (f.data || !f.video) {
      const data = f.data || await fs.promises.readFile(f.chemin);
      await poser(c, f.nom, data, TYPES[f.nom.split('.').pop().toLowerCase()]);
      fait += data.length;
    } else {
      const debut = fait;
      await poser(c, f.nom, { chemin: f.chemin, taille: f.taille, progres: n => { fait += n; progres(fait / p.taille, quoi); } }, TYPES[f.nom.split('.').pop().toLowerCase()]);
      fait = debut + f.taille;
    }
    progres(fait / p.taille, quoi);
  }
  const garder = new Set(p.fichiers.map(f => f.nom));
  const l = await liste(c).catch(() => null);
  for (const n of l ? l.keys() : []) if (IMG.test(n) && !garder.has(n)) await requete(c, 'DELETE', n, null, null, 10000).catch(() => {});
  return { ok: true };
}
async function changerEtat(c, modif) {
  const et = Object.assign({ noir: false, mire: 0 }, (await lireJson(c, 'etat.json')) || {}, modif);
  await poser(c, 'etat.json', Buffer.from(JSON.stringify(et)), TYPES.json);
  return et;
}
async function appliquer(c, reglages, dureeDe, rotDe) {
  const dia = await lireJson(c, 'diaporama.json');
  if (!dia || dia.type !== 'ecranhall') throw new Error('aucun diaporama Écran Hall sur ce boîtier : envoie-le d’abord');
  dia.orientation = reglages.orientation; dia.transition = reglages.transition; dia.son = reglages.son === true;
  for (const d of dia.diapos) { if (d.v) { if (rotDe) d.r = rotDe(d.n); } else d.d = dureeDe(d.n); }
  await poser(c, 'diaporama.json', Buffer.from(JSON.stringify(dia, null, 1)), TYPES.json);
  return { ok: true };
}

module.exports = { paquet, ecrireTar, ecrireTarFichier, empreinte, liste, etat, envoyer, changerEtat, appliquer, lireDefi, autorisation, IMG };
