#!/bin/bash
# Installateur de secours (Écran Hall), quand macOS refuse d'ouvrir « Installer Écran Hall ».
# Utilisation : dans le Terminal, tape « bash » puis une espace, glisse ce fichier dans la fenêtre, Entrée.
D="$(cd "$(dirname "$0")" && pwd)"
CMD="${D}/Installer Écran Hall.app/Contents/Resources/Installer Écran Hall.command"
if [ ! -f "${CMD}" ]; then
  echo "« Installer Écran Hall » est introuvable à côté de ce fichier. Retélécharge le dossier d'installation."
  exit 1
fi
xattr -cr "${D}" 2>/dev/null || true
echo "Installation de Écran Hall dans le Terminal…"
/bin/bash "${CMD}"
RC=$?
echo
[ ${RC} -eq 0 ] && echo "Terminé. Tu peux fermer cette fenêtre." || echo "L'installation s'est arrêtée (code ${RC}). Envoie une capture de cette fenêtre."
exit ${RC}
