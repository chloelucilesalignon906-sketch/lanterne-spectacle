'use strict';
// Fiabilité, commune aux logiciels de Lanterne Spectacle (copiée dans chacun, comme sauvegarde-main.js).
// - réglages du moteur : l'image et les minuteries continuent quand une fenêtre est cachée ou recouverte ;
// - journal des problèmes (Mac : ~/Library/Logs/<logiciel>/journal.txt, Windows : %APPDATA%\<logiciel>\logs\journal.txt) ;
// - reprise après un plantage de la page : elle se recharge seule, avec le dernier état envoyé par la page (snapshot).
// const fiab = require('./fiabilite')({ app, ipcMain, dialog, gpu: true });   // avant app.whenReady()
// fiab.watch(win) une fois la fenêtre créée ; fiab.log('sujet', 'texte') ailleurs.
const fs = require('fs');
const path = require('path');

module.exports = function fiabilite({ app, ipcMain, dialog, gpu = false }) {
  const sw = app.commandLine;
  sw.appendSwitch('disable-renderer-backgrounding');
  sw.appendSwitch('disable-background-timer-throttling');
  sw.appendSwitch('disable-backgrounding-occluded-windows');
  sw.appendSwitch('disable-background-media-suspend');
  // Windows : une fenêtre recouverte reste « visible » ; vidéos jamais mises en pause quand la régie est réduite
  sw.appendSwitch('disable-features', 'CalculateNativeWinOcclusion,BackgroundVideoPauseOptimization,BackgroundVideoTrackOptimization');
  // Mac à deux cartes graphiques : la plus puissante pour les logiciels qui affichent de la vidéo
  if (gpu) sw.appendSwitch('force_high_performance_gpu');

  /* ---------- journal ---------- */
  let file = null;
  const recent = new Map();   // pas plus de 20 lignes par minute et par sujet
  function log(tag, msg) {
    try {
      const now = Date.now(), r = recent.get(tag) || { t: now, n: 0 };
      if (now - r.t > 60000) { r.t = now; r.n = 0; }
      if (++r.n > 20) { recent.set(tag, r); return; }
      recent.set(tag, r);
      if (!file) {
        const dir = app.getPath('logs');
        fs.mkdirSync(dir, { recursive: true });
        file = path.join(dir, 'journal.txt');
        try { if (fs.statSync(file).size > 1e6) fs.renameSync(file, file + '.ancien'); } catch (e) {}
      }
      fs.appendFileSync(file, `${new Date().toISOString()} [${tag}] ${String(msg).slice(0, 4000)}\n`);
    } catch (e) {}
  }
  // une erreur du processus principal est notée sans fermer le logiciel
  process.on('uncaughtException', e => { log('erreur', e && e.stack || e); console.error(e); });
  process.on('unhandledRejection', e => { log('promesse', e && e.stack || e); });
  app.on('child-process-gone', (_e, d) => log('processus', `${d.type} : ${d.reason} (code ${d.exitCode})`));
  // Mac à puce Apple : le logiciel doit tourner en version Apple Silicon (arm64) ; en version Intel (Rosetta), il est bien plus lent
  const translated = () => { try { return !!(app.runningUnderARM64Translation || app.runningUnderRosettaTranslation); } catch (e) { return false; } };
  const gpuStatus = () => { try { return app.getGPUFeatureStatus() || {}; } catch (e) { return {}; } };
  const soft = s => /software|disabled|unavailable/.test(String(s || ''));
  // l'état de la carte graphique n'est fiable qu'après l'événement gpu-info-update (avant, Chromium répond « logiciel ») :
  // on attend qu'il se stabilise, puis on le note au journal ; pas de message à l'écran (rien à faire pour l'utilisateur)
  let gpuKnown = false, gpuTimer = null;
  function info() {
    const g = gpuStatus();
    return { arch: process.arch, translated: translated(), gpuKnown, gpu: { canvas: g['2d_canvas'], compositing: g.gpu_compositing, video: g.video_decode, webgl: g.webgl },
      slowGpu: gpuKnown && (soft(g['2d_canvas']) || soft(g.gpu_compositing)) };
  }
  ipcMain.handle('fiab-info', () => info());
  app.on('gpu-info-update', () => {
    clearTimeout(gpuTimer);
    gpuTimer = setTimeout(() => { gpuKnown = true; const i = info(); log('graphisme', JSON.stringify(i.gpu) + (i.slowGpu ? ' · SANS CARTE GRAPHIQUE' : '')); }, 3000);
  });
  app.on('child-process-gone', (_e, d) => { if (d.type === 'GPU') setTimeout(() => log('carte graphique', JSON.stringify(info().gpu)), 3000); });
  app.whenReady().then(() => {
    const i = info();
    log('démarrage', `${app.getName()} ${app.getVersion()} · Electron ${process.versions.electron} · ${process.platform} ${process.arch}${i.translated ? ' · MODE INTEL (Rosetta)' : ''}`);
    if (i.translated && process.platform === 'darwin') {
      dialog.showMessageBox({ type: 'warning', buttons: ['OK'], message: `${app.getName()} tourne en version Intel (Rosetta) sur ce Mac à puce Apple.`,
        detail: 'Dans ce mode, il est nettement plus lent, surtout avec une sortie active. Relance « Installer Lanterne Spectacle » (version 2.1.2 ou plus récente) en cochant tous les logiciels : il installera la version faite pour la puce Apple.' }).catch(() => {});
    }
  });
  ipcMain.on('fiab-log', (_e, tag, msg) => log('page:' + String(tag).slice(0, 30), msg));

  /* ---------- reprise après un plantage de la page ---------- */
  const snaps = new Map(), crashed = new Set();
  ipcMain.on('fiab-snap', (e, data) => {
    if (!data || typeof data !== 'object') return;
    const prev = snaps.get(e.sender.id);
    if (data.json == null && prev) data.json = prev.json;   // contenu inchangé : la page ne renvoie que l'état
    snaps.set(e.sender.id, data);
  });
  ipcMain.handle('fiab-recover', e => {
    const id = e.sender.id;
    if (!crashed.has(id)) return null;
    crashed.delete(id);
    return snaps.get(id) || null;
  });
  function watch(win, { onGone } = {}) {
    const wc = win.webContents, id = wc.id;
    let times = [];
    wc.on('render-process-gone', (_e, d) => {
      log('page', `arrêt de la page : ${d.reason} (code ${d.exitCode})`);
      if (d.reason === 'clean-exit' || win.isDestroyed()) return;
      crashed.add(id);
      try { if (onGone) onGone(d); } catch (e) { log('erreur', e && e.stack || e); }
      // les fenêtres de sortie ouvertes par la page partagent son processus : elles sont fermées avec elle
      try {
        const { BrowserWindow } = require('electron');
        for (const w of BrowserWindow.getAllWindows()) if (w !== win && !w.isDestroyed() && w.webContents.isCrashed()) w.destroy();
      } catch (e) {}
      const now = Date.now();
      times = times.filter(t => now - t < 60000); times.push(now);
      if (times.length > 3) {
        // plantages répétés : on ne relance pas en boucle, on demande
        const r = dialog.showMessageBoxSync(win, { type: 'error', buttons: ['Relancer', 'Quitter'], defaultId: 0, cancelId: 1,
          message: `${app.getName()} a rencontré plusieurs problèmes de suite.`, detail: 'Relancer recharge la fenêtre avec le dernier état connu.' });
        if (r === 1) { app.quit(); return; }
        times = [];
      }
      setTimeout(() => { if (!win.isDestroyed()) wc.reload(); }, 300);
    });
    // page bloquée : après 8 s sans réponse, on propose de la recharger avec le dernier état connu (comme après un plantage)
    let hangT = null, hangAsk = null;
    const hangEnd = () => { clearTimeout(hangT); hangT = null; if (hangAsk) { try { hangAsk.abort(); } catch (e) {} hangAsk = null; } };
    wc.on('unresponsive', () => {
      log('page', 'la page ne répond plus');
      if (hangT || hangAsk) return;
      hangT = setTimeout(() => {
        hangT = null;
        if (win.isDestroyed()) return;
        hangAsk = new AbortController();
        dialog.showMessageBox(win, { type: 'warning', buttons: ['Recharger la fenêtre', 'Attendre'], defaultId: 0, cancelId: 1, signal: hangAsk.signal,
          message: `${app.getName()} ne répond plus.`, detail: 'Recharger la fenêtre la relance avec le dernier état connu, comme après un plantage (vérifie ensuite les sorties). Attendre laisse la page finir ce qu’elle fait.' })
          .then(r => {
            hangAsk = null;
            if (r.response !== 0 || win.isDestroyed()) return;
            log('page', 'rechargée après blocage, à la demande');
            try { wc.forcefullyCrashRenderer(); } catch (e) { try { crashed.add(id); wc.reload(); } catch (er) {} }
          }).catch(() => { hangAsk = null; });
      }, 8000);
    });
    wc.on('responsive', () => { log('page', 'la page répond de nouveau'); hangEnd(); });
    win.on('closed', () => { hangEnd(); snaps.delete(id); crashed.delete(id); });
  }
  return { log, watch, ecrire, ecrireAsync, raison };
};

/* ---------- écriture sûre d'un fichier (sauvegardes, réglages) ----------
   Écrit d'abord un fichier temporaire à côté, le force sur le disque, puis le renomme : une coupure de courant
   ou un plantage pendant l'écriture laisse l'ancien fichier entier au lieu d'un fichier vide ou coupé.
   Utilisable sans lancer fiabilite() : require('./fiabilite').ecrire(fichier, données). */
// fichier temporaire propre à chaque écriture : deux enregistrements du même fichier qui se croisent ne se mélangent pas
let tmpN = 0;
const tmpOf = file => `${file}.${process.pid}.${++tmpN}.tmp`;
// erreurs où l'écriture directe serait pire : plus de place, quota, disque en lecture seule ou abîmé
const KEEP_OLD = new Set(['ENOSPC', 'EDQUOT', 'EROFS', 'EIO', 'EFBIG']);
const keepOld = e => !!(e && KEEP_OLD.has(e.code));
// message lisible pour une écriture refusée (sauvegardes, projet)
function raison(e) {
  const c = e && e.code;
  if (c === 'ENOSPC' || c === 'EDQUOT') return 'le disque est plein : libère de la place, puis recommence (l’ancienne sauvegarde est gardée)';
  if (c === 'EROFS') return 'ce disque est en lecture seule';
  if (c === 'EACCES' || c === 'EPERM') return 'ce dossier refuse l’écriture';
  if (c === 'EIO') return 'erreur du disque (l’ancienne sauvegarde est gardée)';
  return String(e && e.message || e);
}
function ecrire(file, data) {
  const tmp = tmpOf(file);
  try {
    const fd = fs.openSync(tmp, 'w');
    try { fs.writeFileSync(fd, data); try { fs.fsyncSync(fd); } catch (e) {} } finally { fs.closeSync(fd); }
    fs.renameSync(tmp, file);
  } catch (e) {
    try { fs.rmSync(tmp, { force: true }); } catch (er) {}
    // disque plein ou abîmé : l'ancien fichier est gardé tel quel (une écriture directe le viderait avant d'échouer)
    if (keepOld(e)) throw e;
    fs.writeFileSync(file, data);   // dossier sans droit de créer un fichier à côté, fichier verrouillé (Windows) : écriture directe
  }
}
async function ecrireAsync(file, data) {
  const tmp = tmpOf(file);
  try {
    const fh = await fs.promises.open(tmp, 'w');
    try { await fh.writeFile(data); try { await fh.sync(); } catch (e) {} } finally { await fh.close(); }
    await fs.promises.rename(tmp, file);
  } catch (e) {
    try { await fs.promises.rm(tmp, { force: true }); } catch (er) {}
    if (keepOld(e)) throw e;
    await fs.promises.writeFile(file, data);
  }
}
module.exports.ecrire = ecrire;
module.exports.ecrireAsync = ecrireAsync;
module.exports.raison = raison;
