'use strict';
// Nom de famille, graisse et italique d'un fichier de police (.ttf, .otf, .ttc), lus dans ses tables « name » et « OS/2 »
const fs = require('fs');

function faceAt(b, base) {
  const n = b.readUInt16BE(base + 4);
  const tables = {};
  for (let i = 0; i < n; i++) {
    const o = base + 12 + i * 16;
    tables[b.toString('latin1', o, o + 4)] = { off: b.readUInt32BE(o + 8), len: b.readUInt32BE(o + 12) };
  }
  const names = {};
  const nt = tables.name;
  if (nt) {
    const cnt = b.readUInt16BE(nt.off + 2), strOff = nt.off + b.readUInt16BE(nt.off + 4);
    for (let i = 0; i < cnt; i++) {
      const r = nt.off + 6 + i * 12;
      const pid = b.readUInt16BE(r), eid = b.readUInt16BE(r + 2), lang = b.readUInt16BE(r + 4), id = b.readUInt16BE(r + 6), len = b.readUInt16BE(r + 8), off = b.readUInt16BE(r + 10);
      if (![1, 2, 4, 6, 16, 17].includes(id)) continue;
      const raw = b.subarray(strOff + off, strOff + off + len);
      let s;
      if (pid === 3 || pid === 0) { const t = Buffer.from(raw); t.swap16(); s = t.toString('utf16le'); }
      else if (pid === 1 && eid === 0) s = raw.toString('latin1');
      else continue;
      // anglais (États-Unis) d'abord
      const score = (pid === 3 && lang === 0x409) ? 3 : pid === 1 && lang === 0 ? 2 : 1;
      if (!names[id] || names[id].score < score) names[id] = { s, score };
    }
  }
  let weight = 400, italic = false;
  const os2 = tables['OS/2'];
  if (os2) { weight = b.readUInt16BE(os2.off + 4) || 400; italic = !!(b.readUInt16BE(os2.off + 62) & 1); }
  // police variable : plage des graisses (axe « wght » de la table fvar), ex. « 100 900 »
  let range = '';
  const fv = tables.fvar;
  if (fv) {
    const axOff = fv.off + b.readUInt16BE(fv.off + 4), n = b.readUInt16BE(fv.off + 8), size = b.readUInt16BE(fv.off + 10);
    for (let i = 0; i < n; i++) {
      const o = axOff + i * size;
      if (b.toString('latin1', o, o + 4) === 'wght') range = `${Math.round(b.readInt32BE(o + 4) / 65536)} ${Math.round(b.readInt32BE(o + 12) / 65536)}`;
    }
  }
  const v = id => names[id] ? names[id].s.trim() : '';
  return { family: v(16) || v(1), sub: v(17) || v(2), full: v(4), ps: v(6), legacy: v(1), weight: range || weight, variable: !!range, italic };
}

// liste des visages d'un fichier (une police, ou plusieurs dans un .ttc)
function read(file) {
  const b = fs.readFileSync(file);
  return readBuf(b);
}
function readBuf(b) {
  if (b.length < 12) return [];
  const tag = b.toString('latin1', 0, 4);
  if (tag === 'ttcf') {
    const n = b.readUInt32BE(8), out = [];
    for (let i = 0; i < n; i++) { try { out.push(Object.assign(faceAt(b, b.readUInt32BE(12 + i * 4)), { index: i })); } catch (e) {} }
    return out;
  }
  if (tag === 'wOFF' || tag === 'wOF2') return [];   // police web : nom lu par la page
  try { return [faceAt(b, 0)]; } catch (e) { return []; }
}

module.exports = { read, readBuf };
