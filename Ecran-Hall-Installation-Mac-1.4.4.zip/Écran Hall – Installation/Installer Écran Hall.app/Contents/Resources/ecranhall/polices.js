'use strict';
/* Lanterne PPT — polices d'un diaporama : trouver chaque police utilisée, sinon la remplacer au plus près.
   Ordre de recherche : police importée par l'utilisateur, police installée sur l'ordinateur, polices de Microsoft Office
   (Mac : rangées dans l'application, invisibles des autres logiciels), polices fournies avec Lanterne PPT,
   police intégrée au fichier, nom complet d'un style (« Avenir Black » = Avenir en graisse 900), police proche. */
(function () {
const GENERIC = ['monospace', 'serif', 'sans-serif'];
const SAMPLE = 'mmmmmmmmmmlli WWW@#ÉçQ 0123 ﬁ';
const cv = document.createElement('canvas').getContext('2d');
const wCache = new Map();
function width(fam) { if (wCache.has(fam)) return wCache.get(fam); cv.font = `72px ${fam}`; const w = cv.measureText(SAMPLE).width; wCache.set(fam, w); return w; }
// police connue de Chromium sous ce nom de famille (installée ou déjà chargée)
function installed(face) {
  if (!face) return false;
  const q = `"${face.replace(/"/g, '')}"`;
  return GENERIC.some(g => Math.abs(width(`${q}, ${g}`) - width(g)) > 0.5);
}
// les deux graisses donnent-elles des dessins différents (vraie police grasse, pas une imitation) ?
function hasWeight(face, w) {
  cv.font = `400 72px "${face}"`; const a = cv.measureText(SAMPLE).width;
  cv.font = `${w} 72px "${face}"`; const b = cv.measureText(SAMPLE).width;
  return Math.abs(a - b) > 0.5 || w === 400;
}
const STYLE_WORDS = [
  [/\s+(Extra|Ultra)[\s-]?Black$/i, 950], [/\s+(Black|Heavy)$/i, 900], [/\s+(Extra|Ultra)[\s-]?Bold$/i, 800], [/\s+(Semi|Demi)[\s-]?Bold$/i, 600],
  [/\s+Bold$/i, 700], [/\s+Medium$/i, 500], [/\s+(Book|Roman|Regular|Normal)$/i, 400], [/\s+(Extra|Ultra)[\s-]?Light$/i, 200],
  [/\s+(Semi|Demi)[\s-]?Light$/i, 350], [/\s+Light$/i, 300], [/\s+(Thin|Hairline)$/i, 100], [/\s+Narrow$/i, 400], [/\s+Condensed$/i, 400],
];
function splitStyle(face) {
  for (const [re, w] of STYLE_WORDS) if (re.test(face)) return { base: face.replace(re, '').trim(), weight: w };
  return null;
}
// polices de remplacement quand rien n'est trouvé (Mac, Windows, puis polices fournies)
const SUBST = {
  'calibri': ['Carlito'], 'calibri light': ['Carlito'], 'cambria': ['Caladea'], 'aptos': ['Helvetica Neue', 'Segoe UI', 'Inter', 'Arial'], 'aptos display': ['Helvetica Neue', 'Segoe UI', 'Inter', 'Arial'], 'aptos narrow': ['Arial Narrow', 'Helvetica Neue'],
  'avenir': ['Avenir Next', 'Montserrat', 'Century Gothic'], 'avenir next': ['Avenir', 'Montserrat'], 'avenir black': ['Avenir Next', 'Montserrat'], 'segoe ui': ['Helvetica Neue', 'Arial'], 'helvetica': ['Helvetica Neue', 'Arial'], 'helvetica neue': ['Helvetica', 'Arial'],
  'arial': ['Helvetica', 'Liberation Sans'], 'times new roman': ['Times', 'Liberation Serif'], 'times': ['Times New Roman', 'Liberation Serif'], 'century gothic': ['Avenir', 'Montserrat'], 'gill sans': ['Gill Sans MT', 'Montserrat'], 'gill sans mt': ['Gill Sans', 'Montserrat'],
  'franklin gothic': ['Arial', 'Helvetica Neue'], 'futura': ['Century Gothic', 'Montserrat'], 'proxima nova': ['Montserrat'], 'gotham': ['Montserrat'], 'garamond': ['Georgia', 'Times New Roman'], 'tahoma': ['Verdana', 'Arial'], 'verdana': ['Tahoma', 'Arial'],
  'open sans': ['Open Sans'], 'lato': ['Open Sans', 'Helvetica Neue'], 'source sans pro': ['Open Sans'], 'nunito': ['Montserrat'], 'raleway': ['Montserrat'], 'poppins': ['Poppins'],
};
const SERIF = /serif|times|garamond|georgia|cambria|didot|bodoni|baskerville|caslon|palatino|book antiqua|minion|caladea/i;

let BUNDLED = [], OFFICE = [], IMPORTED = [], EMBEDDED = [], BASE_URL = '';
const MAP = new Map();          // nom de police du diaporama -> { family, weight (forcée) | null, status, use }
const loadedFaces = new Set();  // familles déjà chargées par FontFace
const OWN = new Map();          // famille chargée par Lanterne PPT -> d'où elle vient (elle n'est pas « installée »)

async function addFace(family, url, desc) {
  const key = family + '|' + url + '|' + (desc.weight || '') + '|' + (desc.style || '');
  if (loadedFaces.has(key)) return true;
  try {
    const ff = new FontFace(family, typeof url === 'string' ? `url("${url}")` : url, desc);
    await ff.load();
    document.fonts.add(ff);
    loadedFaces.add(key);
    wCache.clear();
    return true;
  } catch (e) { return false; }
}
// visages d'une liste (Office, fournies, importées) pour une famille, chargés sous le nom voulu
async function loadFamilyFrom(list, family, asName) {
  const faces = list.filter(f => f.family.toLowerCase() === family.toLowerCase());
  let ok = false;
  for (const f of faces) ok = (await addFace(asName || f.family, f.url, { weight: String(f.weight || 400), style: f.italic || f.style === 'italic' ? 'italic' : 'normal' })) || ok;
  return ok;
}
// police intégrée au fichier PowerPoint (EOT) : seulement si elle n'est pas compressée (MicroType Express)
async function embeddedFont(e) {
  try {
    const buf = await (await fetch(e.url)).arrayBuffer();
    const dv = new DataView(buf);
    const eotSize = dv.getUint32(0, true), dataSize = dv.getUint32(4, true), flags = dv.getUint32(12, true);
    let data;
    if (dv.getUint16(34, true) === 0x504C && eotSize === buf.byteLength && dataSize < eotSize) {
      if (flags & 0x4) return 'compressée';
      data = new Uint8Array(buf.slice(eotSize - dataSize));
      if (flags & 0x10000000) for (let i = 0; i < data.length; i++) data[i] ^= 0x50;
    } else data = new Uint8Array(buf);
    const ok = await addFace(e.family, data.buffer, { weight: String(e.weight), style: e.italic ? 'italic' : 'normal' });
    return ok ? 'ok' : 'illisible';
  } catch (err) { return 'illisible'; }
}

async function resolveFace(face, deck) {
  const r = await resolveFace0(face, deck);
  if (['importée', 'Office', 'fournie', 'intégrée'].includes(r.status)) OWN.set(r.family.toLowerCase(), r.status);
  return r;
}
// police vue par Chromium : installée sur l'ordinateur, ou chargée ici plus tôt (sa vraie source est alors gardée)
const sysOrOwn = f => OWN.get(f.toLowerCase()) || (installed(f) ? 'installée' : '');
async function resolveFace0(face, deck) {
  const low = face.toLowerCase();
  // 1. importée par l'utilisateur pour ce nom (ou dont la famille porte ce nom)
  const imp = IMPORTED.filter(f => (f.for || []).some(x => x.toLowerCase() === low));
  if (imp.length) {
    let ok = false;
    for (const f of imp) ok = (await addFace(face, f.url, { weight: String(f.weight || 400), style: f.italic ? 'italic' : 'normal' })) || ok;
    // police variable : la graisse vient du nom (« Avenir Black » = 900)
    const sp = splitStyle(face), variable = imp.some(f => / /.test(String(f.weight)));
    if (ok) return { family: face, weight: variable && sp ? sp.weight : null, status: 'importée', use: imp[0].name || face };
  }
  if (IMPORTED.some(f => f.family.toLowerCase() === low) && await loadFamilyFrom(IMPORTED, face)) return { family: face, status: 'importée', use: face };
  // 2. installée
  const seen = sysOrOwn(face);
  if (seen && seen !== 'importée') return { family: face, status: seen, use: face };
  // 3. Microsoft Office (Mac)
  if (OFFICE.some(f => f.family.toLowerCase() === low) && await loadFamilyFrom(OFFICE, face)) return { family: face, status: 'Office', use: face };
  // 4. fournie avec Lanterne PPT
  if (BUNDLED.some(f => f.family.toLowerCase() === low) && await loadFamilyFrom(BUNDLED, face)) return { family: face, status: 'fournie', use: face };
  // 5. intégrée au fichier
  const emb = (deck.embedded || []).filter(e => e.family.toLowerCase() === low);
  let embState = '';
  if (emb.length) {
    let ok = false;
    for (const e of emb) { const r = await embeddedFont(e); if (r === 'ok') ok = true; else embState = r; }
    if (ok) return { family: face, status: 'intégrée', use: face };
  }
  // 6. nom complet d'un visage installé (Mac : « Avenir-Black »)
  if (await addFace(face, `local("${face}"), local("${face.replace(/\s+/g, '-')}"), local("${face.replace(/\s+/g, '')}")`, { weight: '400', style: 'normal' })) {
    if (installed(face)) return { family: face, status: 'installée', use: face };
  }
  // 7. famille + graisse (« Outfit ExtraBold » = Outfit en 800)
  const sp = splitStyle(face);
  if (sp && sp.base) {
    const b = sp.base, bl = b.toLowerCase();
    let src = '';
    if (IMPORTED.some(f => f.family.toLowerCase() === bl) && await loadFamilyFrom(IMPORTED, b)) src = 'importée';
    else if (sysOrOwn(b) && sysOrOwn(b) !== 'importée') src = sysOrOwn(b);
    else if (OFFICE.some(f => f.family.toLowerCase() === bl) && await loadFamilyFrom(OFFICE, b)) src = 'Office';
    else if (BUNDLED.some(f => f.family.toLowerCase() === bl) && await loadFamilyFrom(BUNDLED, b)) src = 'fournie';
    if (src) return { family: b, weight: sp.weight, status: src, use: `${b} (${sp.weight})`, exact: hasWeight(b, sp.weight) };
  }
  // 8. remplacement
  const cand = SUBST[low] || (sp && SUBST[sp.base.toLowerCase()]) || [];
  for (const c of cand) {
    if (installed(c) || (BUNDLED.some(f => f.family === c) && await loadFamilyFrom(BUNDLED, c)) || (OFFICE.some(f => f.family === c) && await loadFamilyFrom(OFFICE, c)))
      return { family: c, weight: sp ? sp.weight : null, status: 'remplacée', use: c, emb: embState };
  }
  const gen = SERIF.test(face) ? 'serif' : 'sans-serif';
  const fb = gen === 'serif' ? (installed('Times New Roman') ? 'Times New Roman' : 'serif') : (installed('Helvetica Neue') ? 'Helvetica Neue' : installed('Arial') ? 'Arial' : 'sans-serif');
  return { family: fb, weight: sp ? sp.weight : null, status: 'manquante', use: fb, emb: embState };
}

const P = {
  // listes : polices fournies (fonts/index.json), Office et importées (données par le processus principal)
  async init(o) {
    BASE_URL = o.base || '';
    BUNDLED = (o.bundled || []).map(f => Object.assign({}, f, { url: o.base + 'fonts/' + encodeURIComponent(f.file), weight: f.weight, italic: f.style === 'italic' }));
    OFFICE = o.office || [];
    IMPORTED = o.imported || [];
  },
  setImported(list) { IMPORTED = list || []; },
  setOffice(list) { OFFICE = list || []; },
  // toutes les polices du diaporama : rapport [{ face, status, use }]
  async prepare(deck) {
    MAP.clear();
    const faces = new Set(deck.fonts || []);
    if (deck.themeFonts) { faces.add(deck.themeFonts.major); faces.add(deck.themeFonts.minor); }
    const report = [];
    for (const f of faces) {
      if (!f) continue;
      const r = await resolveFace(f, deck);
      MAP.set(f, r);
      if ((deck.fonts || []).includes(f)) report.push(Object.assign({ face: f }, r));
    }
    // fenêtre cachée (Mac) : document.fonts.ready peut ne jamais arriver si la page n'est jamais dessinée
    await Promise.race([document.fonts.ready, new Promise(r => setTimeout(r, 4000))]);
    wCache.clear();
    return report;
  },
  // police à utiliser pour dessiner : { family (liste CSS), weight, style }
  resolve(face, b, i) {
    const r = MAP.get(face);
    const fam = r ? r.family : face;
    const fall = SERIF.test(face) ? 'serif' : '"Helvetica Neue", Arial, sans-serif';
    let weight = b ? 700 : 400;
    if (r && r.weight) weight = b && r.weight < 600 ? 700 : r.weight;
    return { family: `"${fam}", ${fall}`, weight, style: i ? 'italic' : 'normal' };
  },
  installed, splitStyle,
};
window.LanternePolices = P;
})();
