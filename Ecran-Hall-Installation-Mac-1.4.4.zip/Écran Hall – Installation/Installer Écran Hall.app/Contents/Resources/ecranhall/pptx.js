'use strict';
/* Lanterne PPT — lecture d'un diaporama PowerPoint (.pptx déjà décompressé, lu par fetch sous `base`)
   Donne un modèle simple à dessiner : diapos, éléments (formes, images, vidéos, textes, tableaux), fonds,
   transitions, animations et notes. Les coordonnées restent en EMU (914400 par pouce, 12700 par point).
   Ce qui n'est pas reproduit est noté dans deck.warnings (avec le numéro de la diapo). */
(function () {
const R_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
// espaces de noms des extensions de PowerPoint que nous savons lire (mc:Choice Requires="…")
const KNOWN_NS = new Set(['p14', 'p15', 'a14', 'p159', 'a16', 'asvg', 'v', 'p188', 'thm15', 'x14', 'c14', 'wps', 'a15', 'aink', 'am3d']);
const SKIP_NS = new Set(['aink', 'am3d']);   // encre et modèles 3D : on prend l'image de secours

/* ---------- petits outils XML (noms locaux, sans tenir compte du préfixe) ---------- */
const kids = (el, name) => { const out = []; if (!el) return out; for (let c = el.firstElementChild; c; c = c.nextElementSibling) if (!name || c.localName === name) out.push(c); return out; };
const kid = (el, name) => { if (!el) return null; for (let c = el.firstElementChild; c; c = c.nextElementSibling) if (c.localName === name) return c; return null; };
const path1 = (el, ...names) => { let e = el; for (const n of names) { e = kid(e, n); if (!e) return null; } return e; };
const attr = (el, n, d) => { if (!el) return d; const v = el.getAttribute(n); return v == null ? d : v; };
const num = (el, n, d) => { const v = attr(el, n, null); if (v == null || v === '') return d; const x = parseFloat(v); return isFinite(x) ? x : d; };
const bool = (el, n, d) => { const v = attr(el, n, null); return v == null ? d : (v === '1' || v === 'true' || v === 'on'); };
const rid = (el, n) => el ? (el.getAttributeNS(R_NS, n) || el.getAttribute('r:' + n) || '') : '';
// mc:AlternateContent : on garde mc:Choice si nous connaissons ses espaces de noms, sinon mc:Fallback
function resolveAC(el) {
  for (const ac of [...el.getElementsByTagNameNS('*', 'AlternateContent')]) {
    if (!ac.parentNode) continue;
    let pick = null;
    for (const c of kids(ac)) {
      if (c.localName === 'Choice') {
        const req = (c.getAttribute('Requires') || '').split(/\s+/).filter(Boolean);
        if (!pick && req.every(r => KNOWN_NS.has(r) && !SKIP_NS.has(r))) pick = c;
      } else if (c.localName === 'Fallback' && !pick) pick = c;
    }
    const frag = el.ownerDocument.createDocumentFragment();
    if (pick) while (pick.firstChild) frag.appendChild(pick.firstChild);
    ac.parentNode.replaceChild(frag, ac);
  }
  return el;
}

/* ---------- couleurs ---------- */
const PRESET = { black: '000000', white: 'FFFFFF', red: 'FF0000', green: '008000', blue: '0000FF', yellow: 'FFFF00', cyan: '00FFFF', magenta: 'FF00FF', gray: '808080', grey: '808080', darkGray: 'A9A9A9', lightGray: 'D3D3D3', orange: 'FFA500', purple: '800080', navy: '000080', maroon: '800000', olive: '808000', teal: '008080', silver: 'C0C0C0', lime: '00FF00', pink: 'FFC0CB', brown: 'A52A2A', gold: 'FFD700', darkBlue: '00008B', darkRed: '8B0000', darkGreen: '006400', lightBlue: 'ADD8E6' };
const SYS = { windowText: '000000', window: 'FFFFFF', btnFace: 'F0F0F0', highlight: '0078D7', highlightText: 'FFFFFF', menuText: '000000', captionText: '000000', grayText: '6D6D6D', btnText: '000000' };
const hex2 = h => ({ r: parseInt(h.slice(0, 2), 16), g: parseInt(h.slice(2, 4), 16), b: parseInt(h.slice(4, 6), 16), a: 1 });
function rgb2hsl({ r, g, b }) {
  r /= 255; g /= 255; b /= 255;
  const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2;
  if (mx === mn) return { h: 0, s: 0, l };
  const d = mx - mn, s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
  let h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
  return { h: h / 6, s, l };
}
function hsl2rgb({ h, s, l }) {
  if (s === 0) { const v = Math.round(l * 255); return { r: v, g: v, b: v }; }
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
  const f = t => { t = (t % 1 + 1) % 1; return t < 1 / 6 ? p + (q - p) * 6 * t : t < 1 / 2 ? q : t < 2 / 3 ? p + (q - p) * (2 / 3 - t) * 6 : p; };
  return { r: Math.round(f(h + 1 / 3) * 255), g: Math.round(f(h) * 255), b: Math.round(f(h - 1 / 3) * 255) };
}
const toLin = v => { v /= 255; return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
const toSrgb = v => { v = Math.max(0, Math.min(1, v)); return Math.round((v <= 0.0031308 ? v * 12.92 : 1.055 * Math.pow(v, 1 / 2.4) - 0.055) * 255); };
const clamp01 = v => Math.max(0, Math.min(1, v));

/* ---------- lecture du paquet ---------- */
async function loadDeck(base, opt = {}) {
  const warn = new Map();   // texte -> Set(numéros de diapo)
  const warning = (txt, n) => { if (!warn.has(txt)) warn.set(txt, new Set()); if (n) warn.get(txt).add(n); };
  const xmlCache = new Map();
  const parser = new DOMParser();
  const url = p => base + p.split('/').map(encodeURIComponent).join('/');
  async function xml(p) {
    if (xmlCache.has(p)) return xmlCache.get(p);
    const pr = (async () => {
      // Écran Hall 1.2.1 : une pièce illisible du fichier n'arrête plus toute la lecture (« Failed to fetch » sur un Mac le 23/11/2026)
      let r;
      try { r = await fetch(url(p)); } catch (e) { warning('Partie du fichier illisible : ' + p); try { console.warn('pptx: lecture impossible ' + p + ' : ' + e.message); } catch (x) {} return null; }
      if (!r.ok) return null;
      const d = parser.parseFromString(await r.text(), 'application/xml');
      if (d.getElementsByTagName('parsererror').length) return null;
      resolveAC(d.documentElement);
      return d.documentElement;
    })();
    xmlCache.set(p, pr);
    return pr;
  }
  const dirOf = p => p.slice(0, p.lastIndexOf('/') + 1);
  function joinPath(dir, t) {
    if (t.startsWith('/')) return t.slice(1);
    const parts = (dir + t).split('/'), out = [];
    for (const s of parts) { if (s === '..') out.pop(); else if (s !== '.' && s !== '') out.push(s); }
    return out.join('/');
  }
  async function rels(p) {
    const r = await xml(dirOf(p) + '_rels/' + p.slice(dirOf(p).length) + '.rels');
    const m = new Map();
    for (const e of kids(r, 'Relationship')) {
      const ext = attr(e, 'TargetMode', '') === 'External';
      const t = attr(e, 'Target', '');
      m.set(attr(e, 'Id', ''), { type: attr(e, 'Type', '').split('/').pop(), target: ext ? t : joinPath(dirOf(p), decodeURIComponent(t)), external: ext });
    }
    return m;
  }

  const pres = await xml('ppt/presentation.xml');
  if (!pres) throw new Error('presentation.xml introuvable : ce n’est pas un diaporama PowerPoint (.pptx).');
  const presRels = await rels('ppt/presentation.xml');
  const sz = kid(pres, 'sldSz');
  const W = num(sz, 'cx', 12192000), H = num(sz, 'cy', 6858000);
  const defaultTextStyle = kid(pres, 'defaultTextStyle');
  // polices intégrées au fichier
  const embedded = [];
  for (const ef of kids(kid(pres, 'embeddedFontLst'), 'embeddedFont')) {
    const fam = attr(kid(ef, 'font'), 'typeface', '');
    for (const [k, w, it] of [['regular', 400, false], ['bold', 700, false], ['italic', 400, true], ['boldItalic', 700, true]]) {
      const r = presRels.get(rid(kid(ef, k), 'id'));
      if (fam && r) embedded.push({ family: fam, weight: w, italic: it, url: url(r.target) });
    }
  }
  // tableaux : styles du fichier
  let tableStyles = null;
  for (const r of presRels.values()) if (r.type === 'tableStyles') tableStyles = await xml(r.target);

  /* ----- thèmes, masques, dispositions (gardés une fois lus) ----- */
  const themes = new Map(), masters = new Map(), layouts = new Map();
  async function loadTheme(p) {
    if (themes.has(p)) return themes.get(p);
    const t = await xml(p);
    const th = { colors: {}, major: 'Calibri Light', minor: 'Calibri', fills: [], lines: [], effects: [], bgFills: [] };
    const cs = path1(t, 'themeElements', 'clrScheme');
    for (const c of kids(cs)) {
      const v = kid(c, 'srgbClr') ? attr(kid(c, 'srgbClr'), 'val') : kid(c, 'sysClr') ? attr(kid(c, 'sysClr'), 'lastClr', SYS[attr(kid(c, 'sysClr'), 'val')] || '000000') : '000000';
      th.colors[c.localName] = v;
    }
    const fs = path1(t, 'themeElements', 'fontScheme');
    th.major = attr(path1(fs, 'majorFont', 'latin'), 'typeface', th.major) || th.major;
    th.minor = attr(path1(fs, 'minorFont', 'latin'), 'typeface', th.minor) || th.minor;
    const fm = path1(t, 'themeElements', 'fmtScheme');
    th.fills = kids(kid(fm, 'fillStyleLst')); th.lines = kids(kid(fm, 'lnStyleLst')); th.effects = kids(kid(fm, 'effectStyleLst')); th.bgFills = kids(kid(fm, 'bgFillStyleLst'));
    th.objDefaults = kid(t, 'objectDefaults');
    themes.set(p, th);
    return th;
  }
  const clrMapOf = el => { const m = {}; if (el) for (const a of el.attributes) m[a.name] = a.value; return m; };
  async function loadMaster(p) {
    if (masters.has(p)) return masters.get(p);
    const doc = await xml(p), rl = await rels(p);
    let theme = null;
    for (const r of rl.values()) if (r.type === 'theme') theme = await loadTheme(r.target);
    const m = { path: p, doc, rels: rl, theme, clrMap: clrMapOf(kid(doc, 'clrMap')), tx: kid(doc, 'txStyles'), tree: path1(doc, 'cSld', 'spTree'), bg: path1(doc, 'cSld', 'bg') };
    m.ph = phIndex(m.tree);
    masters.set(p, m);
    return m;
  }
  async function loadLayout(p) {
    if (layouts.has(p)) return layouts.get(p);
    const doc = await xml(p), rl = await rels(p);
    let master = null;
    for (const r of rl.values()) if (r.type === 'slideMaster') master = await loadMaster(r.target);
    const ov = path1(doc, 'clrMapOvr', 'overrideClrMapping');
    const l = { path: p, doc, rels: rl, master, clrMap: ov ? clrMapOf(ov) : null, tree: path1(doc, 'cSld', 'spTree'), bg: path1(doc, 'cSld', 'bg'), showMaster: bool(doc, 'showMasterSp', true) };
    l.ph = phIndex(l.tree);
    layouts.set(p, l);
    return l;
  }
  // espaces réservés d'un arbre : par numéro et par type
  function phIndex(tree) {
    const idx = new Map(), type = new Map();
    for (const sp of tree ? tree.getElementsByTagNameNS('*', 'ph') : []) {
      const shape = sp.parentNode && sp.parentNode.parentNode && sp.parentNode.parentNode.parentNode;
      if (!shape) continue;
      const t = attr(sp, 'type', 'body'), i = attr(sp, 'idx', null);
      if (i != null && !idx.has(i)) idx.set(i, shape);
      if (!type.has(t)) type.set(t, shape);
    }
    return { idx, type };
  }
  const phOf = sp => { const nv = kid(sp, 'nvSpPr') || kid(sp, 'nvPicPr') || kid(sp, 'nvGraphicFramePr') || kid(sp, 'nvCxnSpPr') || kid(sp, 'nvGrpSpPr'); return path1(nv, 'nvPr', 'ph'); };
  function findPh(ix, ph, isMaster) {
    if (!ix || !ph) return null;
    const t = attr(ph, 'type', 'body'), i = attr(ph, 'idx', null);
    if (!isMaster && i != null && ix.idx.has(i)) {
      const s = ix.idx.get(i), st = attr(phOf(s), 'type', 'body');
      if (st === t || t === 'body' || st === 'body' || (t === 'obj')) return s;
    }
    const alt = { ctrTitle: 'title', subTitle: 'body', obj: 'body', tbl: 'body', chart: 'body', pic: 'body', media: 'body', clipArt: 'body', dgm: 'body' };
    if (ix.type.has(t)) return ix.type.get(t);
    if (alt[t] && ix.type.has(alt[t])) return ix.type.get(alt[t]);
    if (isMaster && i != null && ix.idx.has(i)) return ix.idx.get(i);
    return null;
  }

  /* ----- contexte d'une partie (diapo, disposition ou masque) : couleurs, liens, styles ----- */
  function mkCtx(part, layout, master, slideNo) {
    const theme = master.theme || { colors: {}, major: 'Calibri Light', minor: 'Calibri', fills: [], lines: [], effects: [], bgFills: [] };
    const map = Object.assign({}, master.clrMap, (layout && layout.clrMap) || {}, part.clrMap || {});
    return { part, layout, master, theme, map, n: slideNo, rels: part.rels };
  }
  function schemeHex(ctx, v, ph) {
    if (v === 'phClr') return ph || { r: 0, g: 0, b: 0, a: 1 };
    const m = { bg1: 'lt1', tx1: 'dk1', bg2: 'lt2', tx2: 'dk2' };
    const k = m[v] ? (ctx.map[v] || m[v]) : v;
    return hex2(ctx.theme.colors[k] || ctx.theme.colors[m[v] || v] || '000000');
  }
  // couleur d'un élément contenant srgbClr / schemeClr / …, avec ses modificateurs
  function color(ctx, holder, ph) {
    if (!holder) return null;
    const e = ['srgbClr', 'schemeClr', 'sysClr', 'prstClr', 'scrgbClr', 'hslClr'].includes(holder.localName) ? holder : kids(holder).find(c => /Clr$/.test(c.localName) && c.localName !== 'buClr');
    if (!e) return null;
    let c;
    switch (e.localName) {
      case 'srgbClr': c = hex2(attr(e, 'val', '000000')); break;
      case 'schemeClr': c = Object.assign({}, schemeHex(ctx, attr(e, 'val', 'tx1'), ph)); break;
      case 'sysClr': c = hex2(attr(e, 'lastClr', SYS[attr(e, 'val')] || '000000')); break;
      case 'prstClr': c = hex2(PRESET[attr(e, 'val')] || '000000'); break;
      case 'scrgbClr': c = { r: toSrgb(num(e, 'r', 0) / 1e5), g: toSrgb(num(e, 'g', 0) / 1e5), b: toSrgb(num(e, 'b', 0) / 1e5), a: 1 }; break;
      case 'hslClr': c = Object.assign(hsl2rgb({ h: num(e, 'hue', 0) / 21600000, s: num(e, 'sat', 0) / 1e5, l: num(e, 'lum', 0) / 1e5 }), { a: 1 }); break;
      default: return null;
    }
    c = Object.assign({ a: 1 }, c);
    for (const m of kids(e)) {
      const v = num(m, 'val', 0) / 1e5;
      switch (m.localName) {
        case 'alpha': c.a = v; break;
        case 'alphaMod': c.a *= v; break;
        case 'alphaOff': c.a = clamp01(c.a + v); break;
        case 'lumMod': case 'lumOff': case 'satMod': case 'satOff': case 'hueMod': case 'hueOff': case 'lum': case 'sat': case 'hue': {
          const h = rgb2hsl(c);
          if (m.localName === 'lumMod') h.l *= v; else if (m.localName === 'lumOff') h.l += v; else if (m.localName === 'lum') h.l = v;
          else if (m.localName === 'satMod') h.s *= v; else if (m.localName === 'satOff') h.s += v; else if (m.localName === 'sat') h.s = v;
          else if (m.localName === 'hueMod') h.h *= v; else if (m.localName === 'hueOff') h.h += num(m, 'val', 0) / 21600000; else h.h = num(m, 'val', 0) / 21600000;
          h.l = clamp01(h.l); h.s = clamp01(h.s);
          Object.assign(c, hsl2rgb(h)); break;
        }
        case 'shade': c.r = toSrgb(toLin(c.r) * v); c.g = toSrgb(toLin(c.g) * v); c.b = toSrgb(toLin(c.b) * v); break;
        case 'tint': c.r = toSrgb(toLin(c.r) * v + 1 - v); c.g = toSrgb(toLin(c.g) * v + 1 - v); c.b = toSrgb(toLin(c.b) * v + 1 - v); break;
        case 'inv': c.r = 255 - c.r; c.g = 255 - c.g; c.b = 255 - c.b; break;
        case 'gray': { const y = Math.round(0.299 * c.r + 0.587 * c.g + 0.114 * c.b); c.r = c.g = c.b = y; break; }
        case 'comp': { const h = rgb2hsl(c); h.h = (h.h + 0.5) % 1; Object.assign(c, hsl2rgb(h)); break; }
      }
    }
    return c;
  }
  function media(ctx, id) {
    const r = ctx.rels && ctx.rels.get(id);
    if (!r) return '';
    if (r.external) { warning('Vidéo ou image liée hors du fichier (non intégrée) : à intégrer dans PowerPoint', ctx.n); return ''; }
    return url(r.target);
  }

  /* ----- remplissages, traits, effets ----- */
  function fill(ctx, holder, ph) {
    if (!holder) return undefined;
    for (const c of kids(holder)) {
      switch (c.localName) {
        case 'noFill': return { type: 'none' };
        case 'solidFill': { const k = color(ctx, c, ph); return k ? { type: 'solid', c: k } : { type: 'none' }; }
        case 'gradFill': {
          const stops = kids(kid(c, 'gsLst'), 'gs').map(g => ({ pos: num(g, 'pos', 0) / 1e5, c: color(ctx, g, ph) || { r: 0, g: 0, b: 0, a: 1 } })).sort((a, b) => a.pos - b.pos);
          const lin = kid(c, 'lin'), pth = kid(c, 'path');
          return { type: 'grad', stops, ang: lin ? num(lin, 'ang', 0) / 60000 : 90, scaled: bool(lin, 'scaled', false), path: pth ? attr(pth, 'path', 'circle') : null, ftr: pth && kid(pth, 'fillToRect') ? { l: num(kid(pth, 'fillToRect'), 'l', 0) / 1e5, t: num(kid(pth, 'fillToRect'), 't', 0) / 1e5, r: num(kid(pth, 'fillToRect'), 'r', 0) / 1e5, b: num(kid(pth, 'fillToRect'), 'b', 0) / 1e5 } : null, rotWithShape: bool(c, 'rotWithShape', true) };
        }
        case 'blipFill': return blipFill(ctx, c);
        case 'pattFill': { const fg = color(ctx, kid(c, 'fgClr'), ph), bg = color(ctx, kid(c, 'bgClr'), ph); warning('Motif (remplissage à trame) remplacé par une couleur unie', ctx.n); return fg ? { type: 'solid', c: { r: (fg.r + (bg ? bg.r : 255)) >> 1, g: (fg.g + (bg ? bg.g : 255)) >> 1, b: (fg.b + (bg ? bg.b : 255)) >> 1, a: fg.a } } : { type: 'none' }; }
        case 'grpFill': return { type: 'grp' };
      }
    }
    return undefined;
  }
  function blipFill(ctx, bf) {
    const blip = kid(bf, 'blip');
    if (!blip) return { type: 'none' };
    let u = media(ctx, rid(blip, 'embed') || rid(blip, 'link'));
    // image vectorielle (SVG) à côté de l'image PNG de secours
    for (const e of blip.getElementsByTagNameNS('*', 'svgBlip')) { const s = media(ctx, rid(e, 'embed')); if (s) u = s; }
    const src = kid(bf, 'srcRect');
    const crop = src ? { l: num(src, 'l', 0) / 1e5, t: num(src, 't', 0) / 1e5, r: num(src, 'r', 0) / 1e5, b: num(src, 'b', 0) / 1e5 } : null;
    const f = { type: 'blip', url: u, crop, alpha: 1, filters: [] };
    const fr = path1(bf, 'stretch', 'fillRect');
    if (fr) f.fillRect = { l: num(fr, 'l', 0) / 1e5, t: num(fr, 't', 0) / 1e5, r: num(fr, 'r', 0) / 1e5, b: num(fr, 'b', 0) / 1e5 };
    const tile = kid(bf, 'tile');
    if (tile) f.tile = { sx: num(tile, 'sx', 1e5) / 1e5, sy: num(tile, 'sy', 1e5) / 1e5, tx: num(tile, 'tx', 0), ty: num(tile, 'ty', 0) };
    for (const m of kids(blip)) {
      switch (m.localName) {
        case 'alphaModFix': f.alpha = num(m, 'amt', 1e5) / 1e5; break;
        case 'grayscl': f.filters.push('grayscale(1)'); break;
        case 'lum': { const b = num(m, 'bright', 0) / 1e5, c = num(m, 'contrast', 0) / 1e5; if (b) f.filters.push(`brightness(${1 + b})`); if (c) f.filters.push(`contrast(${1 + c})`); break; }
        case 'duotone': f.filters.push('grayscale(1)'); warning('Effet bichromie d’une image simplifié en noir et blanc', ctx.n); break;
        case 'biLevel': f.filters.push('grayscale(1) contrast(10)'); break;
        case 'extLst':
          for (const ie of m.getElementsByTagNameNS('*', 'imgEffect')) for (const x of kids(ie)) {
            if (x.localName === 'brightnessContrast') { const b = num(x, 'bright', 0) / 1e5, c = num(x, 'contrast', 0) / 1e5; if (b) f.filters.push(`brightness(${1 + b})`); if (c) f.filters.push(`contrast(${1 + c})`); }
            else if (x.localName === 'saturation') f.filters.push(`saturate(${num(x, 'sat', 1e5) / 1e5})`);
            else if (x.localName === 'colorTemperature') {} // trop discret pour être reproduit
            else if (x.localName === 'artisticBlur') f.filters.push(`blur(${Math.max(1, num(x, 'radius', 10) / 4)}px)`);
            else if (x.localName === 'backgroundRemoval') warning('Arrière-plan supprimé d’une image (PowerPoint) : image affichée entière', ctx.n);
            else warning('Effet artistique d’une image non reproduit', ctx.n);
          }
          break;
      }
    }
    return f;
  }
  function line(ctx, ln, ph) {
    if (!ln) return undefined;
    const f = fill(ctx, ln, ph);
    const o = {};
    if (ln.hasAttribute('w')) o.w = num(ln, 'w', 9525);
    if (f) o.fill = f;
    const d = kid(ln, 'prstDash'); if (d) o.dash = attr(d, 'val', 'solid');
    const cd = kid(ln, 'custDash'); if (cd) o.dash = kids(cd, 'ds').map(s => [num(s, 'd', 1e5) / 1e5, num(s, 'sp', 1e5) / 1e5]);
    if (ln.hasAttribute('cap')) o.cap = attr(ln, 'cap');
    if (kid(ln, 'round')) o.join = 'round'; else if (kid(ln, 'bevel')) o.join = 'bevel'; else if (kid(ln, 'miter')) o.join = 'miter';
    for (const k of ['headEnd', 'tailEnd']) { const e = kid(ln, k); if (e && attr(e, 'type', 'none') !== 'none') o[k] = { type: attr(e, 'type'), w: attr(e, 'w', 'med'), len: attr(e, 'len', 'med') }; }
    if (kid(ln, 'noFill')) o.fill = { type: 'none' };
    return o;
  }
  function effects(ctx, el, ph) {
    const e = kid(el, 'effectLst');
    if (!e) return undefined;
    const o = {};
    const sh = kid(e, 'outerShdw');
    if (sh) o.shadow = { c: color(ctx, sh, ph) || { r: 0, g: 0, b: 0, a: 0.4 }, blur: num(sh, 'blurRad', 0), dist: num(sh, 'dist', 0), dir: num(sh, 'dir', 0) / 60000 };
    const gl = kid(e, 'glow');
    if (gl) o.glow = { c: color(ctx, gl, ph), rad: num(gl, 'rad', 0) };
    const se = kid(e, 'softEdge'); if (se) o.softEdge = num(se, 'rad', 0);
    if (kid(e, 'reflection')) warning('Reflet d’un objet non reproduit', ctx.n);
    if (kid(e, 'innerShdw')) warning('Ombre intérieure non reproduite', ctx.n);
    return o;
  }

  /* ----- styles de texte : propriétés de paragraphe et de caractère, avec héritage ----- */
  function rPrOf(ctx, rp, ph) {
    if (!rp) return {};
    const o = {};
    if (rp.hasAttribute('sz')) o.sz = num(rp, 'sz', 1800);
    if (rp.hasAttribute('b')) o.b = bool(rp, 'b', false);
    if (rp.hasAttribute('i')) o.i = bool(rp, 'i', false);
    if (rp.hasAttribute('u')) o.u = attr(rp, 'u', 'none');
    if (rp.hasAttribute('strike')) o.strike = attr(rp, 'strike', 'noStrike');
    if (rp.hasAttribute('cap')) o.cap = attr(rp, 'cap', 'none');
    if (rp.hasAttribute('spc')) o.spc = num(rp, 'spc', 0);
    if (rp.hasAttribute('baseline')) o.baseline = num(rp, 'baseline', 0);
    const f = fill(ctx, rp, ph); if (f) o.fill = f;
    const ln = kid(rp, 'ln'); if (ln) o.ln = line(ctx, ln, ph);
    const la = kid(rp, 'latin'); if (la && attr(la, 'typeface', '')) o.font = attr(la, 'typeface');
    const ea = kid(rp, 'ea'); if (ea && attr(ea, 'typeface', '') && !o.font) o.eaFont = attr(ea, 'typeface');
    const hl = kid(rp, 'highlight'); if (hl) o.hl = color(ctx, hl, ph);
    const ef = effects(ctx, rp, ph); if (ef && ef.shadow) o.shadow = ef.shadow;
    return o;
  }
  function pPrOf(ctx, pp, ph) {
    if (!pp) return {};
    const o = {};
    for (const k of ['marL', 'indent', 'defTabSz']) if (pp.hasAttribute(k)) o[k] = num(pp, k, 0);
    if (pp.hasAttribute('algn')) o.algn = attr(pp, 'algn');
    if (pp.hasAttribute('rtl')) o.rtl = bool(pp, 'rtl', false);
    for (const k of ['lnSpc', 'spcBef', 'spcAft']) {
      const e = kid(pp, k);
      if (e) { const pc = kid(e, 'spcPct'), pt = kid(e, 'spcPts'); o[k] = pc ? { pct: num(pc, 'val', 1e5) / 1e5 } : pt ? { pts: num(pt, 'val', 0) / 100 } : undefined; }
    }
    if (kid(pp, 'buNone')) o.bu = { none: true };
    else if (kid(pp, 'buChar')) o.bu = { char: attr(kid(pp, 'buChar'), 'char', '•') };
    else if (kid(pp, 'buAutoNum')) o.bu = { auto: attr(kid(pp, 'buAutoNum'), 'type', 'arabicPeriod'), start: num(kid(pp, 'buAutoNum'), 'startAt', 1) };
    else if (kid(pp, 'buBlip')) o.bu = { char: '•' };
    if (kid(pp, 'buFont')) o.buFont = attr(kid(pp, 'buFont'), 'typeface');
    if (kid(pp, 'buClr')) o.buClr = color(ctx, kid(pp, 'buClr'), ph);
    if (kid(pp, 'buClrTx')) o.buClr = null;
    if (kid(pp, 'buSzPct')) o.buSz = num(kid(pp, 'buSzPct'), 'val', 1e5) / 1e5;
    if (kid(pp, 'buSzPts')) o.buSzPts = num(kid(pp, 'buSzPts'), 'val', 0) / 100;
    const tabs = kid(pp, 'tabLst'); if (tabs) o.tabs = kids(tabs, 'tab').map(t => ({ pos: num(t, 'pos', 0), algn: attr(t, 'algn', 'l') })).sort((a, b) => a.pos - b.pos);
    const d = kid(pp, 'defRPr'); if (d) o.def = rPrOf(ctx, d, ph);
    return o;
  }
  // niveaux d'une liste de styles (lstStyle, titleStyle, bodyStyle, defaultTextStyle…) : lvl1pPr … lvl9pPr
  function lvls(ctx, ls, ph) {
    if (!ls) return null;
    const out = [];
    const dflt = kid(ls, 'defPPr');
    for (let i = 1; i <= 9; i++) { const e = kid(ls, `lvl${i}pPr`); out.push(e ? pPrOf(ctx, e, ph) : null); }
    if (dflt) out.def = pPrOf(ctx, dflt, ph);
    return out;
  }

  /* ----- géométrie : position et taille d'un objet ----- */
  function xfrmOf(spPr) {
    const x = kid(spPr, 'xfrm');
    if (!x) return null;
    const off = kid(x, 'off'), ext = kid(x, 'ext');
    return { x: num(off, 'x', 0), y: num(off, 'y', 0), w: num(ext, 'cx', 0), h: num(ext, 'cy', 0), rot: num(x, 'rot', 0) / 60000, flipH: bool(x, 'flipH', false), flipV: bool(x, 'flipV', false), chOff: kid(x, 'chOff') ? { x: num(kid(x, 'chOff'), 'x', 0), y: num(kid(x, 'chOff'), 'y', 0) } : null, chExt: kid(x, 'chExt') ? { w: num(kid(x, 'chExt'), 'cx', 0), h: num(kid(x, 'chExt'), 'cy', 0) } : null };
  }
  function geomOf(spPr) {
    const pg = kid(spPr, 'prstGeom');
    if (pg) { const av = {}; for (const g of kids(kid(pg, 'avLst'), 'gd')) av[attr(g, 'name')] = attr(g, 'fmla'); return { prst: attr(pg, 'prst', 'rect'), av }; }
    const cg = kid(spPr, 'custGeom');
    if (cg) {
      const g = { cust: true, av: [], gd: [], paths: [] };
      for (const x of kids(kid(cg, 'avLst'), 'gd')) g.av.push([attr(x, 'name'), attr(x, 'fmla')]);
      for (const x of kids(kid(cg, 'gdLst'), 'gd')) g.gd.push([attr(x, 'name'), attr(x, 'fmla')]);
      const rc = kid(cg, 'rect'); if (rc) g.rect = [attr(rc, 'l'), attr(rc, 't'), attr(rc, 'r'), attr(rc, 'b')];
      for (const p of kids(kid(cg, 'pathLst'), 'path')) {
        const P = { fill: attr(p, 'fill', 'norm'), stroke: attr(p, 'stroke', 'true'), c: [] };
        if (p.hasAttribute('w')) P.w = attr(p, 'w'); if (p.hasAttribute('h')) P.h = attr(p, 'h');
        for (const c of kids(p)) {
          const pts = kids(c, 'pt').map(t => [attr(t, 'x'), attr(t, 'y')]).flat();
          if (c.localName === 'moveTo') P.c.push(['M', ...pts]);
          else if (c.localName === 'lnTo') P.c.push(['L', ...pts]);
          else if (c.localName === 'cubicBezTo') P.c.push(['C', ...pts]);
          else if (c.localName === 'quadBezTo') P.c.push(['Q', ...pts]);
          else if (c.localName === 'arcTo') P.c.push(['A', attr(c, 'wR'), attr(c, 'hR'), attr(c, 'stAng'), attr(c, 'swAng')]);
          else if (c.localName === 'close') P.c.push(['Z']);
        }
        g.paths.push(P);
      }
      return g;
    }
    return null;
  }

  /* ----- texte d'un objet ----- */
  function bodyPrOf(bp) {
    if (!bp) return {};
    const o = {};
    for (const k of ['lIns', 'tIns', 'rIns', 'bIns', 'rot']) if (bp.hasAttribute(k)) o[k] = num(bp, k, 0);
    for (const k of ['anchor', 'wrap', 'vert']) if (bp.hasAttribute(k)) o[k] = attr(bp, k);
    if (bp.hasAttribute('anchorCtr')) o.anchorCtr = bool(bp, 'anchorCtr', false);
    if (bp.hasAttribute('numCol')) o.numCol = num(bp, 'numCol', 1);
    if (bp.hasAttribute('upright')) o.upright = bool(bp, 'upright', false);
    const na = kid(bp, 'normAutofit');
    if (na) o.autofit = { scale: num(na, 'fontScale', 1e5) / 1e5, lnRed: num(na, 'lnSpcReduction', 0) / 1e5 };
    if (kid(bp, 'spAutoFit')) o.autofit = { sp: true };
    if (kid(bp, 'noAutofit')) o.autofit = { none: true };
    const pw = kid(bp, 'prstTxWarp');
    if (pw && attr(pw, 'prst', 'textNoShape') !== 'textNoShape') o.warp = attr(pw, 'prst');
    return o;
  }
  function textOf(ctx, txBody, chain, slideNo) {
    if (!txBody) return null;
    const own = lvls(ctx, kid(txBody, 'lstStyle'));
    const levels = [own, ...chain.levels];
    const paras = [];
    let any = false;
    for (const p of kids(txBody, 'p')) {
      const pp = kid(p, 'pPr');
      const lvl = Math.min(8, num(pp, 'lvl', 0));
      // propriétés du paragraphe : de la plus générale à la plus précise
      const P = {};
      const R = {};
      for (let i = levels.length - 1; i >= 0; i--) {
        const L = levels[i]; if (!L) continue;
        for (const src of [L.def, L[lvl]]) if (src) { const { def, ...rest } = src; Object.assign(P, rest); if (def) Object.assign(R, def); }
      }
      const mine = pPrOf(ctx, pp);
      { const { def, ...rest } = mine; Object.assign(P, rest); if (def) Object.assign(R, def); }
      const runs = [];
      for (const r of kids(p)) {
        if (r.localName === 'r' || r.localName === 'fld') {
          let t = (kid(r, 't') && kid(r, 't').textContent) || '';
          if (r.localName === 'fld' && /slidenum/i.test(attr(r, 'type', ''))) t = String(slideNo || t);
          runs.push(Object.assign({}, R, rPrOf(ctx, kid(r, 'rPr')), { t }));
          if (t.trim()) any = true;
        } else if (r.localName === 'br') runs.push(Object.assign({}, R, rPrOf(ctx, kid(r, 'rPr')), { br: true, t: '' }));
      }
      const end = Object.assign({}, R, rPrOf(ctx, kid(p, 'endParaRPr')));
      paras.push({ p: P, runs, end, lvl });
    }
    return { paras, any };
  }

  /* ----- un objet de l'arbre (forme, image, groupe, tableau…) ----- */
  async function shapeList(ctx, tree, inherit, slideNo, isLayer) {
    const out = [];
    for (const c of kids(tree)) await one(ctx, c, inherit, slideNo, isLayer, out, null);
    return out;
  }
  // gt : transformation du groupe parent (fonction qui place un rectangle enfant dans la diapo)
  async function one(ctx, el, inherit, slideNo, isLayer, out, gt, parents = []) {
    const name = el.localName;
    if (!['sp', 'pic', 'grpSp', 'cxnSp', 'graphicFrame', 'contentPart'].includes(name)) return;
    const nv = kid(el, 'nvSpPr') || kid(el, 'nvPicPr') || kid(el, 'nvGrpSpPr') || kid(el, 'nvCxnSpPr') || kid(el, 'nvGraphicFramePr');
    const cNv = kid(nv, 'cNvPr');
    const id = attr(cNv, 'id', ''), nm = attr(cNv, 'name', '');
    if (bool(cNv, 'hidden', false)) return;
    const ph = path1(nv, 'nvPr', 'ph');
    if (isLayer && ph) return;   // espaces réservés des masques et dispositions : jamais dessinés en diaporama
    if (name === 'contentPart') { warning('Encre (dessin à main levée) non reproduite', slideNo); return; }
    const spPr = kid(el, 'spPr') || kid(el, 'grpSpPr');
    // héritage des espaces réservés : disposition puis masque
    let lph = null, mph = null;
    if (ph && inherit) { lph = findPh(inherit.layout && inherit.layout.ph, ph, false); mph = findPh(inherit.master.ph, ph, true); }
    let xf = xfrmOf(spPr);
    if (name === 'graphicFrame') xf = xfrmOf(el);   // p:xfrm directement dans l'objet
    if (!xf && lph) xf = xfrmOf(kid(lph, 'spPr'));
    if (!xf && mph) xf = xfrmOf(kid(mph, 'spPr'));
    if (!xf) { if (name !== 'grpSp') return; xf = { x: 0, y: 0, w: 0, h: 0, rot: 0 }; }
    let box = { x: xf.x, y: xf.y, w: xf.w, h: xf.h, rot: xf.rot || 0, flipH: !!xf.flipH, flipV: !!xf.flipV };
    if (gt) box = gt(box);
    const base = { id, name: nm, x: box.x, y: box.y, w: box.w, h: box.h, rot: box.rot, flipH: box.flipH, flipV: box.flipV, parents };
    if (attr(cNv, 'descr', '')) base.descr = attr(cNv, 'descr');
    const hl = kid(cNv, 'hlinkClick'); if (hl) base.link = true;

    if (name === 'grpSp') {
      const ch = xf.chOff || { x: 0, y: 0 }, ce = xf.chExt || { w: xf.w, h: xf.h };
      const sx = ce.w ? xf.w / ce.w : 1, sy = ce.h ? xf.h / ce.h : 1;
      const g = box, cx = g.x + g.w / 2, cy = g.y + g.h / 2, a = (g.rot || 0) * Math.PI / 180;
      const inner = b => {
        // enfant : repère du groupe -> diapo (échelle, miroir, rotation autour du centre du groupe)
        let x = xf.x + (b.x - ch.x) * sx, y = xf.y + (b.y - ch.y) * sy, w = b.w * sx, h = b.h * sy;
        // la boîte du groupe a déjà été placée par gt : on refait la même chose pour l'enfant
        const pre = { x, y, w, h };
        let ccx = pre.x + pre.w / 2, ccy = pre.y + pre.h / 2;
        // décalage dû au placement du groupe (gt) : centre du groupe avant/après
        const gx0 = xf.x + xf.w / 2, gy0 = xf.y + xf.h / 2;
        let dx = ccx - gx0, dy = ccy - gy0;
        if (g.flipH) dx = -dx;
        if (g.flipV) dy = -dy;
        const rx = dx * Math.cos(a) - dy * Math.sin(a), ry = dx * Math.sin(a) + dy * Math.cos(a);
        const nw = w * (g.w / (xf.w || 1)), nh = h * (g.h / (xf.h || 1));
        const ncx = cx + rx * (g.w / (xf.w || 1)), ncy = cy + ry * (g.h / (xf.h || 1));
        return { x: ncx - nw / 2, y: ncy - nh / 2, w: nw, h: nh, rot: (b.rot || 0) * ((g.flipH !== g.flipV) ? -1 : 1) + (g.rot || 0), flipH: !!b.flipH !== !!g.flipH, flipV: !!b.flipV !== !!g.flipV };
      };
      const gfill = fill(ctx, spPr);
      const before = out.length;
      for (const c of kids(el)) await one(ctx, c, inherit, slideNo, isLayer, out, inner, parents.concat(id));
      for (let i = before; i < out.length; i++) if (out[i].fill && out[i].fill.type === 'grp') out[i].fill = gfill || { type: 'none' };
      return;
    }

    // style de l'objet (références au thème)
    const st = kid(el, 'style');
    const refColor = r => r ? color(ctx, r) : null;
    const styleFill = () => { const r = st && kid(st, 'fillRef'); if (!r) return undefined; const i = num(r, 'idx', 0); if (!i) return { type: 'none' }; const list = i >= 1000 ? ctx.theme.bgFills : ctx.theme.fills; const f = list[(i >= 1000 ? i - 1000 : i) - 1]; if (!f) return undefined; const holder = { localName: 'x' }; return fill(ctx, wrapOne(f), refColor(r)); };
    const styleLine = () => { const r = st && kid(st, 'lnRef'); if (!r) return undefined; const i = num(r, 'idx', 0); if (!i) return undefined; const l = ctx.theme.lines[i - 1]; return l ? line(ctx, l, refColor(r)) : undefined; };
    const styleFont = () => { const r = st && kid(st, 'fontRef'); if (!r) return null; return { font: attr(r, 'idx', 'minor') === 'major' ? '+mj-lt' : '+mn-lt', fill: refColor(r) ? { type: 'solid', c: refColor(r) } : undefined }; };

    if (name === 'pic') {
      const bf = kid(el, 'blipFill');
      const img = blipFill(ctx, bf);
      const o = Object.assign(base, { kind: 'pic', img, geom: geomOf(spPr) || { prst: 'rect', av: {} }, line: line(ctx, kid(spPr, 'ln')) || styleLine(), fx: effects(ctx, spPr) });
      const vf = path1(nv, 'nvPr', 'videoFile') || path1(nv, 'nvPr', 'audioFile');
      let mediaUrl = '';
      for (const m of el.getElementsByTagNameNS('*', 'media')) { const u = media(ctx, rid(m, 'embed')); if (u) mediaUrl = u; }
      if (!mediaUrl && vf) mediaUrl = media(ctx, rid(vf, 'link'));
      if (mediaUrl || vf) {
        o.kind = vf && vf.localName === 'audioFile' ? 'audio' : 'video';
        o.media = { url: mediaUrl };
        const m14 = el.getElementsByTagNameNS('*', 'media')[0];
        if (m14) {
          const tr = kid(m14, 'trim'); if (tr) o.media.trim = { st: num(tr, 'st', 0), end: num(tr, 'end', 0) };
          const fd = kid(m14, 'fade'); if (fd) o.media.fade = { in: num(fd, 'in', 0), out: num(fd, 'out', 0) };
        }
        if (!mediaUrl) warning('Vidéo introuvable dans le fichier', slideNo);
        else if (!/\.(mp4|m4v|mov|webm|mp3|m4a|wav|aac|ogg)$/i.test(mediaUrl)) warning('Format de vidéo ou de son peut-être illisible (' + mediaUrl.split('.').pop() + ') : préfère le MP4 (H.264)', slideNo);
      }
      if (lph && !kid(spPr, 'xfrm')) {}   // place héritée déjà prise
      out.push(o);
      return;
    }

    if (name === 'graphicFrame') {
      const gd = path1(el, 'graphic', 'graphicData');
      const uri = attr(gd, 'uri', '');
      const tbl = kid(gd, 'tbl');
      if (tbl) { out.push(Object.assign(base, { kind: 'table', table: tableOf(ctx, tbl, slideNo) })); return; }
      if (/diagram/.test(uri)) {
        // SmartArt : PowerPoint garde un dessin tout fait (drawingN.xml) que nous reprenons
        const rel = kid(gd, 'relIds');
        let drawing = null;
        for (const r of ctx.rels.values()) if (r.type === 'diagramDrawing' && (!rel || true)) drawing = drawing || r.target;
        const dmId = rel ? rid(rel, 'dm') : '';
        // le dessin associé est indiqué dans les données du diagramme (dsp:dataModelExt relId)
        if (dmId && ctx.rels.get(dmId)) {
          const dm = await xml(ctx.rels.get(dmId).target);
          const ext = dm && dm.getElementsByTagNameNS('*', 'dataModelExt')[0];
          const drel = ext && ext.getAttribute('relId');
          if (drel && ctx.rels.get(drel)) drawing = ctx.rels.get(drel).target;
        }
        const d = drawing && await xml(drawing);
        const tree = d && d.getElementsByTagNameNS('*', 'spTree')[0];
        if (tree) {
          const drels = await rels(drawing);
          const dctx = Object.assign({}, ctx, { rels: drels });
          const gtx = b => { const r = { x: b.x + box.x, y: b.y + box.y, w: b.w, h: b.h, rot: b.rot, flipH: b.flipH, flipV: b.flipV }; return gt ? gt(r) : r; };
          for (const c of kids(tree)) await one(dctx, c, null, slideNo, false, out, gtx, parents.concat(id));
          // un SmartArt animé est animé en bloc
          return;
        }
        warning('SmartArt sans dessin enregistré : non affiché', slideNo);
        return;
      }
      if (/chart/.test(uri)) { warning('Graphique (diagramme de données) non reproduit : colle-le en image dans PowerPoint', slideNo); out.push(Object.assign(base, { kind: 'missing', label: 'Graphique' })); return; }
      if (/ole/.test(uri)) {
        // objet incorporé : son image d'aperçu
        const pic = gd.getElementsByTagNameNS('*', 'pic')[0];
        if (pic) { const img = blipFill(ctx, kid(pic, 'blipFill')); out.push(Object.assign(base, { kind: 'pic', img, geom: { prst: 'rect', av: {} } })); return; }
      }
      warning('Objet inconnu non reproduit', slideNo);
      return;
    }

    // forme (sp) ou connecteur (cxnSp)
    const ownFill = fill(ctx, spPr);
    let f = ownFill;
    if (f === undefined && lph) f = fill(ctx, kid(lph, 'spPr'));
    if (f === undefined && mph) f = fill(ctx, kid(mph, 'spPr'));
    if (f === undefined) f = styleFill();
    let ln = line(ctx, kid(spPr, 'ln'));
    const sl = styleLine();
    if (sl) ln = Object.assign({}, sl, ln || {});
    if (!ln && lph) ln = line(ctx, kid(kid(lph, 'spPr'), 'ln'));
    let geom = geomOf(spPr) || (lph && geomOf(kid(lph, 'spPr'))) || (mph && geomOf(kid(mph, 'spPr'))) || { prst: 'rect', av: {} };
    if (name === 'cxnSp' && geom.prst === 'rect') geom = { prst: 'line', av: {} };
    let fx = effects(ctx, spPr);
    if (!fx && st) { const r = kid(st, 'effectRef'); const i = r ? num(r, 'idx', 0) : 0; const e = i && ctx.theme.effects[i - 1]; if (e) { const ef = effects(ctx, e, refColor(r)); if (ef && (ef.shadow || ef.glow)) fx = ef; } }
    // texte : chaîne d'héritage des styles
    const txb = kid(el, 'txBody');
    let text = null, bodyPr = {};
    if (txb) {
      const levels = [];
      const phType = ph ? attr(ph, 'type', 'body') : null;
      if (lph) levels.push(lvls(ctx, path1(lph, 'txBody', 'lstStyle')));
      if (mph) levels.push(lvls(ctx, path1(mph, 'txBody', 'lstStyle')));
      if (ph && inherit) {
        const tx = inherit.master.tx;
        const k = phType === 'title' || phType === 'ctrTitle' ? 'titleStyle' : ['body', 'subTitle', 'obj', null].includes(phType) || !phType ? 'bodyStyle' : 'otherStyle';
        levels.push(lvls(ctx, kid(tx, k)));
      } else if (inherit === null) {
        // SmartArt : styles par défaut seulement
      }
      // police et couleur du style de la forme (formes insérées : texte blanc sur fond accent…)
      const sf = styleFont();
      if (sf) { const a = []; a.def = { def: Object.assign({ font: sf.font }, sf.fill ? { fill: sf.fill } : {}) }; levels.push(a); }
      levels.push(lvls(ctx, defaultTextStyle));
      text = textOf(ctx, txb, { levels }, slideNo);
      const bps = [mph && path1(mph, 'txBody', 'bodyPr'), lph && path1(lph, 'txBody', 'bodyPr'), kid(txb, 'bodyPr')];
      for (const b of bps) if (b) Object.assign(bodyPr, bodyPrOf(b));
      if (bodyPr.warp) warning('Texte déformé (WordArt) affiché droit', slideNo);
      if (bodyPr.numCol > 1) warning('Texte en plusieurs colonnes affiché en une seule', slideNo);
      if (text && !text.any) text = null;
    }
    // espace réservé vide : PowerPoint ne le montre pas en diaporama
    if (ph && !text && (!f || f.type === 'none') && (!ln || !ln.fill || ln.fill.type === 'none')) return;
    if (ph && ownFill === undefined && !text && !kid(spPr, 'ln')) return;
    out.push(Object.assign(base, { kind: 'shape', geom, fill: f, line: ln, fx, text, body: bodyPr, ph: ph ? attr(ph, 'type', 'body') : null }));
  }
  // un élément de remplissage seul doit être « contenu » pour fill()
  function wrapOne(e) { const d = e.ownerDocument.createElement('w'); d.appendChild(e.cloneNode(true)); return d; }

  /* ----- tableaux ----- */
  function tableOf(ctx, tbl, slideNo) {
    const grid = kids(kid(tbl, 'tblGrid'), 'gridCol').map(g => num(g, 'w', 0));
    const tp = kid(tbl, 'tblPr');
    const flags = { firstRow: bool(tp, 'firstRow', false), lastRow: bool(tp, 'lastRow', false), firstCol: bool(tp, 'firstCol', false), lastCol: bool(tp, 'lastCol', false), bandRow: bool(tp, 'bandRow', false), bandCol: bool(tp, 'bandCol', false) };
    const sid = (kid(tp, 'tableStyleId') && kid(tp, 'tableStyleId').textContent.trim()) || '';
    let style = null;
    if (sid && tableStyles) for (const s of kids(tableStyles, 'tblStyle')) if (attr(s, 'styleId') === sid) style = s;
    if (sid && !style) warning('Style de tableau intégré de PowerPoint simplifié', slideNo);
    const tblFill = fill(ctx, tp);
    const rows = [];
    const trs = kids(tbl, 'tr');
    trs.forEach((tr, ri) => {
      const cells = [];
      kids(tr, 'tc').forEach((tc, ci) => {
        const pr = kid(tc, 'tcPr');
        // parties du style qui s'appliquent à cette cellule (de la plus générale à la plus précise)
        const parts = ['wholeTbl'];
        if (flags.bandRow) parts.push(((ri - (flags.firstRow ? 1 : 0)) % 2 === 0) ? 'band1H' : 'band2H');
        if (flags.bandCol) parts.push(((ci - (flags.firstCol ? 1 : 0)) % 2 === 0) ? 'band1V' : 'band2V');
        if (flags.firstCol && ci === 0) parts.push('firstCol');
        if (flags.lastCol && ci === grid.length - 1) parts.push('lastCol');
        if (flags.lastRow && ri === trs.length - 1) parts.push('lastRow');
        if (flags.firstRow && ri === 0) parts.push('firstRow');
        let cf, txc, txb, borders = {};
        for (const p of parts) {
          const s = style && kid(style, p); if (!s) continue;
          const tcs = kid(s, 'tcStyle'), txs = kid(s, 'tcTxStyle');
          const ff = tcs && kid(tcs, 'fill'); if (ff) { const v = fill(ctx, ff); if (v) cf = v; }
          const fr = tcs && kid(tcs, 'fillRef'); if (fr && !ff) { const c = color(ctx, fr); if (c) cf = { type: 'solid', c }; }
          if (txs) { const c = color(ctx, txs); if (c) txc = c; if (txs.hasAttribute('b')) txb = attr(txs, 'b') === 'on'; }
          const bd = tcs && kid(tcs, 'tcBdr');
          if (bd) for (const b of kids(bd)) { const l = kid(b, 'ln'); if (l) borders[b.localName] = line(ctx, l); }
        }
        const own = fill(ctx, pr); if (own) cf = own;
        const bo = {};
        for (const [k, s] of [['lnL', 'left'], ['lnR', 'right'], ['lnT', 'top'], ['lnB', 'bottom']]) {
          const l = kid(pr, k);
          bo[s] = l ? line(ctx, l) : borders[s] || (s === 'top' || s === 'bottom' ? borders.insideH : borders.insideV) || null;
        }
        const levels = [lvls(ctx, defaultTextStyle)];
        const extra = {}; if (txc) extra.fill = { type: 'solid', c: txc }; if (txb != null) extra.b = txb;
        const cellLv = []; cellLv.def = { def: extra };
        const text = textOf(ctx, kid(tc, 'txBody'), { levels: [cellLv, ...levels] }, slideNo);
        cells.push({
          text, fill: cf, border: bo, span: num(tc, 'gridSpan', 1), rspan: num(tc, 'rowSpan', 1), hMerge: bool(tc, 'hMerge', false), vMerge: bool(tc, 'vMerge', false),
          body: { lIns: num(pr, 'marL', 91440), rIns: num(pr, 'marR', 91440), tIns: num(pr, 'marT', 45720), bIns: num(pr, 'marB', 45720), anchor: attr(pr, 'anchor', 't') },
        });
      });
      rows.push({ h: num(tr, 'h', 0), cells });
    });
    return { grid, rows, fill: tblFill };
  }

  /* ----- fond ----- */
  async function bgOf(ctx, bg) {
    if (!bg) return null;
    const pr = kid(bg, 'bgPr');
    if (pr) return fill(ctx, pr) || null;
    const ref = kid(bg, 'bgRef');
    if (ref) {
      const i = num(ref, 'idx', 0), c = color(ctx, ref);
      if (i >= 1001) { const f = ctx.theme.bgFills[i - 1001]; if (f) return fill(ctx, wrapOne(f), c); }
      else if (i > 0) { const f = ctx.theme.fills[i - 1]; if (f) return fill(ctx, wrapOne(f), c); }
      return c ? { type: 'solid', c } : null;
    }
    return null;
  }

  /* ----- transition ----- */
  function transitionOf(slideEl, n) {
    const t = kid(slideEl, 'transition');
    if (!t) return { type: 'cut', dur: 0, advClick: true };
    const spd = attr(t, 'spd', 'fast');
    let dur = { slow: 1000, med: 750, fast: 500 }[spd] || 500;
    const d14 = t.getAttribute('p14:dur') || t.getAttributeNS('http://schemas.microsoft.com/office/powerpoint/2010/main', 'dur');
    if (d14) dur = +d14;
    const o = { type: 'cut', dur, advClick: bool(t, 'advClick', true) };
    if (t.hasAttribute('advTm')) o.advTm = num(t, 'advTm', 0);
    const e = kids(t).find(c => c.localName !== 'sndAc' && c.localName !== 'extLst');
    if (!e) { o.type = 'cut'; return o; }
    const k = e.localName;
    o.dir = attr(e, 'dir', null);
    const simple = { fade: 'fade', cut: 'cut', push: 'push', wipe: 'wipe', split: 'split', cover: 'cover', pull: 'pull', zoom: 'zoom', morph: 'morph', dissolve: 'fade', randomBar: 'fade', circle: 'circle', diamond: 'diamond', plus: 'plus', wedge: 'circle', wheel: 'circle', newsflash: 'zoom', strips: 'wipe', blinds: 'fade', checker: 'fade', comb: 'fade', random: 'fade', reveal: 'fade', flash: 'flash', prism: 'push', doors: 'split', window: 'split', ferris: 'push', gallery: 'push', conveyor: 'push', pan: 'push', glitter: 'fade', honeycomb: 'fade', vortex: 'fade', shred: 'fade', switch: 'push', flip: 'push', ripple: 'fade', flythrough: 'zoom', warp: 'zoom', curtains: 'split', wind: 'push', prstTrans: 'fade', fracture: 'fade', crush: 'fade', peelOff: 'pull', pageCurlDouble: 'pull', pageCurlSingle: 'pull', airplane: 'fade', origami: 'fade', vortexp: 'fade' };
    o.type = simple[k] || 'fade';
    if (k === 'fade' && bool(e, 'thruBlk', false)) o.type = 'fadeBlack';
    if (k === 'morph') o.morph = attr(e, 'option', 'byObject');
    if (k === 'split') { o.orient = attr(e, 'orient', 'horz'); o.inOut = attr(e, 'dir', 'out'); }
    if (k === 'zoom') o.inOut = attr(e, 'dir', 'in');
    if (!(k in simple) || (simple[k] !== k && !['dissolve', 'randomBar', 'cut'].includes(k)))
      warning(`Transition « ${k} » remplacée par une transition proche (${({ fade: 'fondu', push: 'poussée', zoom: 'zoom', split: 'fractionner', circle: 'cercle', pull: 'découvrir', wipe: 'balayage', flash: 'flash' })[o.type] || 'fondu'})`, n);
    return o;
  }

  /* ----- animations (p:timing) ----- */
  function timingOf(slideEl, n) {
    const tm = kid(slideEl, 'timing');
    const res = { steps: [], inter: [], media: {}, effects: [] };   // effects : chaque effet de la séquence principale (pour les désactiver dans Lanterne PPT)
    let inMain = false;
    if (!tm) return res;
    // nœud média (p:video / p:audio) : volume, boucle
    for (const v of [...tm.getElementsByTagNameNS('*', 'video'), ...tm.getElementsByTagNameNS('*', 'audio')]) {
      const mn = kid(v, 'cMediaNode'); if (!mn) continue;
      const tgt = path1(mn, 'tgtEl', 'spTgt'); if (!tgt) continue;
      const ctn = kid(mn, 'cTn');
      res.media[attr(tgt, 'spid')] = { vol: num(mn, 'vol', 1e5) / 1e5, mute: bool(mn, 'mute', false), loop: attr(ctn, 'repeatCount', '') === 'indefinite', fullScrn: bool(v, 'fullScrn', false), numSld: num(mn, 'numSld', 1) };
    }
    const delayOf = ctn => {
      let d = 0, click = false, auto = false, trig = null;
      for (const c of kids(kid(ctn, 'stCondLst'), 'cond')) {
        const dl = attr(c, 'delay', '0'), ev = attr(c, 'evt', '');
        if (dl === 'indefinite') { if (!ev) click = true; }
        else if (!ev) d = +dl || 0;
        if (ev === 'onBegin') auto = true;
        if (ev === 'onClick') { const t = path1(c, 'tgtEl', 'spTgt'); if (t) trig = attr(t, 'spid'); }
      }
      return { d, click: click && !auto, trig };
    };
    // comportements d'un nœud (récursif), temps absolu dans l'étape
    function collect(ctn, t0, list, eff) {
      for (const c of kids(kid(ctn, 'childTnLst'))) {
        const k = c.localName;
        if (k === 'par' || k === 'seq') {
          const ct = kid(c, 'cTn'); if (!ct) continue;
          const { d } = delayOf(ct);
          const e2 = ct.hasAttribute('presetClass') ? { cls: attr(ct, 'presetClass'), id: num(ct, 'presetID', 0), sub: num(ct, 'presetSubtype', 0), node: attr(ct, 'nodeType', ''), accel: num(ct, 'accel', 0) / 1e5, decel: num(ct, 'decel', 0) / 1e5, autoRev: bool(ct, 'autoRev', false), rep: attr(ct, 'repeatCount', '1000'), dur: attr(ct, 'dur', '') } : eff;
          if (e2 && e2 !== eff && inMain) { e2.fx = res.effects.length; res.effects.push({ fx: e2.fx, group: res.steps.length, cls: e2.cls, id: e2.id, node: e2.node, spid: null, dur: 0 }); }
          collect(ct, t0 + d, list, e2);
        } else {
          const bh = kid(c, 'cBhvr'); if (!bh) continue;
          const ct = kid(bh, 'cTn');
          const { d } = delayOf(ct);
          const tgt = path1(bh, 'tgtEl', 'spTgt');
          if (!tgt) continue;
          const durA = attr(ct, 'dur', '1');
          const dur = durA === 'indefinite' ? 0 : +durA || 0;
          const b = { spid: attr(tgt, 'spid'), t: t0 + d, dur, fill: attr(ct, 'fill', 'remove'), accel: num(ct, 'accel', 0) / 1e5 || (eff && eff.accel) || 0, decel: num(ct, 'decel', 0) / 1e5 || (eff && eff.decel) || 0, autoRev: bool(ct, 'autoRev', false) || !!(eff && eff.autoRev), rep: attr(ct, 'repeatCount', null), cls: eff ? eff.cls : '', kind: k };
          if (b.rep === 'indefinite') b.rep = Infinity; else b.rep = b.rep ? +b.rep / 1000 : 1;
          if (eff && eff.rep && eff.rep !== '1000') b.rep = eff.rep === 'indefinite' ? Infinity : +eff.rep / 1000;
          const tr = kid(tgt, 'txEl'); if (tr) { const pr = kid(tr, 'pRg'); b.para = pr ? [num(pr, 'st', 0), num(pr, 'end', 0)] : null; }
          if (eff && eff.fx != null) { b.fx = eff.fx; const fe = res.effects[eff.fx]; if (fe.spid == null) { fe.spid = b.spid; fe.para = b.para || null; } if (k === 'cmd' && !fe.cmd) fe.cmd = attr(c, 'cmd', ''); fe.dur = Math.max(fe.dur, dur); }
          const attrs = kids(kid(bh, 'attrNameLst'), 'attrName').map(a => a.textContent.trim());
          b.attrs = attrs;
          switch (k) {
            case 'set': { const to = kid(c, 'to'); const sv = to && kid(to, 'strVal'), fv = to && kid(to, 'fltVal'); b.to = sv ? attr(sv, 'val') : fv ? num(fv, 'val', 0) : null; break; }
            case 'anim': {
              b.calc = attr(c, 'calcmode', 'lin'); b.vt = attr(c, 'valueType', 'num');
              b.by = attr(c, 'by', null); b.from = attr(c, 'from', null); b.toA = attr(c, 'to', null);
              b.tav = kids(kid(c, 'tavLst'), 'tav').map(t => { const v = kid(t, 'val'); const sv = v && kid(v, 'strVal'), fv = v && kid(v, 'fltVal'); return { tm: attr(t, 'tm', null) === 'indefinite' ? null : num(t, 'tm', null), v: sv ? attr(sv, 'val') : fv ? num(fv, 'val', 0) : null, f: attr(t, 'fmla', '') }; });
              break;
            }
            case 'animEffect': b.tr = attr(c, 'transition', 'in'); b.filter = attr(c, 'filter', 'fade'); { const pr = attr(c, 'prLst', ''); if (pr) b.prLst = pr; } break;
            case 'animMotion': b.path = attr(c, 'path', ''); b.origin = attr(c, 'origin', 'parent'); b.rAng = num(c, 'rAng', 0); { const by = kid(c, 'by'), fr = kid(c, 'from'), to = kid(c, 'to'); if (by) b.byXY = [num(by, 'x', 0) / 1e5, num(by, 'y', 0) / 1e5]; if (fr) b.fromXY = [num(fr, 'x', 0) / 1e5, num(fr, 'y', 0) / 1e5]; if (to) b.toXY = [num(to, 'x', 0) / 1e5, num(to, 'y', 0) / 1e5]; } break;
            case 'animScale': { const by = kid(c, 'by'), fr = kid(c, 'from'), to = kid(c, 'to'); if (by) b.by = [num(by, 'x', 1e5) / 1e5, num(by, 'y', 1e5) / 1e5]; if (fr) b.from = [num(fr, 'x', 1e5) / 1e5, num(fr, 'y', 1e5) / 1e5]; if (to) b.to = [num(to, 'x', 1e5) / 1e5, num(to, 'y', 1e5) / 1e5]; break; }
            case 'animRot': b.by = num(c, 'by', 0) / 60000; if (c.hasAttribute('from')) b.from = num(c, 'from', 0) / 60000; if (c.hasAttribute('to')) b.to = num(c, 'to', 0) / 60000; break;
            case 'animClr': { const to = kid(c, 'to'); b.toC = to ? color(slideCtxNow, to) : null; break; }
            case 'cmd': b.cmd = attr(c, 'cmd', ''); b.ctype = attr(c, 'type', 'call'); break;
            case 'audio': case 'video': continue;
            default: unknownBeh.add(k); continue;
          }
          list.push(b);
        }
      }
    }
    const unknownBeh = new Set();
    for (const seq of tm.getElementsByTagNameNS('*', 'seq')) {
      const ct = kid(seq, 'cTn'); if (!ct) continue;
      const nt = attr(ct, 'nodeType', '');
      if (nt === 'mainSeq') {
        for (const par of kids(kid(ct, 'childTnLst'), 'par')) {
          const pc = kid(par, 'cTn');
          const { d, click } = delayOf(pc);
          const list = [];
          inMain = true; collect(pc, 0, list, null); inMain = false;
          res.steps.push({ click, delay: click ? 0 : d, items: list });
        }
      } else if (nt === 'interactiveSeq') {
        const trig = delayOf(ct).trig;
        const list = [];
        collect(ct, 0, list, null);
        res.inter.push({ trig, items: list });
      }
    }
    if (unknownBeh.size) warning('Effet d’animation non reproduit (' + [...unknownBeh].join(', ') + ')', n);
    return res;
  }
  let slideCtxNow = null;

  /* ----- notes du présentateur ----- */
  async function notesOf(rl) {
    for (const r of rl.values()) if (r.type === 'notesSlide') {
      const d = await xml(r.target); if (!d) return '';
      const parts = [];
      for (const sp of d.getElementsByTagNameNS('*', 'sp')) {
        const ph = sp.getElementsByTagNameNS('*', 'ph')[0];
        if (!ph || attr(ph, 'type', 'body') !== 'body') continue;
        for (const p of sp.getElementsByTagNameNS('*', 'p')) parts.push([...p.getElementsByTagNameNS('*', 't')].map(t => t.textContent).join(''));
      }
      return parts.join('\n').trim();
    }
    return '';
  }

  /* ----- diapos ----- */
  const ids = kids(kid(pres, 'sldIdLst'), 'sldId');
  const slides = [];
  let n = 0;
  for (const s of ids) {
    const r = presRels.get(rid(s, 'id'));
    if (!r) continue;
    n++;
    const p = r.target;
    const doc = await xml(p);
    if (!doc) { warning('Diapo illisible', n); continue; }
    const rl = await rels(p);
    let layout = null;
    for (const x of rl.values()) if (x.type === 'slideLayout') layout = await loadLayout(x.target);
    const master = layout ? layout.master : null;
    if (!master) { warning('Diapo sans masque', n); continue; }
    const ov = path1(doc, 'clrMapOvr', 'overrideClrMapping');
    const part = { rels: rl, clrMap: ov ? clrMapOf(ov) : null };
    const ctx = mkCtx(part, layout, master, n);
    slideCtxNow = ctx;
    const lctx = mkCtx({ rels: layout.rels, clrMap: null }, layout, master, n);
    const mctx = mkCtx({ rels: master.rels, clrMap: null }, null, master, n);
    // fond : diapo, sinon disposition, sinon masque
    let bg = await bgOf(ctx, path1(doc, 'cSld', 'bg'));
    if (!bg) bg = await bgOf(lctx, layout.bg);
    if (!bg) bg = await bgOf(mctx, master.bg);
    const showMaster = bool(doc, 'showMasterSp', true);
    const under = [];
    if (showMaster && layout.showMaster) under.push(...await shapeList(mctx, master.tree, null, n, true));
    if (showMaster) under.push(...await shapeList(lctx, layout.tree, null, n, true));
    under.forEach(e => { e.layer = true; e.id = 'm' + e.id; });
    const els = await shapeList(ctx, path1(doc, 'cSld', 'spTree'), { layout, master }, n, false);
    const title = (() => { for (const e of els) if ((e.ph === 'title' || e.ph === 'ctrTitle') && e.text) return e.text.paras.map(q => q.runs.map(x => x.br ? ' ' : x.t).join('')).join(' ').replace(/\s+/g, ' ').trim(); return ''; })();
    const tr = transitionOf(doc, n);
    const timing = timingOf(doc, n);
    slides.push({ n, hidden: attr(doc, 'show', '1') === '0', bg, els: under.concat(els), transition: tr, timing, notes: await notesOf(rl), title, name: attr(path1(doc, 'cSld'), 'name', '') });
    if (opt.progress) opt.progress(n, ids.length);
  }
  // polices utilisées (pour vérifier qu'elles sont là)
  const fonts = new Set();
  const theme0 = masters.size ? [...masters.values()][0].theme : null;
  const fontName = f => !f ? '' : f === '+mj-lt' || f === '+mj-ea' ? (theme0 && theme0.major) : f === '+mn-lt' || f === '+mn-ea' ? (theme0 && theme0.minor) : f;
  for (const s of slides) for (const e of s.els) {
    const add = t => { if (!t) return; for (const p of t.paras) { for (const r of p.runs) if (r.t.trim()) fonts.add(fontName(r.font || '+mn-lt')); if (p.p.bu && p.p.bu.char && p.p.buFont && p.runs.length) fonts.add(p.p.buFont); } };
    add(e.text);
    if (e.table) for (const row of e.table.rows) for (const c of row.cells) add(c.text);
  }
  fonts.delete(''); fonts.delete(undefined);
  const warnings = [...warn].map(([t, s]) => ({ text: t, slides: [...s].sort((a, b) => a - b) }));
  return { W, H, slides, fonts: [...fonts].sort(), embedded, warnings, themeFonts: theme0 ? { major: theme0.major, minor: theme0.minor } : { major: 'Calibri Light', minor: 'Calibri' } };
}

window.LanternePptx = { loadDeck };
})();
