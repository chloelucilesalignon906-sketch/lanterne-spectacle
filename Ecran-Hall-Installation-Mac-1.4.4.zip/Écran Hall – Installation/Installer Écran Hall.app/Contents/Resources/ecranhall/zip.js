'use strict';
// Lecture d'un fichier .pptx (zip) : liste des fichiers et extraction vers un dossier, sans module externe.
// Gère les zip64 (gros fichiers vidéo) ; méthodes « stocké » (0) et « deflate » (8).
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { pipeline } = require('stream/promises');

function readAt(fd, pos, len) {
  const b = Buffer.alloc(len);
  let got = 0;
  while (got < len) { const n = fs.readSync(fd, b, got, len - got, pos + got); if (!n) break; got += n; }
  return got === len ? b : b.subarray(0, got);
}
const u64 = (b, o) => Number(b.readBigUInt64LE(o));

// liste des fichiers du zip : [{ name, method, csize, size, off }]
function list(file) {
  const fd = fs.openSync(file, 'r');
  try {
    const size = fs.fstatSync(fd).size;
    const tailLen = Math.min(size, 65557 + 22);
    const tail = readAt(fd, size - tailLen, tailLen);
    let e = -1;
    for (let i = tail.length - 22; i >= 0; i--) if (tail.readUInt32LE(i) === 0x06054b50) { e = i; break; }
    if (e < 0) throw new Error('Ce fichier n’est pas un .pptx valide (zip illisible).');
    let count = tail.readUInt16LE(e + 10), cdSize = tail.readUInt32LE(e + 12), cdOff = tail.readUInt32LE(e + 16);
    // zip64 : localisateur juste avant la fin du répertoire
    if (e >= 20 && tail.readUInt32LE(e - 20) === 0x07064b50) {
      const z64 = u64(tail, e - 20 + 8);
      const r = readAt(fd, z64, 56);
      if (r.readUInt32LE(0) === 0x06064b50) { count = u64(r, 32); cdSize = u64(r, 40); cdOff = u64(r, 48); }
    }
    const cd = readAt(fd, cdOff, cdSize);
    const out = [];
    let p = 0;
    for (let k = 0; k < count && p + 46 <= cd.length; k++) {
      if (cd.readUInt32LE(p) !== 0x02014b50) break;
      const flags = cd.readUInt16LE(p + 8), method = cd.readUInt16LE(p + 10);
      let csize = cd.readUInt32LE(p + 20), usize = cd.readUInt32LE(p + 24);
      const nl = cd.readUInt16LE(p + 28), xl = cd.readUInt16LE(p + 30), cl = cd.readUInt16LE(p + 32);
      let off = cd.readUInt32LE(p + 42);
      const nameBuf = cd.subarray(p + 46, p + 46 + nl);
      const name = (flags & 0x800) ? nameBuf.toString('utf8') : nameBuf.toString('latin1');
      // champ zip64 : seules les valeurs à 0xFFFFFFFF y sont, dans l'ordre taille, taille compressée, position
      let x = p + 46 + nl;
      const xe = x + xl;
      while (x + 4 <= xe) {
        const id = cd.readUInt16LE(x), len = cd.readUInt16LE(x + 2);
        if (id === 1) {
          let q = x + 4;
          if (usize === 0xffffffff) { usize = u64(cd, q); q += 8; }
          if (csize === 0xffffffff) { csize = u64(cd, q); q += 8; }
          if (off === 0xffffffff) { off = u64(cd, q); q += 8; }
        }
        x += 4 + len;
      }
      out.push({ name, method, csize, size: usize, off });
      p += 46 + nl + xl + cl;
    }
    return out;
  } finally { fs.closeSync(fd); }
}

// extrait une entrée vers dest (dossiers créés)
async function extractEntry(file, ent, dest) {
  const fd = fs.openSync(file, 'r');
  let start;
  try {
    const h = readAt(fd, ent.off, 30);
    if (h.readUInt32LE(0) !== 0x04034b50) throw new Error('entrée abîmée : ' + ent.name);
    start = ent.off + 30 + h.readUInt16LE(26) + h.readUInt16LE(28);
  } finally { fs.closeSync(fd); }
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const tmp = dest + '.part';
  if (ent.csize === 0) fs.writeFileSync(tmp, '');
  else {
    const src = fs.createReadStream(file, { start, end: start + ent.csize - 1 });
    if (ent.method === 0) await pipeline(src, fs.createWriteStream(tmp));
    else if (ent.method === 8) await pipeline(src, zlib.createInflateRaw(), fs.createWriteStream(tmp));
    else throw new Error('compression non gérée (' + ent.method + ') : ' + ent.name);
  }
  fs.renameSync(tmp, dest);
}

// extrait tout le zip dans dir ; progress(fait, total) en octets
async function extractAll(file, dir, progress) {
  const ents = list(file).filter(e => !e.name.endsWith('/'));
  const total = ents.reduce((s, e) => s + e.size, 0) || 1;
  let done = 0;
  // petits fichiers d'abord (le diaporama peut s'afficher pendant que les vidéos arrivent)
  ents.sort((a, b) => a.size - b.size);
  const root = path.resolve(dir);
  for (const e of ents) {
    const dest = path.resolve(root, e.name);
    if (!dest.startsWith(root + path.sep)) continue;   // chemin hors du dossier : ignoré
    await extractEntry(file, e, dest);
    done += e.size;
    if (progress) progress(done, total, e.name);
  }
  return ents.length;
}

module.exports = { list, extractEntry, extractAll };
