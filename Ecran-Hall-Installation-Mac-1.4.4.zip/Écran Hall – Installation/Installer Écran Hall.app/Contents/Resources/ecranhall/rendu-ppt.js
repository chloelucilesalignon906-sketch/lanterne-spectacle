'use strict';
/* Lanterne PPT — dessin des diapos (canevas 2D), animations, transitions et Morph.
   Chaque objet est dessiné une fois dans une petite image (« vignette d'objet », mise en cache à la bonne taille),
   puis posé à chaque image avec sa position, sa rotation, son opacité et sa découpe du moment. */
(function () {
const EMU_PT = 12700;
const DEG = Math.PI / 180;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const css = c => c ? `rgba(${c.r | 0},${c.g | 0},${c.b | 0},${c.a == null ? 1 : +c.a.toFixed(4)})` : 'transparent';

/* ================= géométrie des formes (définitions de PowerPoint, formes.json) ================= */
let PRESETS = {};
function setPresets(p) { PRESETS = p || {}; }
const GUIDE_CONST = (w, h) => {
  const ss = Math.min(w, h), ls = Math.max(w, h);
  const g = { w, h, l: 0, t: 0, r: w, b: h, hc: w / 2, vc: h / 2, ss, ls, cd2: 10800000, cd4: 5400000, cd8: 2700000, '3cd4': 16200000, '3cd8': 8100000, '5cd8': 13500000, '7cd8': 18900000 };
  for (const d of [2, 3, 4, 5, 6, 8, 10, 12, 16, 32]) { g['wd' + d] = w / d; g['hd' + d] = h / d; g['ssd' + d] = ss / d; }
  return g;
};
function evalGuides(list, g) {
  const v = x => { if (x == null) return 0; if (x in g) return g[x]; const n = parseFloat(x); return isFinite(n) ? n : 0; };
  const ang = x => x / 60000 * DEG;
  for (const [name, f] of list) {
    const p = String(f).trim().split(/\s+/), [a, b, c] = [v(p[1]), v(p[2]), v(p[3])];
    let r = 0;
    switch (p[0]) {
      case '*/': r = c ? a * b / c : 0; break;
      case '+-': r = a + b - c; break;
      case '+/': r = c ? (a + b) / c : 0; break;
      case '?:': r = a > 0 ? b : c; break;
      case 'abs': r = Math.abs(a); break;
      case 'at2': r = Math.atan2(b, a) / DEG * 60000; break;
      case 'cat2': r = a * Math.cos(Math.atan2(c, b)); break;
      case 'cos': r = a * Math.cos(ang(b)); break;
      case 'max': r = Math.max(a, b); break;
      case 'min': r = Math.min(a, b); break;
      case 'mod': r = Math.sqrt(a * a + b * b + c * c); break;
      case 'pin': r = b < a ? a : b > c ? c : b; break;
      case 'sat2': r = a * Math.sin(Math.atan2(c, b)); break;
      case 'sin': r = a * Math.sin(ang(b)); break;
      case 'sqrt': r = Math.sqrt(Math.max(0, a)); break;
      case 'tan': r = a * Math.tan(ang(b)); break;
      case 'val': r = a; break;
      default: r = 0;
    }
    g[name] = r;
  }
  return g;
}
// chemins (Path2D) d'une forme de w × h pixels ; geom = { prst, av } ou { cust, av, gd, paths }
function shapePaths(geom, w, h) {
  let def = geom && geom.cust ? geom : PRESETS[geom && geom.prst] || PRESETS.rect;
  if (!def) def = { av: [], gd: [], paths: [{ c: [['M', 'l', 't'], ['L', 'r', 't'], ['L', 'r', 'b'], ['L', 'l', 'b'], ['Z']] }] };
  const g = GUIDE_CONST(w, h);
  const av = (def.av || []).map(([n, f]) => [n, geom && geom.av && !Array.isArray(geom.av) && geom.av[n] ? geom.av[n] : f]);
  if (geom && geom.cust) evalGuides(geom.av || [], g); else evalGuides(av, g);
  evalGuides(def.gd || [], g);
  const val = x => { if (x in g) return g[x]; const n = parseFloat(x); return isFinite(n) ? n : 0; };
  const out = [];
  for (const P of def.paths || []) {
    const pw = P.w != null ? val(P.w) : 0, ph = P.h != null ? val(P.h) : 0;
    const sx = pw ? w / pw : 1, sy = ph ? h / ph : 1;
    const path = new Path2D();
    let cx = 0, cy = 0, sx0 = 0, sy0 = 0;
    for (const c of P.c) {
      const k = c[0];
      if (k === 'M') { cx = val(c[1]) * sx; cy = val(c[2]) * sy; sx0 = cx; sy0 = cy; path.moveTo(cx, cy); }
      else if (k === 'L') { cx = val(c[1]) * sx; cy = val(c[2]) * sy; path.lineTo(cx, cy); }
      else if (k === 'C') { path.bezierCurveTo(val(c[1]) * sx, val(c[2]) * sy, val(c[3]) * sx, val(c[4]) * sy, val(c[5]) * sx, val(c[6]) * sy); cx = val(c[5]) * sx; cy = val(c[6]) * sy; }
      else if (k === 'Q') { path.quadraticCurveTo(val(c[1]) * sx, val(c[2]) * sy, val(c[3]) * sx, val(c[4]) * sy); cx = val(c[3]) * sx; cy = val(c[4]) * sy; }
      else if (k === 'A') {
        const wR = val(c[1]) * sx, hR = val(c[2]) * sy, st = val(c[3]) / 60000, sw = val(c[4]) / 60000;
        if (wR <= 0 || hR <= 0) continue;
        const par = a => Math.atan2(wR * Math.sin(a * DEG), hR * Math.cos(a * DEG));
        const t1 = par(st);
        let d = par(st + sw) - t1;
        if (Math.abs(sw) >= 360) d = Math.sign(sw) * 2 * Math.PI;
        else { while (sw > 0 && d < 0) d += 2 * Math.PI; while (sw < 0 && d > 0) d -= 2 * Math.PI; if (sw > 0 && sw > 180 && d < Math.PI) d += 2 * Math.PI; if (sw < 0 && sw < -180 && d > -Math.PI) d -= 2 * Math.PI; }
        const ecx = cx - wR * Math.cos(t1), ecy = cy - hR * Math.sin(t1);
        path.ellipse(ecx, ecy, wR, hR, 0, t1, t1 + d, d < 0);
        cx = ecx + wR * Math.cos(t1 + d); cy = ecy + hR * Math.sin(t1 + d);
      }
      else if (k === 'Z') { path.closePath(); cx = sx0; cy = sy0; }
    }
    out.push({ path, fill: P.fill !== 'none', fillMode: P.fill || 'norm', stroke: P.stroke !== 'false' && P.stroke !== false });
  }
  let rect = { l: 0, t: 0, r: w, b: h };
  if (def.rect) rect = { l: val(def.rect[0]), t: val(def.rect[1]), r: val(def.rect[2]), b: val(def.rect[3]) };
  return { paths: out, rect };
}

/* ================= peinture : remplissages, traits ================= */
function paintOf(ctx, f, x, y, w, h, img) {
  if (!f || f.type === 'none' || f.type === 'grp') return null;
  if (f.type === 'solid') return css(f.c);
  if (f.type === 'grad') {
    let g;
    if (f.path) {
      // centre du dégradé : rectangle fillToRect (marges en fractions de la boîte)
      const r = f.ftr || { l: 0.5, t: 0.5, r: 0.5, b: 0.5 };
      const cx = x + w * (r.l + (1 - r.r)) / 2, cy = y + h * (r.t + (1 - r.b)) / 2;
      const rad = Math.hypot(Math.max(cx - x, x + w - cx), Math.max(cy - y, y + h - cy));
      g = ctx.createRadialGradient(cx, cy, 0, cx, cy, rad || 1);
    } else {
      let a = (f.ang || 0) * DEG;
      if (f.scaled && w && h) a = Math.atan2(Math.sin(a) * h / w, Math.cos(a)) ;
      const cx = x + w / 2, cy = y + h / 2, dx = Math.cos(a), dy = Math.sin(a);
      const L = Math.abs(w * dx) + Math.abs(h * dy);
      g = ctx.createLinearGradient(cx - dx * L / 2, cy - dy * L / 2, cx + dx * L / 2, cy + dy * L / 2);
    }
    for (const s of f.stops) g.addColorStop(clamp(s.pos, 0, 1), css(s.c));
    return g;
  }
  if (f.type === 'blip') return img ? { blip: f, img } : null;
  return null;
}
const DASHES = { solid: null, dash: [4, 3], sysDash: [3, 1], sysDot: [1, 1], dot: [1, 3], dashDot: [4, 3, 1, 3], lgDash: [8, 3], lgDashDot: [8, 3, 1, 3], lgDashDotDot: [8, 3, 1, 3, 1, 3], sysDashDot: [3, 1, 1, 1], sysDashDotDot: [3, 1, 1, 1, 1, 1] };
function setStroke(ctx, ln, s, x, y, w, h) {
  const lw = Math.max(0.6, (ln.w != null ? ln.w : 9525) * s);
  const p = paintOf(ctx, ln.fill || { type: 'solid', c: { r: 0, g: 0, b: 0, a: 1 } }, x, y, w, h);
  if (!p || typeof p === 'object' && p.blip) return 0;
  ctx.strokeStyle = p; ctx.lineWidth = lw;
  ctx.lineCap = ln.cap === 'rnd' ? 'round' : ln.cap === 'sq' ? 'square' : 'butt';
  ctx.lineJoin = ln.join || 'round';
  const d = Array.isArray(ln.dash) ? ln.dash.flat().map(v => v * 1) : DASHES[ln.dash];
  ctx.setLineDash(d ? d.map(v => v * lw) : []);
  return lw;
}
function arrowHead(ctx, x, y, ang, end, lw) {
  const k = { sm: 2, med: 3, lg: 5 };
  const L = (k[end.len] || 3) * lw, W = (k[end.w] || 3) * lw;
  ctx.save(); ctx.translate(x, y); ctx.rotate(ang); ctx.setLineDash([]);
  ctx.beginPath();
  if (end.type === 'oval') ctx.ellipse(0, 0, L / 2, W / 2, 0, 0, Math.PI * 2);
  else if (end.type === 'diamond') { ctx.moveTo(L / 2, 0); ctx.lineTo(0, W / 2); ctx.lineTo(-L / 2, 0); ctx.lineTo(0, -W / 2); ctx.closePath(); }
  else if (end.type === 'arrow') { ctx.moveTo(-L, -W / 2); ctx.lineTo(0, 0); ctx.lineTo(-L, W / 2); ctx.lineWidth = lw; ctx.stroke(); ctx.restore(); return; }
  else if (end.type === 'stealth') { ctx.moveTo(0, 0); ctx.lineTo(-L, -W / 2); ctx.lineTo(-L * 0.6, 0); ctx.lineTo(-L, W / 2); ctx.closePath(); }
  else { ctx.moveTo(0, 0); ctx.lineTo(-L, -W / 2); ctx.lineTo(-L, W / 2); ctx.closePath(); }
  ctx.fillStyle = ctx.strokeStyle; ctx.fill(); ctx.restore();
}

/* ================= polices ================= */
// FONT(face, b, i) -> { family, weight, style } fourni par polices.js ; repli simple sans lui
let FONT = (face, b, i) => ({ family: `"${face}", "Helvetica Neue", Arial, sans-serif`, weight: b ? 700 : 400, style: i ? 'italic' : 'normal' });
function setFontResolver(fn) { FONT = fn; }
const mctx = document.createElement('canvas').getContext('2d');
const metricCache = new Map();
function fontStr(r, px, theme) {
  let face = r.font || r.eaFont || '+mn-lt';
  if (face === '+mj-lt' || face === '+mj-ea' || face === '+mj-cs') face = theme.major;
  else if (face === '+mn-lt' || face === '+mn-ea' || face === '+mn-cs') face = theme.minor;
  const f = FONT(face, !!r.b, !!r.i);
  return { str: `${f.style === 'italic' ? 'italic ' : ''}${f.weight} ${Math.max(0.5, px).toFixed(2)}px ${f.family}`, face };
}
function metrics(fs) {
  let m = metricCache.get(fs);
  if (!m) {
    mctx.font = fs;
    const t = mctx.measureText('Hgjpq ÉÀ');
    const px = parseFloat(/([\d.]+)px/.exec(fs)[1]) || 1;
    m = { asc: (t.fontBoundingBoxAscent || px * 0.9) / px, desc: (t.fontBoundingBoxDescent || px * 0.22) / px };
    metricCache.set(fs, m);
    if (metricCache.size > 4000) metricCache.clear();
  }
  return m;
}
function measure(fs, text, ls) {
  mctx.font = fs;
  mctx.letterSpacing = ls ? ls + 'px' : '0px';
  return mctx.measureText(text).width;
}

/* ================= texte : mise en lignes ================= */
const ROMAN = n => { const r = [[1000, 'm'], [900, 'cm'], [500, 'd'], [400, 'cd'], [100, 'c'], [90, 'xc'], [50, 'l'], [40, 'xl'], [10, 'x'], [9, 'ix'], [5, 'v'], [4, 'iv'], [1, 'i']]; let s = ''; for (const [v, k] of r) while (n >= v) { s += k; n -= v; } return s; };
function autoNum(type, n) {
  const alpha = n => { let s = ''; while (n > 0) { n--; s = String.fromCharCode(97 + n % 26) + s; n = Math.floor(n / 26); } return s; };
  let core = String(n);
  if (/^alphaLc/.test(type)) core = alpha(n); else if (/^alphaUc/.test(type)) core = alpha(n).toUpperCase();
  else if (/^romanLc/.test(type)) core = ROMAN(n); else if (/^romanUc/.test(type)) core = ROMAN(n).toUpperCase();
  if (/ParenBoth$/.test(type)) return `(${core})`;
  if (/ParenR$/.test(type)) return `${core})`;
  if (/Period$/.test(type)) return `${core}.`;
  if (/Minus$/.test(type)) return `- ${core} -`;
  return core;
}
// lignes d'un bloc de texte pour une largeur donnée (pixels) ; s = pixels par EMU
function layoutText(text, body, boxW, s, theme, autofit) {
  const scaleF = autofit && autofit.scale ? autofit.scale : 1;
  const lnRed = autofit && autofit.lnRed ? autofit.lnRed : 0;
  const wrap = body.wrap !== 'none';
  const lines = [];
  const counters = [];
  let y = 0, first = true;
  text.paras.forEach((para, pi) => {
    const P = para.p;
    const lvl = para.lvl || 0;
    const runs0 = para.runs.length ? para.runs : [Object.assign({}, para.end, { t: '' })];
    const sizeOf = r => (r.sz || para.end.sz || 1800) / 100 * EMU_PT * s * scaleF;
    // puce
    let bullet = null;
    const hasText = para.runs.some(r => r.t);
    if (P.bu && !P.bu.none && hasText) {
      const r0 = para.runs.find(r => r.t) || para.end;
      let ch = P.bu.char;
      if (P.bu.auto) { counters[lvl] = (counters[lvl] || (P.bu.start || 1) - 1) + 1; ch = autoNum(P.bu.auto, counters[lvl]); counters.length = lvl + 1; }
      const bsz = P.buSzPts ? P.buSzPts * EMU_PT * s * scaleF : sizeOf(r0) * (P.buSz || 1);
      const fb = fontStr(Object.assign({}, r0, P.buFont && !P.bu.auto ? { font: P.buFont, b: false, i: false } : {}), bsz, theme);
      bullet = { t: ch, font: fb.str, face: fb.face, color: P.buClr || null, run: r0, w: measure(fb.str, ch) };
    } else if (!(P.bu && P.bu.auto)) counters.length = lvl;
    const marL = (P.marL || 0) * s, indent = (P.indent || 0) * s;
    const defTab = (P.defTabSz || 914400) * s;
    // espacement avant (sauf premier paragraphe)
    const sz0 = sizeOf(runs0.find(r => r.t) || runs0[0]);
    const spc = (sp, base) => !sp ? 0 : sp.pts != null ? sp.pts * EMU_PT * s * scaleF : sp.pct * base * 1.2;
    if (!first) y += spc(P.spcBef, sz0); else y += 0;
    first = false;
    // morceaux : mots et espaces, coupures possibles après un espace ou un trait d'union
    const pieces = [];
    for (const r of runs0) {
      if (r.br) { pieces.push({ br: true, r, px: sizeOf(r) }); continue; }
      let t = r.t || '';
      if (r.cap === 'all') t = t.toUpperCase();
      const px = sizeOf(r) * (r.baseline ? 0.67 : 1);
      const fsr = fontStr(r, px, theme);
      const ls = r.spc ? r.spc / 100 * EMU_PT * s * scaleF : 0;
      const re = /\t|[^\s\-‐‑]*[\-‐‑]|[^\s\-‐‑]+|[^\S\t]+/g;
      let m;
      while ((m = re.exec(t))) {
        const tok = m[0];
        if (tok === '\t') { pieces.push({ tab: true, r, font: fsr.str, px }); continue; }
        pieces.push({ t: tok, r, font: fsr.str, face: fsr.face, px, ls, w: measure(fsr.str, tok, ls) + (r.cap === 'small' ? 0 : 0), sp: /^\s+$/.test(tok) });
      }
      if (!t) pieces.push({ t: '', r, font: fsr.str, face: fsr.face, px, ls, w: 0, empty: true });
    }
    // lignes
    const indentFirst = marL + indent;
    let line = null;
    const newLine = firstOfPara => {
      const x0 = firstOfPara ? indentFirst : marL;
      line = { items: [], x0, w: 0, maxPx: 0, asc: 0, desc: 0, para: pi, P, first: firstOfPara, bullet: firstOfPara ? bullet : null };
      lines.push(line);
      if (firstOfPara && bullet) {
        // la puce se place au retrait de première ligne, le texte à la marge
        const bx = indentFirst;
        line.bulletX = bx;
        line.x0 = indent < 0 ? Math.max(marL, bx + bullet.w) : bx + bullet.w + 0;
        if (indent >= 0) line.x0 = bx + bullet.w;
      }
    };
    newLine(true);
    const avail = () => boxW - line.x0;
    for (let i = 0; i < pieces.length; i++) {
      const pc = pieces[i];
      if (pc.br) { line.maxPx = Math.max(line.maxPx, pc.px); newLine(false); continue; }
      if (pc.tab) {
        const cur = line.x0 + line.w;
        let next = Math.ceil((cur + 1) / defTab) * defTab;
        if (P.tabs) { const t = P.tabs.find(tb => tb.pos * s > cur); if (t) next = t.pos * s; }
        line.items.push({ t: '', w: next - cur, r: pc.r, font: pc.font, px: pc.px, tab: true });
        line.w += next - cur; continue;
      }
      if (wrap && !pc.sp && line.w + pc.w > avail() + 0.5 && line.items.some(it => !it.sp && it.t)) {
        // retour à la ligne : les espaces de fin ne comptent pas
        newLine(false);
      }
      if (wrap && !pc.sp && pc.w > avail() && pc.t.length > 1) {
        // mot plus long que la ligne : coupé lettre par lettre
        let acc = '';
        for (const ch of pc.t) {
          const ww = measure(pc.font, acc + ch, pc.ls);
          if (ww > avail() - line.w && acc) { line.items.push(Object.assign({}, pc, { t: acc, w: measure(pc.font, acc, pc.ls) })); line.w += measure(pc.font, acc, pc.ls); newLine(false); acc = ch; }
          else acc += ch;
        }
        if (acc) { const ww = measure(pc.font, acc, pc.ls); line.items.push(Object.assign({}, pc, { t: acc, w: ww })); line.w += ww; }
        continue;
      }
      if (pc.sp && !line.items.length && !line.first) continue;   // espace en début de ligne repliée
      line.items.push(pc); line.w += pc.w;
    }
    // hauteur des lignes du paragraphe
    const lnPct = P.lnSpc && P.lnSpc.pct != null ? Math.max(0.1, P.lnSpc.pct - lnRed) : null;
    const lnPts = P.lnSpc && P.lnSpc.pts != null ? P.lnSpc.pts * EMU_PT * s : null;
    const pLines = lines.filter(l => l.para === pi);
    pLines.forEach((l, k) => {
      let asc = 0, desc = 0, mx = 0;
      const its = l.items.length ? l.items : [{ font: fontStr(para.end, sizeOf(para.end), theme).str, px: sizeOf(para.end) }];
      for (const it of its) { const m = metrics(it.font); asc = Math.max(asc, m.asc * it.px); desc = Math.max(desc, m.desc * it.px); mx = Math.max(mx, it.px); }
      if (l.bullet) { const m = metrics(l.bullet.font); const bp = parseFloat(/([\d.]+)px/.exec(l.bullet.font)[1]); asc = Math.max(asc, m.asc * bp); }
      // trailing spaces width excluded for alignment
      let wTrim = l.w; for (let j = l.items.length - 1; j >= 0 && l.items[j].sp; j--) wTrim -= l.items[j].w;
      l.wTrim = wTrim;
      const natural = (asc + desc) * 1.0;
      let h = lnPts != null ? lnPts : natural * (lnPct != null ? lnPct : 1) * 1.0;
      // PowerPoint : interligne simple = 1,2 × la taille, à peu près la hauteur naturelle de la police
      if (lnPts == null) h = Math.max(h, 0);
      l.asc = asc; l.desc = desc; l.h = h;
      l.base = y + h - desc;
      y += h;
      if (k === pLines.length - 1) y += spc(P.spcAft, mx || sz0);
    });
  });
  return { lines, height: y };
}
function alignX(l, boxW) {
  const a = (l.P && l.P.algn) || 'l';
  const free = boxW - l.x0 - l.wTrim;
  if (a === 'ctr') return l.x0 + free / 2;
  if (a === 'r') return l.x0 + free;
  return l.x0;
}
// dessine les lignes (onlyPara : un seul paragraphe, pour les animations par paragraphe)
function drawLines(ctx, L, ox, oy, boxW, colorOverride, onlyPara) {
  for (const l of L.lines) {
    if (onlyPara != null && l.para !== onlyPara) continue;
    let x = ox + alignX(l, boxW);
    const by = oy + l.base;
    const just = l.P && (l.P.algn === 'just' || l.P.algn === 'dist') && l !== L.lines.filter(q => q.para === l.para).slice(-1)[0];
    const spaces = just ? l.items.filter(it => it.sp).length : 0;
    const extra = just && spaces ? (boxW - l.x0 - l.wTrim) / spaces : 0;
    if (just) x = ox + l.x0;
    if (l.bullet) {
      const b = l.bullet;
      ctx.font = b.font; ctx.letterSpacing = '0px';
      ctx.fillStyle = css(b.color || (b.run.fill && b.run.fill.type === 'solid' ? b.run.fill.c : { r: 0, g: 0, b: 0, a: 1 }));
      ctx.fillText(b.t, ox + l.bulletX, by);
    }
    for (const it of l.items) {
      if (it.t && !it.sp) {
        const r = it.r;
        ctx.font = it.font;
        ctx.letterSpacing = it.ls ? it.ls + 'px' : '0px';
        const yb = by - (r.baseline ? r.baseline / 1e5 * it.px / 0.67 : 0);
        if (r.hl) { ctx.fillStyle = css(r.hl); ctx.fillRect(x, by - it.px * 0.95, it.w, it.px * 1.2); }
        let fillC = colorOverride || (r.fill && r.fill.type === 'solid' ? css(r.fill.c) : r.fill && r.fill.type === 'grad' && r.fill.stops.length ? css(r.fill.stops[0].c) : r.fill && r.fill.type === 'none' ? null : '#000');
        if (r.fill && r.fill.type === 'grad' && !colorOverride) { const g = ctx.createLinearGradient(x, by - it.px, x, by); for (const s of r.fill.stops) g.addColorStop(clamp(s.pos, 0, 1), css(s.c)); fillC = g; }
        if (r.shadow) { const sh = r.shadow; ctx.shadowColor = css(sh.c); ctx.shadowBlur = sh.blur * L.s; ctx.shadowOffsetX = Math.cos(sh.dir * DEG) * sh.dist * L.s; ctx.shadowOffsetY = Math.sin(sh.dir * DEG) * sh.dist * L.s; }
        if (r.cap === 'small') ctx.fontVariantCaps = 'small-caps';
        if (fillC) { ctx.fillStyle = fillC; ctx.fillText(it.t, x, yb); }
        ctx.shadowColor = 'transparent';
        if (r.ln && r.ln.fill && r.ln.fill.type !== 'none') {
          const lw = Math.max(0.5, (r.ln.w != null ? r.ln.w : 6350) * L.s);
          ctx.lineWidth = lw; ctx.lineJoin = 'round'; ctx.strokeStyle = r.ln.fill.type === 'solid' ? css(r.ln.fill.c) : '#000';
          ctx.strokeText(it.t, x, yb);
        }
        if (r.cap === 'small') ctx.fontVariantCaps = 'normal';
        if ((r.u && r.u !== 'none') || (r.strike && r.strike !== 'noStrike')) {
          ctx.fillStyle = typeof fillC === 'string' ? fillC : '#000';
          const th = Math.max(1, it.px * 0.06);
          if (r.u && r.u !== 'none') { ctx.fillRect(x, by + it.px * 0.12, it.w + (extra && it.sp ? extra : 0), th); if (/^dbl/.test(r.u)) ctx.fillRect(x, by + it.px * 0.12 + th * 2, it.w, th); }
          if (r.strike && r.strike !== 'noStrike') { ctx.fillRect(x, by - it.px * 0.3, it.w, th); if (r.strike === 'dblStrike') ctx.fillRect(x, by - it.px * 0.3 - th * 2, it.w, th); }
        }
      }
      x += it.w + (it.sp ? extra : 0);
    }
  }
}

/* ================= images ================= */
const IMG = new Map();   // url -> { img, ok, p }
function loadImg(url) {
  if (!url) return null;
  let e = IMG.get(url);
  if (!e) {
    const img = new Image();
    img.decoding = 'async';
    e = { img, ok: false, err: false };
    e.p = new Promise(res => {
      img.onload = () => { e.ok = true; (img.decode ? img.decode().catch(() => {}) : Promise.resolve()).then(res); };
      img.onerror = () => { e.err = true; res(); };
    });
    img.src = url;
    IMG.set(url, e);
  }
  return e;
}
const imgSize = im => ({ w: im.naturalWidth || im.videoWidth || im.width || 1, h: im.naturalHeight || im.videoHeight || im.height || 1 });
// image dans la boîte (x,y,w,h), avec recadrage (crop) et marges internes (fillRect)
function drawCropped(ctx, im, f, x, y, w, h) {
  const fr = f.fillRect || { l: 0, t: 0, r: 0, b: 0 };
  x += fr.l * w; y += fr.t * h; w *= (1 - fr.l - fr.r); h *= (1 - fr.t - fr.b);
  const c = f.crop || { l: 0, t: 0, r: 0, b: 0 };
  const cw = 1 - c.l - c.r, ch = 1 - c.t - c.b;
  if (cw <= 0 || ch <= 0) return;
  const W = w / cw, H = h / ch;
  const { w: iw, h: ih } = imgSize(im);
  if (f.tile) {
    const pat = ctx.createPattern(im, 'repeat');
    if (pat) { pat.setTransform(new DOMMatrix().translate(x, y).scale(f.tile.sx * w / iw * 0 + (W / iw) * f.tile.sx, (H / ih) * f.tile.sy)); ctx.fillStyle = pat; ctx.fillRect(x, y, w, h); }
    return;
  }
  // morceau de l'image source qui tombe dans la boîte
  const sx = Math.max(0, c.l) * iw, sy = Math.max(0, c.t) * ih;
  const ex = Math.min(1, 1 - c.r) * iw, ey = Math.min(1, 1 - c.b) * ih;
  const dx = x + (Math.max(0, c.l) - c.l) * W, dy = y + (Math.max(0, c.t) - c.t) * H;
  const dw = (ex - sx) / iw * W, dh = (ey - sy) / ih * H;
  if (!(dw > 0 && dh > 0 && ex > sx && ey > sy)) return;
  // image entière (SVG compris : Chromium découpe mal une image vectorielle par la source)
  if (!sx && !sy && Math.abs(ex - iw) < 0.5 && Math.abs(ey - ih) < 0.5) ctx.drawImage(im, dx, dy, dw, dh);
  else ctx.drawImage(im, sx, sy, ex - sx, ey - sy, dx, dy, dw, dh);
}

/* ================= vignettes d'objets ================= */
// dessin d'un objet dans son propre repère : (0,0) = coin haut-gauche de la boîte, w × h pixels
function paintElement(ctx, el, w, h, s, theme, opt = {}) {
  const fx = el.fx || {};
  const shadowOn = sh => { if (!sh) return; ctx.shadowColor = css(sh.c); ctx.shadowBlur = sh.blur * s; ctx.shadowOffsetX = Math.cos(sh.dir * DEG) * sh.dist * s; ctx.shadowOffsetY = Math.sin(sh.dir * DEG) * sh.dist * s; };
  const shadowOff = () => { ctx.shadowColor = 'transparent'; ctx.shadowBlur = 0; ctx.shadowOffsetX = 0; ctx.shadowOffsetY = 0; };
  if (el.kind === 'pic' || el.kind === 'video' || el.kind === 'audio') {
    const src = opt.frame || (el.img && el.img.url && loadImg(el.img.url));
    const im = opt.frame || (src && src.ok ? src.img : null);
    const geo = shapePaths(el.geom || { prst: 'rect', av: {} }, w, h);
    ctx.save();
    if (fx.shadow) { shadowOn(fx.shadow); ctx.fillStyle = '#000'; for (const p of geo.paths) if (p.fill) ctx.fill(p.path); shadowOff(); }
    for (const p of geo.paths) if (p.fill) ctx.clip(p.path);
    if (im) {
      ctx.globalAlpha *= el.img ? el.img.alpha : 1;
      if (el.img && el.img.filters && el.img.filters.length) ctx.filter = el.img.filters.join(' ');
      if (opt.frame) {
        // vidéo : remplit la boîte comme PowerPoint (image étirée à la taille de l'objet)
        const f = Object.assign({}, el.img || {}, { crop: (el.img && el.img.crop) || null });
        drawCropped(ctx, im, f, 0, 0, w, h);
      } else drawCropped(ctx, im, el.img, 0, 0, w, h);
      ctx.filter = 'none';
    } else if (el.kind !== 'audio' && el.img && !el.img.url) { ctx.fillStyle = '#111'; ctx.fillRect(0, 0, w, h); }
    ctx.restore();
    if (el.line && el.line.fill && el.line.fill.type !== 'none') { ctx.save(); if (setStroke(ctx, el.line, s, 0, 0, w, h)) for (const p of geo.paths) if (p.stroke) ctx.stroke(p.path); ctx.restore(); }
    return;
  }
  if (el.kind === 'table') { paintTable(ctx, el, s, theme); return; }
  if (el.kind === 'missing') {
    ctx.save(); ctx.strokeStyle = 'rgba(255,170,60,.7)'; ctx.setLineDash([8, 6]); ctx.lineWidth = 2; ctx.strokeRect(1, 1, w - 2, h - 2); ctx.restore();
    return;
  }
  // forme
  const geo = shapePaths(el.geom, w, h);
  ctx.save();
  const f = el.fill;
  let img = null;
  if (f && f.type === 'blip') { const e = loadImg(f.url); img = e && e.ok ? e.img : null; }
  const paint = paintOf(ctx, f, 0, 0, w, h, img);
  if (paint && !opt.noShape) {
    if (fx.glow && fx.glow.c) { ctx.save(); ctx.shadowColor = css(fx.glow.c); ctx.shadowBlur = fx.glow.rad * s; ctx.fillStyle = css(fx.glow.c); for (const p of geo.paths) if (p.fill) ctx.fill(p.path); ctx.restore(); }
    shadowOn(fx.shadow);
    for (const p of geo.paths) {
      if (!p.fill) continue;
      if (typeof paint === 'object' && paint.blip) { ctx.save(); ctx.fillStyle = '#000'; if (fx.shadow) ctx.fill(p.path); shadowOff(); ctx.clip(p.path); ctx.globalAlpha *= paint.blip.alpha; drawCropped(ctx, paint.img, paint.blip, 0, 0, w, h); ctx.restore(); }
      else {
        ctx.fillStyle = paint; ctx.fill(p.path);
        if (p.fillMode === 'darken' || p.fillMode === 'darkenLess') { ctx.fillStyle = `rgba(0,0,0,${p.fillMode === 'darken' ? 0.4 : 0.2})`; ctx.fill(p.path); }
        if (p.fillMode === 'lighten' || p.fillMode === 'lightenLess') { ctx.fillStyle = `rgba(255,255,255,${p.fillMode === 'lighten' ? 0.4 : 0.2})`; ctx.fill(p.path); }
      }
    }
    shadowOff();
  }
  const ln = el.line;
  if (ln && ln.fill && ln.fill.type !== 'none' && !opt.noShape) {
    if (!paint && fx.shadow) shadowOn(fx.shadow);
    const lw = setStroke(ctx, ln, s, 0, 0, w, h);
    if (lw) {
      for (const p of geo.paths) if (p.stroke) ctx.stroke(p.path);
      shadowOff();
      // flèches au bout des traits
      if ((ln.headEnd || ln.tailEnd) && geo.paths.length) {
        const pts = linePoints(el.geom, w, h);
        if (pts) {
          if (ln.headEnd) arrowHead(ctx, pts[0][0], pts[0][1], Math.atan2(pts[0][1] - pts[1][1], pts[0][0] - pts[1][0]), ln.headEnd, lw);
          if (ln.tailEnd) { const n = pts.length; arrowHead(ctx, pts[n - 1][0], pts[n - 1][1], Math.atan2(pts[n - 1][1] - pts[n - 2][1], pts[n - 1][0] - pts[n - 2][0]), ln.tailEnd, lw); }
        }
      }
    }
  }
  ctx.restore();
}
// extrémités des connecteurs (pour les flèches)
function linePoints(geom, w, h) {
  const p = geom && geom.prst;
  if (!p || p === 'line' || p === 'straightConnector1') return [[0, 0], [w, h]];
  if (/^bentConnector/.test(p)) return [[0, 0], [w / 2, 0], [w / 2, h], [w, h]];
  if (/^curvedConnector/.test(p)) return [[0, 0], [w * 0.4, 0], [w * 0.6, h], [w, h]];
  return null;
}
// boîte du texte : rectangle de texte de la forme moins les marges
function textBox(el, w, h, s) {
  const b = el.body || {};
  const geo = el.kind === 'shape' ? shapePaths(el.geom, w, h).rect : { l: 0, t: 0, r: w, b: h };
  const l = (b.lIns != null ? b.lIns : 91440) * s, r = (b.rIns != null ? b.rIns : 91440) * s, t = (b.tIns != null ? b.tIns : 45720) * s, bo = (b.bIns != null ? b.bIns : 45720) * s;
  return { x: geo.l + l, y: geo.t + t, w: Math.max(1, geo.r - geo.l - l - r), h: Math.max(1, geo.b - geo.t - t - bo) };
}
function textLayoutFor(el, w, h, s, theme) {
  const b = el.body || {};
  const vert = b.vert && b.vert !== 'horz' && b.vert !== 'wordArtVert' ? b.vert : null;
  const tb = textBox(el, vert ? h : w, vert ? w : h, s);
  const L = layoutText(el.text, b, b.wrap === 'none' ? 1e7 : tb.w, s, theme, b.autofit && !b.autofit.sp && !b.autofit.none ? b.autofit : null);
  L.s = s;
  // largeur réelle pour le texte non replié (centré sur la boîte)
  if (b.wrap === 'none') { L.lines.forEach(l => { l.noWrapW = tb.w; }); }
  const anchor = b.anchor || 't';
  const oy = anchor === 'ctr' ? tb.y + (tb.h - L.height) / 2 : anchor === 'b' ? tb.y + tb.h - L.height : tb.y;
  return { L, tb, oy, vert };
}
function paintText(ctx, el, w, h, s, theme, onlyPara, colorOverride) {
  const T = textLayoutFor(el, w, h, s, theme);
  ctx.save();
  ctx.textBaseline = 'alphabetic';
  if (T.vert) {
    // texte vertical : tourné d'un quart de tour
    if (T.vert === 'vert270') { ctx.translate(0, h); ctx.rotate(-Math.PI / 2); }
    else { ctx.translate(w, 0); ctx.rotate(Math.PI / 2); }
  }
  const boxW = el.body && el.body.wrap === 'none' ? T.tb.w : T.tb.w;
  if (el.body && el.body.wrap === 'none') {
    // non replié : l'alignement se fait sur la boîte
    for (const l of T.L.lines) l.x0 = l.x0 || 0;
  }
  drawLines(ctx, T.L, T.tb.x, T.oy, boxW, colorOverride, onlyPara);
  ctx.restore();
  return T;
}
// étendue (pixels, repère de l'objet) que le texte peut occuper hors de la boîte
function textExtent(el, w, h, s, theme) {
  const T = textLayoutFor(el, w, h, s, theme);
  let minX = 0, maxX = w;
  for (const l of T.L.lines) { const x = T.tb.x + alignX(l, T.tb.w); minX = Math.min(minX, x - (l.bullet ? l.bullet.w + 4 : 0)); maxX = Math.max(maxX, x + l.wTrim); }
  const minY = Math.min(0, T.oy - 4), maxY = Math.max(h, T.oy + T.L.height + 4);
  if (T.vert) return { l: Math.min(0, w - (maxY - 0)), t: Math.min(0, minX), r: Math.max(w, maxY), b: Math.max(h, maxX) };
  return { l: minX, t: minY, r: maxX, b: maxY };
}

/* ----- tableaux ----- */
function tableLayout(el, s, theme) {
  const T = el.table;
  const cols = [0]; for (const g of T.grid) cols.push(cols[cols.length - 1] + g * s);
  const rowsH = T.rows.map(r => r.h * s);
  // hauteur nécessaire au texte
  T.rows.forEach((row, ri) => row.cells.forEach((c, ci) => {
    if (c.hMerge || c.vMerge || !c.text || (c.rspan || 1) > 1) return;
    const span = Math.max(1, c.span || 1);
    const cw = cols[Math.min(cols.length - 1, ci + span)] - cols[ci];
    const L = layoutText(c.text, { wrap: 'square' }, Math.max(1, cw - (c.body.lIns + c.body.rIns) * s), s, theme, null);
    const need = L.height + (c.body.tIns + c.body.bIns) * s;
    if (need > rowsH[ri]) rowsH[ri] = need;
  }));
  const rows = [0]; for (const h of rowsH) rows.push(rows[rows.length - 1] + h);
  return { cols, rows };
}
function paintTable(ctx, el, s, theme) {
  const T = el.table, G = tableLayout(el, s, theme);
  const cellBox = (ri, ci, c) => {
    const x0 = G.cols[ci], x1 = G.cols[Math.min(G.cols.length - 1, ci + Math.max(1, c.span || 1))];
    const y0 = G.rows[ri], y1 = G.rows[Math.min(G.rows.length - 1, ri + Math.max(1, c.rspan || 1))];
    return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
  };
  T.rows.forEach((row, ri) => row.cells.forEach((c, ci) => {
    if (c.hMerge || c.vMerge) return;
    const b = cellBox(ri, ci, c);
    const p = paintOf(ctx, c.fill || T.fill, b.x, b.y, b.w, b.h);
    if (p && typeof p !== 'object') { ctx.fillStyle = p; ctx.fillRect(b.x, b.y, b.w, b.h); }
    else if (p && p.addColorStop) { ctx.fillStyle = p; ctx.fillRect(b.x, b.y, b.w, b.h); }
    if (c.text) {
      const L = layoutText(c.text, { wrap: 'square' }, Math.max(1, b.w - (c.body.lIns + c.body.rIns) * s), s, theme, null);
      L.s = s;
      const ih = b.h - (c.body.tIns + c.body.bIns) * s;
      const oy = b.y + c.body.tIns * s + (c.body.anchor === 'ctr' ? (ih - L.height) / 2 : c.body.anchor === 'b' ? ih - L.height : 0);
      drawLines(ctx, L, b.x + c.body.lIns * s, oy, b.w - (c.body.lIns + c.body.rIns) * s);
    }
  }));
  T.rows.forEach((row, ri) => row.cells.forEach((c, ci) => {
    if (c.hMerge || c.vMerge) return;
    const b = cellBox(ri, ci, c);
    const seg = (ln, x0, y0, x1, y1) => { if (!ln || !ln.fill || ln.fill.type === 'none') return; ctx.save(); if (setStroke(ctx, ln, s, b.x, b.y, b.w, b.h)) { ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); } ctx.restore(); };
    seg(c.border.top, b.x, b.y, b.x + b.w, b.y); seg(c.border.bottom, b.x, b.y + b.h, b.x + b.w, b.y + b.h);
    seg(c.border.left, b.x, b.y, b.x, b.y + b.h); seg(c.border.right, b.x + b.w, b.y, b.x + b.w, b.y + b.h);
  }));
}

/* ----- cache des vignettes d'objets ----- */
// clé : objet + échelle (+ paragraphe) ; la vignette garde une marge pour l'ombre, le trait et le texte qui dépasse
class SpriteCache {
  constructor() { this.m = new Map(); this.gen = 0; }
  clear() { this.m.clear(); }
  get(el, s, theme, part) {
    const key = part == null ? 's' : 'p' + part;
    let c = el._spr; if (!c) c = el._spr = {};
    const want = Math.round(s * 1e9);
    if (c[key] && c[key].s === want && c[key].gen === this.gen) return c[key];
    const w = Math.max(0, el.w * s), h = Math.max(0, el.h * s);
    // marge : trait, ombre, texte qui dépasse
    let ext = { l: 0, t: 0, r: w, b: h };
    const lw = el.line && el.line.fill && el.line.fill.type !== 'none' ? ((el.line.w != null ? el.line.w : 9525) * s) * 3 + 2 : 2;
    let pad = lw;
    const sh = el.fx && el.fx.shadow; if (sh) pad = Math.max(pad, (sh.blur + sh.dist) * s * 1.5 + 2);
    if (el.fx && el.fx.glow) pad = Math.max(pad, el.fx.glow.rad * s * 1.5 + 2);
    if (el.text) { const te = textExtent(el, w, h, s, theme); ext = { l: Math.min(ext.l, te.l), t: Math.min(ext.t, te.t), r: Math.max(ext.r, te.r), b: Math.max(ext.b, te.b) }; pad = Math.max(pad, 6); if (el.text.paras.some(p => p.runs.some(r => r.shadow))) pad = Math.max(pad, 24); }
    if (el.kind === 'table') { const G = tableLayout(el, s, theme); ext.b = Math.max(ext.b, G.rows[G.rows.length - 1]); ext.r = Math.max(ext.r, G.cols[G.cols.length - 1]); }
    const ox = Math.ceil(-ext.l + pad), oy = Math.ceil(-ext.t + pad);
    const cw = Math.ceil(ext.r - ext.l + pad * 2), ch = Math.ceil(ext.b - ext.t + pad * 2);
    const MAX = 8192;
    const cv = document.createElement('canvas');
    cv.width = clamp(cw, 1, MAX); cv.height = clamp(ch, 1, MAX);
    const g = cv.getContext('2d');
    g.translate(ox, oy);
    let pending = false;
    if (part == null || part === 'shape') {
      paintElement(g, el, w, h, s, theme, {});
      if (el.text && part == null) paintText(g, el, w, h, s, theme);
    } else paintText(g, el, w, h, s, theme, part);
    // image pas encore chargée : la vignette sera refaite
    const urls = [el.img && el.img.url, el.fill && el.fill.type === 'blip' && el.fill.url].filter(Boolean);
    for (const u of urls) { const e = loadImg(u); if (e && !e.ok && !e.err) pending = true; }
    const r = { cv, ox, oy, s: pending ? -1 : want, gen: this.gen };
    c[key] = r;
    return r;
  }
}
const SPR = new SpriteCache();

/* ================= animations ================= */
// formules de PowerPoint dans les animations (#ppt_x, sin(), $…)
function evalFormula(src, vars) {
  if (typeof src === 'number') return src;
  const s = String(src || '').trim();
  if (s === '') return 0;
  let i = 0;
  const peek = () => s[i], ws = () => { while (s[i] === ' ') i++; };
  function prim() {
    ws();
    if (s[i] === '(') { i++; const v = expr(); ws(); i++; return v; }
    if (s[i] === '-') { i++; return -prim(); }
    if (s[i] === '+') { i++; return prim(); }
    if (s[i] === '$') { i++; return vars.$; }
    if (s[i] === '#') { const m = /^#ppt_[a-z]+/.exec(s.slice(i)); if (m) { i += m[0].length; return vars[m[0]] || 0; } }
    const n = /^(\d+\.?\d*(?:[eE][-+]?\d+)?|\.\d+)/.exec(s.slice(i));
    if (n) { i += n[0].length; return parseFloat(n[0]); }
    const id = /^[a-z]+/i.exec(s.slice(i));
    if (id) {
      i += id[0].length; const f = id[0].toLowerCase();
      if (f === 'pi') return Math.PI; if (f === 'e') return Math.E;
      ws(); if (s[i] === '(') { i++; const args = [expr()]; ws(); while (s[i] === ',') { i++; args.push(expr()); ws(); } i++;
        const a = args[0];
        switch (f) { case 'sin': return Math.sin(a); case 'cos': return Math.cos(a); case 'tan': return Math.tan(a); case 'asin': return Math.asin(a); case 'acos': return Math.acos(a); case 'atan': return Math.atan(a); case 'abs': return Math.abs(a); case 'sqrt': return Math.sqrt(a); case 'exp': return Math.exp(a); case 'ln': return Math.log(a); case 'max': return Math.max(...args); case 'min': return Math.min(...args); case 'rand': return Math.random() * a; default: return a; }
      }
      return 0;
    }
    i++; return 0;
  }
  function pow() { let v = prim(); ws(); while (s[i] === '^') { i++; v = Math.pow(v, prim()); ws(); } return v; }
  function term() { let v = pow(); ws(); while (s[i] === '*' || s[i] === '/') { const o = s[i++]; const r = pow(); v = o === '*' ? v * r : v / r; ws(); } return v; }
  function expr() { let v = term(); ws(); while (s[i] === '+' || s[i] === '-') { const o = s[i++]; const r = term(); v = o === '+' ? v + r : v - r; ws(); } return v; }
  try { const v = expr(); return isFinite(v) ? v : 0; } catch (e) { return 0; }
}
// avancement avec accélération / décélération (vitesse en trapèze, comme PowerPoint)
function ease(p, a, d) {
  if (!a && !d) return p;
  const r = 1 / (1 - a / 2 - d / 2);
  if (p < a) return r * p * p / (2 * a);
  if (p <= 1 - d) return r * (p - a / 2);
  const q = 1 - p;
  return 1 - r * q * q / (2 * d);
}
// chemin d'une trajectoire (« M 0 0 L 0.2 0.5 C … E ») -> fonction p -> [dx, dy] en fractions de la diapo
function motionPath(str) {
  // nombres avec exposant (« -5.55112E-17 », écrit par PowerPoint) : le E n'y est pas la commande « fin »
  const tok = String(str || '').match(/[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?|[MLCZEmlcze]/g) || [];
  const segs = [];
  let i = 0, cx = 0, cy = 0, sx = 0, sy = 0, cmd = 'M';
  const n = () => parseFloat(tok[i++]) || 0;
  while (i < tok.length) {
    const t = tok[i];
    if (/^[MLCZEmlcze]$/.test(t)) { cmd = t; i++; if (/[Zz]/.test(cmd)) { segs.push({ k: 'L', a: [cx, cy], b: [sx, sy] }); cx = sx; cy = sy; } if (/[Ee]/.test(cmd)) break; continue; }
    if (cmd === 'M' || cmd === 'm') { const x = n(), y = n(); cx = cmd === 'm' ? cx + x : x; cy = cmd === 'm' ? cy + y : y; sx = cx; sy = cy; cmd = cmd === 'm' ? 'l' : 'L'; }
    else if (cmd === 'L' || cmd === 'l') { const x = n(), y = n(); const nx = cmd === 'l' ? cx + x : x, ny = cmd === 'l' ? cy + y : y; segs.push({ k: 'L', a: [cx, cy], b: [nx, ny] }); cx = nx; cy = ny; }
    else if (cmd === 'C' || cmd === 'c') { const p = [n(), n(), n(), n(), n(), n()]; const o = cmd === 'c' ? [cx, cy] : [0, 0]; const c1 = [p[0] + o[0], p[1] + o[1]], c2 = [p[2] + o[0], p[3] + o[1]], e = [p[4] + o[0], p[5] + o[1]]; segs.push({ k: 'C', a: [cx, cy], c1, c2, b: e }); cx = e[0]; cy = e[1]; }
    else i++;
  }
  const start = segs.length ? segs[0].a : [cx, cy];
  // longueur de chaque segment (échantillonnée) pour avancer à vitesse régulière
  const at = (sg, t) => {
    if (sg.k === 'L') return [lerp(sg.a[0], sg.b[0], t), lerp(sg.a[1], sg.b[1], t)];
    const u = 1 - t;
    return [u * u * u * sg.a[0] + 3 * u * u * t * sg.c1[0] + 3 * u * t * t * sg.c2[0] + t * t * t * sg.b[0], u * u * u * sg.a[1] + 3 * u * u * t * sg.c1[1] + 3 * u * t * t * sg.c2[1] + t * t * t * sg.b[1]];
  };
  const lens = segs.map(sg => { if (sg.k === 'L') return Math.hypot(sg.b[0] - sg.a[0], sg.b[1] - sg.a[1]); let L = 0, p = sg.a; for (let k = 1; k <= 20; k++) { const q = at(sg, k / 20); L += Math.hypot(q[0] - p[0], q[1] - p[1]); p = q; } return L; });
  const total = lens.reduce((a, b) => a + b, 0);
  return p => {
    if (!segs.length) return start;
    if (!total) return at(segs[segs.length - 1], 1);
    let d = clamp(p, 0, 1) * total;
    for (let k = 0; k < segs.length; k++) { if (d <= lens[k] || k === segs.length - 1) return at(segs[k], lens[k] ? clamp(d / lens[k], 0, 1) : 1); d -= lens[k]; }
    return start;
  };
}
// valeur d'un comportement « anim » à l'avancement p
function animValue(b, p, vars) {
  if (b.tav && b.tav.length) {
    const tv = b.tav.map((t, k) => ({ tm: t.tm != null ? t.tm / 1e5 : (b.tav.length > 1 ? k / (b.tav.length - 1) : 0), v: t.v, f: t.f }));
    const val = x => typeof x === 'number' ? x : evalFormula(x, vars);
    let k = 0;
    while (k < tv.length - 1 && p >= tv[k + 1].tm) k++;
    const a = tv[k], c = tv[Math.min(k + 1, tv.length - 1)];
    if (b.calc === 'discrete' || b.vt === 'str' && typeof a.v === 'string' && !/[#\d]/.test(a.v)) return { v: a.v, str: true };
    const span = c.tm - a.tm;
    const q = span > 0 ? clamp((p - a.tm) / span, 0, 1) : 1;
    const v = a === c ? val(a.v) : lerp(val(a.v), val(c.v), q);
    if (a.f) return { v: evalFormula(a.f, Object.assign({}, vars, { $: v })) };
    return { v };
  }
  const fr = b.from != null ? evalFormula(b.from, vars) : null, to = b.toA != null ? evalFormula(b.toA, vars) : null, by = b.by != null ? evalFormula(b.by, vars) : null;
  if (fr != null && to != null) return { v: lerp(fr, to, p) };
  if (by != null) return { v: by * p, add: true };
  if (to != null) return { v: to, toOnly: true };
  return null;
}
const ENTR_FILTERS = ['fade', 'wipe', 'barn', 'box', 'circle', 'diamond', 'plus', 'wedge', 'wheel', 'slide', 'strips', 'checkerboard', 'blinds', 'randombar', 'dissolve', 'image'];

/* état d'un objet à un instant : { vis, op, dx, dy, sx, sy, rot, cx, cy, wf, hf, clip } */
function baseState() { return { vis: true, op: 1, dx: 0, dy: 0, sx: 1, sy: 1, rot: 0, clip: null }; }

class SlideAnim {
  constructor(slide, deck) {
    this.slide = slide; this.deck = deck;
    const W = deck.W, H = deck.H;
    // objets et groupes : qui est visé par quoi
    this.els = slide.els;
    this.byId = new Map();
    for (const e of slide.els) { if (!this.byId.has(e.id)) this.byId.set(e.id, []); this.byId.get(e.id).push(e); for (const p of e.parents || []) { if (!this.byId.has(p)) this.byId.set(p, []); this.byId.get(p).push(e); } }
    this.steps = (slide.timing && slide.timing.steps || []).filter(s => s.items.length);
    // effets désactivés dans Lanterne PPT : déjà finis dès l'arrivée sur la diapo (pas joués)
    this.pre = (slide.timing && slide.timing.pre) || [];
    const all = [{ items: this.pre }, ...this.steps];
    // paragraphes animés séparément
    this.paraAnim = new Map();
    for (const st of all) for (const b of st.items) if (b.para) { if (!this.paraAnim.has(b.spid)) this.paraAnim.set(b.spid, new Set()); for (let k = b.para[0]; k <= b.para[1]; k++) this.paraAnim.get(b.spid).add(k); }
    // durée de chaque étape
    for (const st of this.steps) st.len = st.items.reduce((m, b) => Math.max(m, b.t + (b.dur || 0) * (isFinite(b.rep) ? b.rep : 1) * (b.autoRev ? 2 : 1)), 0) + (st.delay || 0);
    // visibilité de départ : un objet dont le premier effet est une entrée est caché
    this.initHidden = new Set();
    const seen = new Set();
    for (const st of all) for (const b of st.items) {
      const key = b.spid + (b.para ? '#' + b.para[0] : '');
      if (seen.has(key)) continue;
      seen.add(key);
      if (b.cls === 'entr' || (b.kind === 'set' && b.attrs.includes('style.visibility') && b.to === 'visible' && b.cls !== 'exit')) this.initHidden.add(key);
    }
    this.vars = new Map();
    for (const e of slide.els) this.vars.set(e, { '#ppt_x': (e.x + e.w / 2) / W, '#ppt_y': (e.y + e.h / 2) / H, '#ppt_w': e.w / W, '#ppt_h': e.h / H, '#ppt_r': e.rot || 0 });
  }
  // états de tous les objets : étape k en cours depuis t ms (k = nombre d'étapes déjà lancées, la k-ième en cours)
  states(k, t) {
    const S = new Map();
    const get = key => { let s = S.get(key); if (!s) { s = baseState(); S.set(key, s); } return s; };
    for (const key of this.initHidden) get(key).vis = false;
    for (const b of this.pre) this.apply(b, 1e12, get);
    for (let j = 0; j < k && j < this.steps.length; j++) {
      const st = this.steps[j];
      const tt = j === k - 1 ? t - (st.delay || 0) : 1e12;
      for (const b of st.items) this.apply(b, tt, get);
    }
    return S;
  }
  apply(b, t, get) {
    if (t < b.t) return;
    const dur = b.dur || 0;
    const rep = isFinite(b.rep) ? b.rep : 1e9;
    const total = dur * rep * (b.autoRev ? 2 : 1);
    let local = t - b.t;
    const done = local >= total;
    if (done && b.fill === 'remove' && b.kind !== 'set' && !(b.kind === 'animEffect')) return;
    if (done && b.kind === 'set' && b.fill === 'remove' && dur > 1) return;
    let p;
    if (!dur) p = 1;
    else if (done) p = b.autoRev ? 0 : 1;
    else { const cyc = dur * (b.autoRev ? 2 : 1); let q = (local % cyc) / dur; if (q > 1) q = 2 - q; p = q; }
    p = ease(clamp(p, 0, 1), b.accel, b.decel);
    const targets = this.byId.get(b.spid) || [];
    const keyOf = e => e.id + (b.para ? '#' + b.para[0] : '');
    const keys = b.para ? [b.spid + '#' + b.para[0]] : targets.length ? targets.map(e => e.id) : [b.spid];
    const W = this.deck.W, H = this.deck.H;
    keys.forEach((key, ix) => {
      const el = targets[ix] || targets[0];
      const s = get(b.para ? key : key);
      const vars = el ? this.vars.get(el) : { '#ppt_x': 0.5, '#ppt_y': 0.5, '#ppt_w': 0, '#ppt_h': 0, '#ppt_r': 0 };
      switch (b.kind) {
        case 'set':
          if (b.attrs.includes('style.visibility')) s.vis = b.to === 'visible';
          else if (b.attrs.includes('style.opacity')) s.op = +b.to;
          break;
        case 'animEffect': {
          if (done) { s.clip = null; if (b.tr === 'out') s.vis = false; break; }
          const name = String(b.filter || 'fade').split(/[\s(]/)[0];
          const arg = (/\(([^)]*)\)/.exec(b.filter || '') || [])[1] || '';
          if (b.tr === 'in') s.vis = true;
          s.clip = { f: ENTR_FILTERS.includes(name) ? name : 'fade', arg, p: b.tr === 'out' ? 1 - p : p };
          break;
        }
        case 'anim': {
          const v = animValue(b, p, vars);
          if (!v) break;
          for (const a of b.attrs) {
            if (a === 'ppt_x') s.cx = v.add ? vars['#ppt_x'] + v.v : v.v;
            else if (a === 'ppt_y') s.cy = v.add ? vars['#ppt_y'] + v.v : v.v;
            else if (a === 'ppt_w') s.wf = v.v;
            else if (a === 'ppt_h') s.hf = v.v;
            else if (a === 'r' || a === 'style.rotation' || a === 'ppt_r') s.rot = v.add ? s.rot + v.v : v.v - (vars['#ppt_r'] || 0);
            else if (a === 'style.opacity') s.op = clamp(+v.v, 0, 1);
            else if (a === 'style.visibility') s.vis = v.v === 'visible';
          }
          break;
        }
        case 'animMotion': {
          let d;
          if (b.path) d = (b._mp || (b._mp = motionPath(b.path)))(p);
          else if (b.byXY) d = [b.byXY[0] * p, b.byXY[1] * p];
          else if (b.fromXY && b.toXY) d = [lerp(b.fromXY[0], b.toXY[0], p), lerp(b.fromXY[1], b.toXY[1], p)];
          else d = [0, 0];
          s.dx += d[0] * W; s.dy += d[1] * H;
          break;
        }
        case 'animScale': {
          let x = 1, y = 1;
          if (b.from && b.to) { x = lerp(b.from[0], b.to[0], p); y = lerp(b.from[1], b.to[1], p); }
          else if (b.to) { x = lerp(1, b.to[0], p); y = lerp(1, b.to[1], p); }
          else if (b.by) { x = lerp(1, b.by[0], p); y = lerp(1, b.by[1], p); }
          s.sx *= x; s.sy *= y; break;
        }
        case 'animRot': s.rot += b.from != null && b.to != null ? lerp(b.from, b.to, p) : (b.by || 0) * p; break;
      }
    });
  }
  // fin de l'étape k (ms depuis son départ)
  stepLen(k) { const st = this.steps[k]; return st ? st.len : 0; }
}

/* ================= dessin d'une diapo ================= */
// view : { x, y, w, h } zone de la diapo sur le canevas (pixels) ; S : états d'animation ; media : Map id -> élément vidéo
function drawBg(ctx, slide, view) {
  const bg = slide.bg;
  ctx.save();
  ctx.beginPath(); ctx.rect(view.x, view.y, view.w, view.h); ctx.clip();
  if (!bg || bg.type === 'none') { ctx.fillStyle = '#fff'; ctx.fillRect(view.x, view.y, view.w, view.h); }
  else if (bg.type === 'blip') {
    ctx.fillStyle = '#fff'; ctx.fillRect(view.x, view.y, view.w, view.h);
    const e = loadImg(bg.url);
    if (e && e.ok) { if (bg.filters && bg.filters.length) ctx.filter = bg.filters.join(' '); ctx.globalAlpha = bg.alpha; drawCropped(ctx, e.img, bg, view.x, view.y, view.w, view.h); ctx.filter = 'none'; }
  } else { const p = paintOf(ctx, bg, view.x, view.y, view.w, view.h); ctx.fillStyle = p && typeof p !== 'object' || (p && p.addColorStop) ? p : '#fff'; ctx.fillRect(view.x, view.y, view.w, view.h); }
  ctx.restore();
}
// pose d'une vignette : boîte (x,y,w,h en EMU), rotation, miroirs, opacité, découpe d'animation
function placeSprite(ctx, spr, el, box, s, alpha, clip, sx = 1, sy = 1) {
  if (alpha <= 0.001) return;
  const w = box.w * s, h = box.h * s;
  const cx = box.x * s + w / 2, cy = box.y * s + h / 2;
  // la vignette a été faite pour la taille d'origine : mise à l'échelle si la boîte a changé (Morph, ppt_w…)
  const kx = el.w ? box.w / el.w : 1, ky = el.h ? box.h / el.h : 1;
  ctx.save();
  ctx.translate(cx, cy);
  if (box.rot) ctx.rotate(box.rot * DEG);
  ctx.scale((box.flipH ? -1 : 1) * kx * sx, (box.flipV ? -1 : 1) * ky * sy);
  const ew = el.w * s, eh = el.h * s;
  ctx.translate(-ew / 2, -eh / 2);
  if (clip && clip.f !== 'fade' && clip.f !== 'dissolve') clipShape(ctx, clip, ew, eh, spr);
  ctx.globalAlpha *= alpha * (clip && (clip.f === 'fade' || clip.f === 'dissolve') ? clip.p : 1);
  if (clip && clip.f === 'slide') { const d = slideOffset(clip, ew, eh); ctx.translate(d[0], d[1]); }
  ctx.drawImage(spr.cv, -spr.ox, -spr.oy);
  ctx.restore();
}
function slideOffset(clip, w, h) {
  const q = 1 - clip.p, a = clip.arg || 'fromBottom';
  return a === 'fromTop' ? [0, -h * q] : a === 'fromLeft' ? [-w * q, 0] : a === 'fromRight' ? [w * q, 0] : [0, h * q];
}
// découpe des effets d'entrée et de sortie (balayage, barres, forme…)
function clipShape(ctx, clip, w, h, spr) {
  const p = clamp(clip.p, 0, 1), a = clip.arg || '';
  const big = 1e5, X = -big, Y = -big;
  ctx.beginPath();
  switch (clip.f) {
    case 'wipe':
      if (a === 'up') ctx.rect(X, h - h * p, big * 2, big);
      else if (a === 'down') ctx.rect(X, Y, big * 2, big + h * p);
      else if (a === 'left') ctx.rect(w - w * p, Y, big, big * 2);
      else ctx.rect(X, Y, big + w * p, big * 2);
      break;
    case 'barn': if (/Vertical/.test(a)) { const half = w * p / 2; ctx.rect(w / 2 - half, Y, half * 2, big * 2); } else { const half = h * p / 2; ctx.rect(X, h / 2 - half, big * 2, half * 2); } break;
    case 'box': case 'plus': { const hw = w * p / 2, hh = h * p / 2; if (/out/.test(a)) { ctx.rect(X, Y, big * 2, big * 2); ctx.rect(w / 2 + hw, h / 2 - hh, -hw * 2, hh * 2); } else ctx.rect(w / 2 - hw, h / 2 - hh, hw * 2, hh * 2); break; }
    case 'circle': { const r = Math.hypot(w, h) / 2 * p; ctx.ellipse(w / 2, h / 2, r * w / Math.hypot(w, h) * 1.42, r * h / Math.hypot(w, h) * 1.42, 0, 0, Math.PI * 2); break; }
    case 'diamond': { const rx = w * p, ry = h * p; ctx.moveTo(w / 2, h / 2 - ry); ctx.lineTo(w / 2 + rx, h / 2); ctx.lineTo(w / 2, h / 2 + ry); ctx.lineTo(w / 2 - rx, h / 2); ctx.closePath(); break; }
    case 'wedge': case 'wheel': { const r = Math.hypot(w, h); ctx.moveTo(w / 2, h / 2); ctx.arc(w / 2, h / 2, r, -Math.PI / 2 - Math.PI * p, -Math.PI / 2 + Math.PI * p); ctx.closePath(); break; }
    case 'strips': case 'blinds': case 'randombar': case 'checkerboard': {
      const n = 8;
      if (/vertical|across/i.test(a)) for (let k = 0; k < n; k++) ctx.rect(k * w / n, Y, w / n * p, big * 2);
      else for (let k = 0; k < n; k++) ctx.rect(X, k * h / n, big * 2, h / n * p);
      break;
    }
    default: ctx.rect(X, Y, big * 2, big * 2);
  }
  ctx.clip();
}
// boîte animée d'un objet (EMU)
function animBox(el, st, deck) {
  let x = el.x, y = el.y, w = el.w, h = el.h;
  if (st) {
    if (st.wf != null) { const nw = st.wf * deck.W; x += (w - nw) / 2; w = nw; }
    if (st.hf != null) { const nh = st.hf * deck.H; y += (h - nh) / 2; h = nh; }
    if (st.cx != null) x = st.cx * deck.W - w / 2;
    if (st.cy != null) y = st.cy * deck.H - h / 2;
    x += st.dx; y += st.dy;
  }
  return { x, y, w, h, rot: (el.rot || 0) + (st ? st.rot : 0), flipH: el.flipH, flipV: el.flipV };
}
// une diapo entière dans ctx ; s = pixels par EMU ; (ox, oy) = coin de la diapo
function drawSlide(ctx, deck, slide, anim, S, view, media, opt = {}) {
  const s = view.w / deck.W;
  const theme = deck.themeFonts;
  if (!opt.noBg) drawBg(ctx, slide, view);
  ctx.save();
  ctx.beginPath(); ctx.rect(view.x, view.y, view.w, view.h); ctx.clip();
  ctx.translate(view.x, view.y);
  for (const el of slide.els) {
    if (opt.skip && opt.skip.has(el)) continue;
    drawElement(ctx, deck, el, anim, S, s, media, theme, opt.alpha != null ? opt.alpha : 1);
  }
  ctx.restore();
}
function stateFor(el, S) {
  if (!S) return null;
  let st = S.get(el.id) || null;
  // groupes : l'état du groupe s'ajoute à celui de l'objet
  for (const p of el.parents || []) {
    const g = S.get(p); if (!g) continue;
    if (!st) st = baseState(); else st = Object.assign({}, st);
    st.vis = st.vis && g.vis; st.op *= g.op; st.dx += g.dx; st.dy += g.dy; st.rot += g.rot; st.sx *= g.sx; st.sy *= g.sy; if (g.clip && !st.clip) st.clip = g.clip;
  }
  return st;
}
function drawElement(ctx, deck, el, anim, S, s, media, theme, alpha, boxOverride) {
  if (el.kind === 'audio' && !el.img) return;
  const st = stateFor(el, S);
  const paras = anim && anim.paraAnim.get(el.id);
  if (st && !st.vis && !paras) return;
  const box = boxOverride || animBox(el, st, deck);
  const op = (st ? st.op : 1) * alpha;
  if (el.kind === 'video' || el.kind === 'audio') {
    const v = media && media.get(el);
    if (v && v.started && v.readyState >= 2 && v.videoWidth && el.kind === 'video') {
      // image vidéo du moment, posée dans la boîte (pas de cache)
      ctx.save();
      const w = box.w * s, h = box.h * s;
      ctx.translate(box.x * s + w / 2, box.y * s + h / 2);
      if (box.rot) ctx.rotate(box.rot * DEG);
      ctx.scale(box.flipH ? -1 : 1, box.flipV ? -1 : 1);
      ctx.translate(-w / 2, -h / 2);
      ctx.globalAlpha *= op * (st && st.clip && st.clip.f === 'fade' ? st.clip.p : 1);
      if (st && st.clip && st.clip.f !== 'fade') clipShape(ctx, st.clip, w, h);
      paintElement(ctx, el, w, h, s, theme, { frame: v });
      ctx.restore();
      return;
    }
  }
  if (!paras) {
    const spr = SPR.get(el, s, theme);
    placeSprite(ctx, spr, el, box, s, op, st && st.clip, st ? st.sx : 1, st ? st.sy : 1);
    return;
  }
  // texte animé par paragraphe : la forme, puis chaque paragraphe avec son propre état
  if (!st || st.vis) placeSprite(ctx, SPR.get(el, s, theme, 'shape'), el, box, s, op, st && st.clip, st ? st.sx : 1, st ? st.sy : 1);
  el.text.paras.forEach((_, pi) => {
    const ps = S && S.get(el.id + '#' + pi);
    const vis = ps ? ps.vis : (st ? st.vis : true);
    if (!vis) return;
    const b2 = ps ? animBox(el, Object.assign({}, ps, { dx: ps.dx + (st ? st.dx : 0), dy: ps.dy + (st ? st.dy : 0) }), deck) : box;
    placeSprite(ctx, SPR.get(el, s, theme, pi), el, b2, s, op * (ps ? ps.op : 1), ps && ps.clip, ps ? ps.sx : 1, ps ? ps.sy : 1);
  });
}

/* ================= transitions ================= */
const easeInOut = p => p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2;
// compose : drawA(ctx) et drawB(ctx) dessinent les diapos dans le canevas ; p de 0 à 1
function composeTransition(ctx, tr, p, view, drawA, drawB, layer) {
  const type = tr.type;
  const { x, y, w, h } = view;
  const dirv = d => ({ l: [-1, 0], r: [1, 0], u: [0, -1], d: [0, 1], lu: [-1, -1], ru: [1, -1], ld: [-1, 1], rd: [1, 1] })[d] || [-1, 0];
  const q = easeInOut(p);
  switch (type) {
    case 'fade': drawA(ctx); ctx.save(); ctx.globalAlpha = p; drawB(ctx); ctx.restore(); return;
    case 'fadeBlack': if (p < 0.5) { drawA(ctx); ctx.fillStyle = `rgba(0,0,0,${p * 2})`; ctx.fillRect(x, y, w, h); } else { drawB(ctx); ctx.fillStyle = `rgba(0,0,0,${(1 - p) * 2})`; ctx.fillRect(x, y, w, h); } return;
    case 'flash': if (p < 0.5) { drawA(ctx); ctx.fillStyle = `rgba(255,255,255,${p * 2})`; ctx.fillRect(x, y, w, h); } else { drawB(ctx); ctx.fillStyle = `rgba(255,255,255,${(1 - p) * 2})`; ctx.fillRect(x, y, w, h); } return;
    case 'push': case 'pull': case 'cover': {
      // push : A sort et B entre ; cover : B glisse sur A ; pull : A glisse et découvre B
      const v = dirv(tr.dir || (type === 'push' ? 'u' : 'l'));
      // dir = côté d'où vient le mouvement (PowerPoint : « depuis la droite » = l pour poussée)
      const mx = -v[0] * w, my = -v[1] * h;
      ctx.save(); ctx.beginPath(); ctx.rect(x, y, w, h); ctx.clip();
      if (type === 'push') { ctx.save(); ctx.translate(mx * q, my * q); drawA(ctx); ctx.restore(); ctx.save(); ctx.translate(-mx * (1 - q), -my * (1 - q)); drawB(ctx); ctx.restore(); }
      else if (type === 'cover') { drawA(ctx); ctx.save(); ctx.translate(-mx * (1 - q), -my * (1 - q)); drawB(ctx); ctx.restore(); }
      else { drawB(ctx); ctx.save(); ctx.translate(mx * q, my * q); drawA(ctx); ctx.restore(); }
      ctx.restore(); return;
    }
    case 'wipe': {
      const d = tr.dir || 'l';
      drawA(ctx); ctx.save(); ctx.beginPath();
      if (d === 'l') ctx.rect(x + w * (1 - q), y, w * q, h); else if (d === 'r') ctx.rect(x, y, w * q, h); else if (d === 'u') ctx.rect(x, y + h * (1 - q), w, h * q); else ctx.rect(x, y, w, h * q);
      ctx.clip(); drawB(ctx); ctx.restore(); return;
    }
    case 'split': {
      drawA(ctx); ctx.save(); ctx.beginPath();
      const out = tr.inOut !== 'in';
      if (tr.orient === 'vert') { const hw = w * q / 2; if (out) ctx.rect(x + w / 2 - hw, y, hw * 2, h); else { ctx.rect(x, y, hw, h); ctx.rect(x + w - hw, y, hw, h); } }
      else { const hh = h * q / 2; if (out) ctx.rect(x, y + h / 2 - hh, w, hh * 2); else { ctx.rect(x, y, w, hh); ctx.rect(x, y + h - hh, w, hh); } }
      ctx.clip(); drawB(ctx); ctx.restore(); return;
    }
    case 'circle': case 'diamond': case 'plus': {
      drawA(ctx); ctx.save(); ctx.beginPath();
      const cx = x + w / 2, cy = y + h / 2, R = Math.hypot(w, h) / 2 * q;
      if (type === 'circle') ctx.arc(cx, cy, R, 0, Math.PI * 2);
      else if (type === 'diamond') { ctx.moveTo(cx, cy - R * 1.42); ctx.lineTo(cx + R * 1.42, cy); ctx.lineTo(cx, cy + R * 1.42); ctx.lineTo(cx - R * 1.42, cy); ctx.closePath(); }
      else { ctx.rect(cx - w * q / 2, cy - h * q / 6, w * q, h * q / 3); ctx.rect(cx - w * q / 6, cy - h * q / 2, w * q / 3, h * q); }
      ctx.clip(); drawB(ctx); ctx.restore(); return;
    }
    case 'zoom': {
      drawA(ctx); ctx.save(); ctx.globalAlpha = q;
      const k = tr.inOut === 'out' ? 1.4 - 0.4 * q : 0.6 + 0.4 * q;
      ctx.translate(x + w / 2, y + h / 2); ctx.scale(k, k); ctx.translate(-x - w / 2, -y - h / 2);
      drawB(ctx); ctx.restore(); return;
    }
    default: (p < 1 ? drawA : drawB)(ctx);
  }
}

/* ----- Morph : objets appariés d'une diapo à l'autre ----- */
function morphPairs(A, B) {
  const pairs = [], usedA = new Set(), usedB = new Set();
  const sig = e => e.kind + '|' + (e.img && e.img.url || '') + '|' + (e.text ? e.text.paras.map(p => p.runs.map(r => r.t).join('')).join('\n') : '') + '|' + (e.geom && e.geom.prst || '');
  const tryMatch = fn => {
    for (const b of B.els) {
      if (usedB.has(b)) continue;
      const a = A.els.find(x => !usedA.has(x) && fn(x, b));
      if (a) { usedA.add(a); usedB.add(b); pairs.push([a, b]); }
    }
  };
  tryMatch((a, b) => /^!!/.test(b.name) && a.name === b.name);
  tryMatch((a, b) => a.name === b.name && a.kind === b.kind && sig(a) === sig(b));
  tryMatch((a, b) => a.kind === b.kind && sig(a) === sig(b) && a.kind !== 'shape');
  tryMatch((a, b) => a.name === b.name && a.kind === b.kind && a.name && !/^(ZoneTexte|TextBox|Text Box)/i.test(a.name));
  tryMatch((a, b) => a.kind === 'shape' && b.kind === 'shape' && !a.text && !b.text && a.geom && b.geom && a.geom.prst === b.geom.prst && a.layer === b.layer);
  return { pairs, onlyA: A.els.filter(e => !usedA.has(e)), onlyB: B.els.filter(e => !usedB.has(e)) };
}
function sameLook(a, b) {
  if (a.kind !== b.kind) return false;
  if (a.kind === 'pic' || a.kind === 'video') return (a.img && a.img.url) === (b.img && b.img.url);
  return JSON.stringify([a.text, a.fill, a.line, a.geom]) === JSON.stringify([b.text, b.fill, b.line, b.geom]) && Math.abs(a.w - b.w) < 2 && Math.abs(a.h - b.h) < 2;
}
function drawMorph(ctx, deck, A, SA, animA, B, SB, animB, p, view, media) {
  const q = easeInOut(clamp(p, 0, 1));
  const s = view.w / deck.W;
  const theme = deck.themeFonts;
  const M = A._morph && A._morph.to === B ? A._morph.m : (A._morph = { to: B, m: morphPairs(A, B) }).m;
  // fond : fondu si les deux fonds diffèrent
  // (celui d'arrivée dessous : un objet qui disparaît le laisse apparaître sans assombrir l'image)
  if (JSON.stringify(A.bg) !== JSON.stringify(B.bg)) { drawBg(ctx, B, view); ctx.save(); ctx.globalAlpha = 1 - q; drawBg(ctx, A, view); ctx.restore(); }
  else drawBg(ctx, A, view);
  ctx.save();
  ctx.beginPath(); ctx.rect(view.x, view.y, view.w, view.h); ctx.clip();
  ctx.translate(view.x, view.y);
  // ordre : celui de la diapo d'arrivée, les objets qui disparaissent d'abord
  for (const a of M.onlyA) drawElement(ctx, deck, a, animA, SA, s, media, theme, 1 - q);
  const pairOfB = new Map(M.pairs.map(([a, b]) => [b, a]));
  for (const b of B.els) {
    const a = pairOfB.get(b);
    if (!a) { drawElement(ctx, deck, b, animB, SB, s, media, theme, q); continue; }
    const sa = stateFor(a, SA), sb = stateFor(b, SB);
    const ba = animBox(a, sa, deck), bb = animBox(b, sb, deck);
    const box = { x: lerp(ba.x, bb.x, q), y: lerp(ba.y, bb.y, q), w: lerp(ba.w, bb.w, q), h: lerp(ba.h, bb.h, q), rot: lerp(ba.rot, bb.rot, q), flipH: b.flipH, flipV: b.flipV };
    const va = sa ? (sa.vis ? sa.op : 0) : 1, vb = sb ? (sb.vis ? sb.op : 0) : 1;
    if (sameLook(a, b)) drawElement(ctx, deck, b, animB, null, s, media, theme, lerp(va, vb, q), box);
    else {
      drawElement(ctx, deck, a, animA, null, s, media, theme, va * (1 - q), box);
      drawElement(ctx, deck, b, animB, null, s, media, theme, vb * q, box);
    }
  }
  ctx.restore();
}

window.LanterneRendu = {
  setPresets, setFontResolver, shapePaths, loadImg, IMG, SPR, SlideAnim, drawSlide, drawBg, drawElement, composeTransition, drawMorph, easeInOut, evalFormula, motionPath,
  clearCache: () => { SPR.gen++; metricCache.clear(); },
};
})();
