#!/bin/bash
# Écran Hall — retire l'appli « Écran Hall » du boîtier TV (le diaporama gardé sur le boîtier part avec elle).
OUTILS="$HOME/Library/Application Support/Écran Hall/outils-android"
PKG="fr.lanterne.ecranhall"
ADB="$OUTILS/platform-tools/adb"
THOMSON="$(ls -d "$HOME"/Desktop/donn*e/thomson 2>/dev/null | head -1)"
[ -x "$ADB" ] || ADB="$THOMSON/platform-tools/adb"
[ -x "$ADB" ] || { echo "adb introuvable : lance d'abord « Installer sur le boîtier TV »."; read -r -p "Entrée pour fermer." _; exit 1; }
ANCIENNE="$(cat "$OUTILS/derniere-adresse.txt" 2>/dev/null)"
read -r -p "Adresse IP du boîtier${ANCIENNE:+ [Entrée = $ANCIENNE]} : " IP
IP="${IP:-$ANCIENNE}"; IP="$(echo "$IP" | tr -d ' ')"
case "$IP" in *:*) CIBLE="$IP" ;; *) CIBLE="$IP:5555" ;; esac
"$ADB" connect "$CIBLE" >/dev/null 2>&1; sleep 2
[ "$("$ADB" -s "$CIBLE" get-state 2>/dev/null)" = "device" ] || { echo "Boîtier injoignable ($CIBLE)."; read -r -p "Entrée pour fermer." _; exit 1; }
read -r -p "Retirer Écran Hall du boîtier $CIBLE ? (o/n) " R
case "$R" in o|O|oui) ;; *) exit 0 ;; esac
"$ADB" -s "$CIBLE" shell dumpsys deviceidle whitelist -$PKG >/dev/null 2>&1
"$ADB" -s "$CIBLE" uninstall "$PKG"
echo "Terminé."
read -r -p "Entrée pour fermer." _
