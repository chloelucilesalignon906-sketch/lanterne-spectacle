package fr.lanterne.ecranhall;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * Dessin de tout l'écran, tourné selon l'orientation de la télé :
 *  paysage = tel quel ; portrait-droite = télé tournée d'un quart de tour dans le sens des aiguilles d'une montre
 *  (l'image est tournée d'un quart de tour dans l'autre sens) ; portrait-gauche = l'inverse.
 * L'écran d'attente, le bandeau d'informations et la mire de test sont tournés de la même façon (lisibles sur la télé).
 */
class Affichage extends View {
    private Bitmap image, avant;
    private long fonduDebut = 0;
    private int fonduMs = 0;
    String orientation = "paysage", ajuste = "contenir";
    int fond = Color.BLACK;
    boolean noir = false;
    List<String> attente = null;          // lignes de l'écran d'attente (pas de diaporama)
    List<String> info = null;             // bandeau d'informations (touche OK de la télécommande)
    String test = null;                   // mire de test : orientation essayée
    String pause = null;                  // petit « pause » en coin
    boolean video = false;                // 1.2 : vidéo en cours, jouée dessous (TextureView) : rien n'est dessiné par-dessus

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final RectF r = new RectF();

    Affichage(Context c) {
        super(c);
        // pas de fond : la vidéo (1.2) est jouée sous cette vue ; le noir est dessiné dans onDraw
        setKeepScreenOn(true);
    }

    /** Nouvelle image ; fondu enchaîné depuis la précédente si ms > 0. */
    void montrer(Bitmap b, int ms) {
        Bitmap ancienne = image;
        if (avant != null && avant != b && avant != ancienne && !avant.isRecycled()) avant.recycle();
        if (ms > 0 && ancienne != null && ancienne != b) avant = ancienne;
        else {
            avant = null;
            if (ancienne != null && ancienne != b && !ancienne.isRecycled()) ancienne.recycle();
        }
        image = b;
        fonduMs = ms;
        fonduDebut = SystemClock.uptimeMillis();
        invalidate();
    }

    void vider() { montrer(null, 0); if (avant != null && !avant.isRecycled()) avant.recycle(); avant = null; }

    static int rotation(String o) { return "portrait-droite".equals(o) ? -90 : "portrait-gauche".equals(o) ? 90 : 0; }

    @Override
    protected void onDraw(Canvas c) {
        int W = getWidth(), H = getHeight();
        boolean transparent = video && test == null && !noir;
        if (!transparent) c.drawColor(Color.BLACK);
        String o = test != null ? test : orientation;
        int rot = rotation(o);
        boolean tourne = rot != 0;
        float cw = tourne ? H : W, ch = tourne ? W : H;      // taille de l'image vue sur la télé
        c.save();
        c.translate(W / 2f, H / 2f);
        c.rotate(rot);
        c.translate(-cw / 2f, -ch / 2f);
        boolean anime = false;
        if (test != null) mire(c, cw, ch, o);
        else if (noir) { /* noir */ }
        else if (video) { if (pause != null) coin(c, cw, ch, pause); }
        else if (image == null && attente != null) lignes(c, cw, ch, attente, true);
        else {
            p.setColor(fond); p.setAlpha(255); c.drawRect(0, 0, cw, ch, p);
            float k = 1f;
            if (fonduMs > 0 && avant != null) {
                k = Math.min(1f, (SystemClock.uptimeMillis() - fonduDebut) / (float) fonduMs);
                dessiner(c, avant, cw, ch, 255);
                if (k < 1f) anime = true;
                else { if (!avant.isRecycled() && avant != image) avant.recycle(); avant = null; }
            }
            if (image != null) dessiner(c, image, cw, ch, (int) (255 * k));
            if (pause != null) coin(c, cw, ch, pause);
        }
        if (info != null && test == null) lignes(c, cw, ch, info, false);
        c.restore();
        if (anime) postInvalidateOnAnimation();
    }

    private void dessiner(Canvas c, Bitmap b, float cw, float ch, int alpha) {
        if (b == null || b.isRecycled()) return;
        float bw = b.getWidth(), bh = b.getHeight();
        float k = "remplir".equals(ajuste) ? Math.max(cw / bw, ch / bh) : Math.min(cw / bw, ch / bh);
        float dw = bw * k, dh = bh * k;
        r.set((cw - dw) / 2f, (ch - dh) / 2f, (cw + dw) / 2f, (ch + dh) / 2f);
        p.setAlpha(alpha);
        c.drawBitmap(b, null, r, p);
        p.setAlpha(255);
    }

    private void lignes(Canvas c, float cw, float ch, List<String> l, boolean pleinEcran) {
        float u = Math.min(cw, ch) / 24f;                  // unité de taille de texte
        if (pleinEcran) { p.setColor(Color.rgb(16, 18, 24)); c.drawRect(0, 0, cw, ch, p); }
        float hauteur = u * 1.9f * l.size() + u * 2f;
        float y0 = pleinEcran ? (ch - hauteur) / 2f : ch - hauteur - u * 2f;
        if (!pleinEcran) {
            p.setColor(Color.argb(215, 10, 12, 16));
            r.set(u, y0, cw - u, y0 + hauteur);
            c.drawRoundRect(r, u * 0.6f, u * 0.6f, p);
        }
        p.setTextAlign(Paint.Align.CENTER);
        float y = y0 + u * 2.2f;
        for (int i = 0; i < l.size(); i++) {
            boolean titre = i == 0;
            p.setTypeface(titre ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            p.setTextSize(titre ? u * 1.5f : u * 0.95f);
            p.setColor(titre ? Color.rgb(255, 196, 64) : Color.rgb(230, 232, 238));
            c.drawText(l.get(i), cw / 2f, y, p);
            y += u * 1.9f;
        }
        p.setTextAlign(Paint.Align.LEFT);
        p.setTypeface(Typeface.DEFAULT);
    }

    private void coin(Canvas c, float cw, float ch, String t) {
        float u = Math.min(cw, ch) / 30f;
        p.setTextSize(u);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        float w = p.measureText(t) + u * 1.4f;
        p.setColor(Color.argb(190, 0, 0, 0));
        r.set(cw - w - u, u, cw - u, u * 2.8f);
        c.drawRoundRect(r, u * 0.4f, u * 0.4f, p);
        p.setColor(Color.WHITE);
        c.drawText(t, cw - w - u + u * 0.7f, u * 2.25f, p);
        p.setTypeface(Typeface.DEFAULT);
    }

    /** Mire de test : flèche vers le haut et texte ; si on la lit à l'endroit sur la télé, l'orientation est la bonne. */
    private void mire(Canvas c, float cw, float ch, String o) {
        p.setColor(Color.rgb(20, 60, 120)); c.drawRect(0, 0, cw, ch, p);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Math.min(cw, ch) / 60f); p.setColor(Color.rgb(255, 196, 64));
        r.set(p.getStrokeWidth(), p.getStrokeWidth(), cw - p.getStrokeWidth(), ch - p.getStrokeWidth());
        c.drawRect(r, p);
        p.setStyle(Paint.Style.FILL);
        float u = Math.min(cw, ch) / 14f;
        Path f = new Path();
        f.moveTo(cw / 2f, u * 1.2f); f.lineTo(cw / 2f + u * 1.6f, u * 3.6f); f.lineTo(cw / 2f + u * 0.55f, u * 3.6f);
        f.lineTo(cw / 2f + u * 0.55f, u * 6f); f.lineTo(cw / 2f - u * 0.55f, u * 6f); f.lineTo(cw / 2f - u * 0.55f, u * 3.6f);
        f.lineTo(cw / 2f - u * 1.6f, u * 3.6f); f.close();
        c.drawPath(f, p);
        List<String> l = new ArrayList<>();
        l.add("HAUT DE L'ÉCRAN");
        l.add("Si tu lis ce texte à l'endroit,");
        l.add("l'orientation est la bonne.");
        l.add(o.equals("paysage") ? "Orientation : paysage" : o.equals("portrait-droite") ? "Orientation : verticale, télé tournée vers la droite" : "Orientation : verticale, télé tournée vers la gauche");
        p.setTextAlign(Paint.Align.CENTER);
        float y = ch / 2f;
        for (int i = 0; i < l.size(); i++) {
            p.setTypeface(i == 0 ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            p.setTextSize(i == 0 ? u * 0.9f : u * 0.5f);
            p.setColor(i == 0 ? Color.rgb(255, 196, 64) : Color.WHITE);
            c.drawText(l.get(i), cw / 2f, y, p);
            y += i == 0 ? u * 1.2f : u * 0.8f;
        }
        p.setTextAlign(Paint.Align.LEFT);
        p.setTypeface(Typeface.DEFAULT);
    }

    /** Taille de l'image vue sur la télé, en pixels (pour décoder les images à la bonne taille). */
    int[] tailleVue() {
        int W = getWidth() > 0 ? getWidth() : getResources().getDisplayMetrics().widthPixels;
        int H = getHeight() > 0 ? getHeight() : getResources().getDisplayMetrics().heightPixels;
        return rotation(orientation) != 0 ? new int[] { H, W } : new int[] { W, H };
    }
}
