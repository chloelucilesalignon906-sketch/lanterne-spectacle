package fr.lanterne.ecranhall;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

/** Lien entre le serveur réseau (fil à part) et l'écran (fil principal) : ce qui est affiché et les demandes reçues. */
final class Etat {
    private Etat() {}

    interface Ecouteur { void demande(String quoi, JSONObject o); }

    // ce que montre l'écran (écrit par MainActivity)
    static volatile int index = 0, nombre = 0;
    static volatile boolean pause = false, noir = false, devant = false;
    static volatile int largeur = 0, hauteur = 0;
    static volatile String titre = "";
    static volatile long recuLe = 0;

    private static final Handler H = new Handler(Looper.getMainLooper());
    private static Ecouteur ecouteur;

    static synchronized void ecouter(Ecouteur e) { ecouteur = e; }
    static synchronized boolean ecoute() { return ecouteur != null; }

    /** Transmet une demande à l'écran (sur le fil principal) ; false si l'écran n'est pas ouvert. */
    static boolean signaler(final String quoi, final JSONObject o) {
        final Ecouteur e;
        synchronized (Etat.class) { e = ecouteur; }
        if (e == null) return false;
        H.post(new Runnable() { public void run() {
            Ecouteur x;
            synchronized (Etat.class) { x = ecouteur; }
            if (x != null) x.demande(quoi, o);
        } });
        return true;
    }
}
