package fr.lanterne.ecranhall;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Boîtier allumé (ou appli mise à jour) : le service démarre (réseau, port 7609) et met le diaporama devant. */
public class Demarrage extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        String a = i.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(a) || "android.intent.action.QUICKBOOT_POWERON".equals(a)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
            EcranService.demarrer(c);
            EcranService.devant(c);
        }
    }
}
