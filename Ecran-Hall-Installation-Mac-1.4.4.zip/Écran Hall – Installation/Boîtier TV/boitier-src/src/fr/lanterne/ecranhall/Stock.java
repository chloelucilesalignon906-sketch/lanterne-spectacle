package fr.lanterne.ecranhall;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.SecureRandom;
import java.util.UUID;

/**
 * Ce que garde le boîtier, même éteint :
 *  - files/actuel/ : le dernier diaporama reçu (diaporama.json + images 001.jpg…) ;
 *  - files/recu/   : le diaporama en cours de réception (remplace « actuel » seulement quand tout est arrivé) ;
 *  - réglages (nom de l'écran, code à 4 chiffres, identifiant, dernière orientation) dans les préférences Android.
 * Écritures atomiques : fichier .tmp puis renommage (comme fiabilite.js de la suite).
 */
final class Stock {
    private Stock() {}

    static final String VERSION = "1.2";

    static File racine(Context c) { return c.getFilesDir(); }
    static File recu(Context c) { return new File(racine(c), "recu"); }

    /** Dossier du diaporama affiché ; rétablit l'ancien si le boîtier s'est éteint au milieu d'un remplacement. */
    static synchronized File actuel(Context c) {
        File a = new File(racine(c), "actuel"), v = new File(racine(c), "ancien");
        if (!new File(a, "diaporama.json").exists() && new File(v, "diaporama.json").exists()) {
            supprimer(a);
            v.renameTo(a);
        }
        return a;
    }

    /** Remplace le diaporama affiché par celui du dossier « recu » (complet et vérifié). */
    static synchronized void installer(Context c, File dossier) throws IOException {
        File a = new File(racine(c), "actuel"), v = new File(racine(c), "ancien");
        supprimer(v);
        if (a.exists() && !a.renameTo(v)) throw new IOException("ancien diaporama impossible à déplacer");
        if (!dossier.renameTo(a)) {
            v.renameTo(a);
            throw new IOException("nouveau diaporama impossible à mettre en place");
        }
        supprimer(v);
    }

    static JSONObject lireDiaporama(Context c) {
        try {
            File f = new File(actuel(c), "diaporama.json");
            if (!f.exists()) return null;
            JSONObject o = new JSONObject(new String(lire(f), "UTF-8"));
            JSONArray l = o.optJSONArray("diapos");
            if (l == null || l.length() == 0) return null;
            return o;
        } catch (Exception e) { return null; }
    }

    /** Réglages changés sans renvoyer les images : réécrit diaporama.json (atomique). */
    static synchronized boolean ecrireDiaporama(Context c, JSONObject o) {
        try { ecrire(new File(actuel(c), "diaporama.json"), o.toString(1).getBytes("UTF-8")); return true; }
        catch (Exception e) { return false; }
    }

    static void ecrire(File f, byte[] d) throws IOException {
        File t = new File(f.getPath() + ".tmp");
        FileOutputStream o = new FileOutputStream(t);
        try { o.write(d); o.getFD().sync(); } finally { o.close(); }
        if (!t.renameTo(f)) { f.delete(); if (!t.renameTo(f)) throw new IOException("renommage impossible : " + f.getName()); }
    }

    static byte[] lire(File f) throws IOException {
        InputStream in = new FileInputStream(f);
        try {
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            byte[] buf = new byte[16384]; int n;
            while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
            return b.toByteArray();
        } finally { in.close(); }
    }

    static void supprimer(File f) {
        if (f == null || !f.exists()) return;
        File[] l = f.listFiles();
        if (l != null) for (File x : l) supprimer(x);
        f.delete();
    }

    /* ---------- réglages ---------- */
    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("ecranhall", Context.MODE_PRIVATE); }

    static String code(Context c) {
        SharedPreferences p = prefs(c);
        String k = p.getString("code", null);
        if (k == null || !k.matches("\\d{4}")) {
            k = String.format("%04d", new SecureRandom().nextInt(10000));
            p.edit().putString("code", k).commit();
        }
        return k;
    }

    static String id(Context c) {
        SharedPreferences p = prefs(c);
        String k = p.getString("id", null);
        if (k == null) { k = UUID.randomUUID().toString().substring(0, 8); p.edit().putString("id", k).commit(); }
        return k;
    }

    static String nom(Context c) { return prefs(c).getString("nom", "Écran Hall"); }
    static void setNom(Context c, String n) { prefs(c).edit().putString("nom", n).commit(); }

    /** Écran noir demandé par l'ordinateur (1.1) : gardé même après un redémarrage du boîtier, jusqu'au retour à l'image. */
    static boolean noir(Context c) { return "1".equals(prefs(c).getString("noir", "0")); }
    static void setNoir(Context c, boolean n) { prefs(c).edit().putString("noir", n ? "1" : "0").commit(); }

    /** Orientation retenue (écran d'attente et mire de test avant le premier diaporama). */
    static String orientation(Context c) { return prefs(c).getString("orientation", "paysage"); }
    static void setOrientation(Context c, String o) { prefs(c).edit().putString("orientation", propreOrientation(o)).commit(); }

    static String propreOrientation(String o) {
        if ("portrait-droite".equals(o) || "portrait-gauche".equals(o)) return o;
        return "paysage";
    }
}
