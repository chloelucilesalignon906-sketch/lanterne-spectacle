package fr.lanterne.ecranhall;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.SurfaceTexture;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Écran Hall : le dernier diaporama reçu, en boucle, en plein écran.
 * Télécommande : OK = informations (adresse, code), ◀ ▶ = diapo précédente / suivante, lecture/pause = pause.
 * 1.2 : vidéos (élément « v ») jouées jusqu'au bout sur une TextureView placée sous l'affichage, tournées comme les images
 * (orientation de la télé + rotation propre de la vidéo « r »), en boucle si elle est seule ; son si « son » est vrai.
 */
public class MainActivity extends Activity implements Etat.Ecouteur {
    private Affichage vue;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final ExecutorService decodeur = Executors.newSingleThreadExecutor();
    private JSONObject dia;            // diaporama affiché (diaporama.json)
    private File dossier;
    private int index = 0;
    private boolean pause = false;
    private int generation = 0;         // change à chaque diaporama : une image décodée pour l'ancien est jetée
    private Bitmap prochaine; private int prochaineIndex = -1;
    // vidéo (1.2)
    private FrameLayout cadre;
    private TextureView ecranVideo;
    private Surface surface;
    private MediaPlayer lecteur;
    private Runnable videoEnAttente;      // vidéo demandée avant que la surface soit prête
    private int videoRot = 0, vW = 0, vH = 0;

    private final Runnable avancer = new Runnable() { public void run() { aller(index + 1, true); } };
    private final Runnable cacherInfo = new Runnable() { public void run() { vue.info = null; vue.invalidate(); } };
    private final Runnable finTest = new Runnable() { public void run() { vue.test = null; vue.invalidate(); } };
    private final Runnable rafraichirAttente = new Runnable() { public void run() { majAttente(); h.postDelayed(this, 5000); } };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        cadre = new FrameLayout(this);
        cadre.setBackgroundColor(Color.BLACK);
        ecranVideo = new TextureView(this);
        ecranVideo.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int hh) {
                surface = new Surface(st);
                if (videoEnAttente != null) { Runnable r = videoEnAttente; videoEnAttente = null; r.run(); }
            }
            public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int hh) {}
            public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                arreterVideo();
                if (surface != null) surface.release();
                surface = null;
                return true;
            }
            public void onSurfaceTextureUpdated(SurfaceTexture st) {}
        });
        cadre.addView(ecranVideo, new FrameLayout.LayoutParams(16, 16, Gravity.CENTER));
        vue = new Affichage(this);
        cadre.addView(vue, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(cadre);
        pleinEcran();
        EcranService.demarrer(this);
        vue.orientation = Stock.orientation(this);
        vue.noir = Stock.noir(this); Etat.noir = vue.noir;
        vue.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            public void onLayoutChange(View v, int l, int t, int r, int bo, int ol, int ot, int or, int ob) {
                if (r - l != or - ol || bo - t != ob - ot) {
                    Etat.largeur = r - l; Etat.hauteur = bo - t;
                    if (dia != null) recharger();     // taille connue : images décodées à la bonne taille
                    cadrerVideo();
                }
            }
        });
        charger(Stock.lireDiaporama(this));
    }

    @Override protected void onResume() { super.onResume(); Etat.devant = true; Etat.ecouter(this); pleinEcran(); }
    @Override protected void onPause() { Etat.devant = false; super.onPause(); }
    @Override protected void onDestroy() { Etat.ecouter(null); h.removeCallbacksAndMessages(null); arreterVideo(); decodeur.shutdownNow(); super.onDestroy(); }
    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) pleinEcran(); }

    @SuppressWarnings("deprecation")
    private void pleinEcran() {
        vue.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    /* ---------------------------------------------------------------- diaporama */
    private void charger(JSONObject d) {
        generation++;
        h.removeCallbacks(avancer);
        h.removeCallbacks(rafraichirAttente);
        if (prochaine != null && !prochaine.isRecycled()) prochaine.recycle();
        prochaine = null; prochaineIndex = -1;
        dia = d;
        dossier = Stock.actuel(this);
        arreterVideo();
        if (d == null) {
            Etat.nombre = 0; Etat.index = 0; Etat.titre = "";
            vue.vider();
            vue.orientation = Stock.orientation(this);
            rafraichirAttente.run();
            return;
        }
        vue.attente = null;
        appliquerReglages(d);
        Etat.nombre = d.optJSONArray("diapos").length();
        Etat.titre = d.optString("titre");
        Etat.recuLe = d.optLong("recuLe");
        index = 0; pause = false; Etat.pause = false; vue.pause = null;
        aller(0, false);
    }

    private void appliquerReglages(JSONObject d) {
        vue.orientation = Stock.propreOrientation(d.optString("orientation"));
        vue.ajuste = "remplir".equals(d.optString("ajuste")) ? "remplir" : "contenir";
        try { vue.fond = Color.parseColor(d.optString("fond", "#000000")); } catch (Exception e) { vue.fond = Color.BLACK; }
    }

    /** Même diaporama, réglages changés (orientation, durées…) : on reste sur la diapo en cours. */
    private void recharger() {
        if (dia == null) return;
        // vidéo en cours : réglages appliqués sans la recommencer
        if (lecteur != null && estVideo(index)) {
            appliquerReglages(dia);
            videoRot = item(index).optInt("r", 0);
            cadrerVideo(); volume(); programmer();
            vue.invalidate();
            return;
        }
        generation++;
        if (prochaine != null && !prochaine.isRecycled()) prochaine.recycle();
        prochaine = null; prochaineIndex = -1;
        appliquerReglages(dia);
        aller(index, false);
    }

    private int nombre() { JSONArray l = dia == null ? null : dia.optJSONArray("diapos"); return l == null ? 0 : l.length(); }
    private JSONObject item(int i) { JSONArray l = dia == null ? null : dia.optJSONArray("diapos"); JSONObject o = l == null ? null : l.optJSONObject(i); return o == null ? new JSONObject() : o; }
    private boolean estVideo(int i) { return item(i).has("v"); }
    private double duree(int i) { JSONObject o = dia.optJSONArray("diapos").optJSONObject(i); double d = o == null ? 8 : o.optDouble("d", 8); return d < 1 ? 1 : d; }

    /** Montre la diapo i (en boucle) ; l'image est décodée hors du fil principal. */
    private void aller(int i, final boolean fondu) {
        h.removeCallbacks(avancer);
        final int n = nombre();
        if (n == 0) return;
        index = ((i % n) + n) % n;
        Etat.index = index;
        final int gen = generation, cible = index;
        final String fichier = dia.optJSONArray("diapos").optJSONObject(index).optString("f");
        if (estVideo(index)) { jouerVideo(new File(dossier, fichier), gen); return; }
        final int ms = fondu && "fondu".equals(dia.optString("transition", "fondu")) && n > 1 && lecteur == null ? 700 : 0;
        if (prochaine != null && prochaineIndex == cible) {
            Bitmap b = prochaine; prochaine = null; prochaineIndex = -1;
            afficher(b, ms, gen, cible);
            return;
        }
        final int[] t = vue.tailleVue();
        decodeur.execute(new Runnable() { public void run() {
            final Bitmap b = decoder(new File(dossier, fichier), t[0], t[1]);
            h.post(new Runnable() { public void run() {
                if (gen != generation || isFinishing()) { if (b != null) b.recycle(); return; }
                afficher(b, ms, gen, cible);
            } });
        } });
    }

    private void afficher(Bitmap b, int ms, int gen, int cible) {
        if (lecteur != null) arreterVideo();
        vue.montrer(b, ms);
        programmer();
        // la suivante est préparée pendant que celle-ci est affichée
        final int n = nombre();
        if (n > 1 && !estVideo((cible + 1) % n)) {
            final int suivante = (cible + 1) % n;
            final String fichier = dia.optJSONArray("diapos").optJSONObject(suivante).optString("f");
            final int[] t = vue.tailleVue();
            final int g = gen;
            decodeur.execute(new Runnable() { public void run() {
                final Bitmap nb = decoder(new File(dossier, fichier), t[0], t[1]);
                h.post(new Runnable() { public void run() {
                    if (g != generation || isFinishing()) { if (nb != null) nb.recycle(); return; }
                    if (prochaine != null && !prochaine.isRecycled()) prochaine.recycle();
                    prochaine = nb; prochaineIndex = suivante;
                } });
            } });
        }
    }

    private void programmer() {
        h.removeCallbacks(avancer);
        if (pause || nombre() <= 1) return;
        // vidéo : suivante à la fin de la lecture ; garde-fou si elle se bloque (durée + 20 s)
        if (estVideo(index)) h.postDelayed(avancer, (long) ((duree(index) + 20) * 1000));
        else h.postDelayed(avancer, (long) (duree(index) * 1000));
    }

    /* ---------------------------------------------------------------- vidéo (1.2) */
    private void jouerVideo(final File f, final int gen) {
        arreterVideo();
        videoRot = item(index).optInt("r", 0);
        vue.video = true;
        vue.invalidate();
        if (surface == null) {
            videoEnAttente = new Runnable() { public void run() { if (gen == generation) jouerVideo(f, gen); } };
            return;
        }
        try {
            final MediaPlayer mp = new MediaPlayer();
            lecteur = mp;
            mp.setSurface(surface);
            mp.setDataSource(f.getPath());
            mp.setLooping(nombre() == 1);
            mp.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() {
                public void onVideoSizeChanged(MediaPlayer m, int w, int hh) { if (m == lecteur) { vW = w; vH = hh; cadrerVideo(); } }
            });
            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                public void onPrepared(MediaPlayer m) {
                    if (m != lecteur || gen != generation) return;
                    volume();
                    if (!pause) m.start();
                }
            });
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                public void onCompletion(MediaPlayer m) { if (m == lecteur && gen == generation && nombre() > 1) aller(index + 1, true); }
            });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                public boolean onError(MediaPlayer m, int what, int extra) {
                    if (m == lecteur && gen == generation) { h.removeCallbacks(avancer); if (nombre() > 1) h.postDelayed(avancer, 1500); }
                    return true;
                }
            });
            mp.prepareAsync();
            cadrerVideo();
            programmer();
        } catch (Exception e) {
            arreterVideo();
            vue.video = true;                       // écran noir plutôt qu'une ancienne image
            if (nombre() > 1) h.postDelayed(avancer, 1500);
        }
    }

    private void arreterVideo() {
        videoEnAttente = null;
        MediaPlayer m = lecteur;
        lecteur = null;
        vW = 0; vH = 0;
        if (m != null) { try { m.stop(); } catch (Exception e) { /* déjà arrêtée */ } try { m.release(); } catch (Exception e) { /* rien */ } }
        if (vue != null) { vue.video = false; vue.invalidate(); }
    }

    /** Son des vidéos : seulement si demandé, et jamais pendant l'écran noir. */
    private void volume() {
        if (lecteur == null) return;
        float v = dia != null && dia.optBoolean("son", false) && !vue.noir ? 1f : 0f;
        try { lecteur.setVolume(v, v); } catch (Exception e) { /* rien */ }
    }

    /** Place la vidéo : tournée (orientation de la télé + rotation de la vidéo) et entière ou en remplissage. */
    private void cadrerVideo() {
        if (cadre == null || ecranVideo == null) return;
        int W = cadre.getWidth(), H = cadre.getHeight();
        if (W <= 0 || H <= 0) return;
        int rot = ((Affichage.rotation(vue.orientation) + videoRot) % 360 + 360) % 360;
        boolean quart = rot == 90 || rot == 270;
        int tw = quart ? H : W, th = quart ? W : H;
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) ecranVideo.getLayoutParams();
        if (lp.width != tw || lp.height != th) { lp.width = tw; lp.height = th; lp.gravity = Gravity.CENTER; ecranVideo.setLayoutParams(lp); }
        ecranVideo.setRotation(rot);
        if (vW > 0 && vH > 0) {
            float k = "remplir".equals(vue.ajuste) ? Math.max(tw / (float) vW, th / (float) vH) : Math.min(tw / (float) vW, th / (float) vH);
            Matrix m = new Matrix();
            m.setScale(vW * k / tw, vH * k / th, tw / 2f, th / 2f);
            ecranVideo.setTransform(m);
        }
    }

    /** Image décodée à peine plus grande que l'écran (mémoire du boîtier). */
    private static Bitmap decoder(File f, int w, int hh) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getPath(), o);
            if (o.outWidth <= 0) return null;
            int s = 1;
            while (w > 0 && hh > 0 && o.outWidth / (s * 2) >= w && o.outHeight / (s * 2) >= hh) s *= 2;
            BitmapFactory.Options d = new BitmapFactory.Options();
            d.inSampleSize = s;
            d.inPreferredConfig = Bitmap.Config.ARGB_8888;
            return BitmapFactory.decodeFile(f.getPath(), d);
        } catch (OutOfMemoryError e) {
            try {
                BitmapFactory.Options d = new BitmapFactory.Options();
                d.inSampleSize = 2; d.inPreferredConfig = Bitmap.Config.RGB_565;
                return BitmapFactory.decodeFile(f.getPath(), d);
            } catch (Throwable t) { return null; }
        } catch (Exception e) { return null; }
    }

    /* ---------------------------------------------------------------- écran d'attente et informations */
    private void majAttente() {
        if (dia != null) return;
        List<String> l = new ArrayList<>();
        l.add(Stock.nom(this));
        l.add("En attente d'un diaporama");
        l.add("Ouvre l'appli « Écran Hall » sur un ordinateur du même réseau");
        String ip = Serveur.ip();
        l.add("Adresse : " + (ip.isEmpty() ? "pas de réseau" : ip));
        l.add("Code : " + Stock.code(this));
        vue.attente = l;
        vue.orientation = Stock.orientation(this);
        vue.invalidate();
    }

    private void montrerInfo() {
        List<String> l = new ArrayList<>();
        l.add(Stock.nom(this));
        String ip = Serveur.ip();
        l.add("Adresse : " + (ip.isEmpty() ? "pas de réseau" : ip) + "    Code : " + Stock.code(this));
        if (dia != null) l.add("« " + dia.optString("titre", "Diaporama") + " » · diapo " + (index + 1) + " / " + nombre() + (pause ? " · en pause" : ""));
        else l.add("Aucun diaporama reçu");
        l.add("◀ ▶ diapo précédente / suivante · lecture/pause · OK ferme ce bandeau");
        l.add("Écran Hall " + Stock.VERSION + " · " + Build.MANUFACTURER + " " + Build.MODEL);
        vue.info = l;
        vue.invalidate();
        h.removeCallbacks(cacherInfo);
        h.postDelayed(cacherInfo, 15000);
    }

    private void basculerPause(Boolean veut) {
        pause = veut != null ? veut : !pause;
        Etat.pause = pause;
        vue.pause = pause ? "❚❚ pause" : null;
        vue.invalidate();
        if (lecteur != null) { try { if (pause) lecteur.pause(); else lecteur.start(); } catch (Exception e) { /* pas encore prête */ } }
        if (pause) h.removeCallbacks(avancer); else programmer();
    }

    /* ---------------------------------------------------------------- demandes reçues par le réseau */
    @Override
    public void demande(String quoi, JSONObject o) {
        switch (quoi) {
            case "diaporama":
                if (dia != null && o.optString("id").equals(dia.optString("id")) && o.optLong("recuLe") == dia.optLong("recuLe")) {
                    dia = o; recharger();                     // mêmes images, réglages changés
                } else charger(o);
                break;
            case "orientation":
                vue.orientation = Stock.orientation(this); vue.invalidate(); cadrerVideo();
                break;
            case "test": {
                vue.test = Stock.propreOrientation(o.optString("orientation"));
                vue.invalidate();
                h.removeCallbacks(finTest);
                h.postDelayed(finTest, Math.max(3, Math.min(120, o.optInt("secondes", 20))) * 1000L);
                break;
            }
            case "info":
                majAttente();
                if (vue.info != null) montrerInfo();
                break;
            case "cmd": {
                String a = o.optString("action");
                if ("suivante".equals(a)) aller(index + 1, true);
                else if ("precedente".equals(a)) aller(index - 1, true);
                else if ("pause".equals(a)) basculerPause(true);
                else if ("lecture".equals(a)) basculerPause(false);
                else if ("noir".equals(a)) {
                    // écran noir sans éteindre la télé (1.1) : le diaporama continue derrière, retour à l'image où il en est
                    vue.noir = o.optBoolean("on", !vue.noir); Etat.noir = vue.noir;
                    Stock.setNoir(this, vue.noir);
                    vue.invalidate();
                    volume();
                }
                else if ("info".equals(a)) montrerInfo();
                else if ("aller".equals(a)) aller(o.optInt("index", 0), true);
                break;
            }
        }
    }

    /* ---------------------------------------------------------------- télécommande */
    @Override
    public boolean onKeyDown(int k, KeyEvent e) {
        switch (k) {
            case KeyEvent.KEYCODE_DPAD_CENTER: case KeyEvent.KEYCODE_ENTER: case KeyEvent.KEYCODE_MENU: case KeyEvent.KEYCODE_INFO:
                if (vue.info != null) cacherInfo.run(); else montrerInfo();
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT: case KeyEvent.KEYCODE_MEDIA_NEXT: case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                if (dia != null) aller(index + 1, false);
                return true;
            case KeyEvent.KEYCODE_DPAD_LEFT: case KeyEvent.KEYCODE_MEDIA_PREVIOUS: case KeyEvent.KEYCODE_MEDIA_REWIND:
                if (dia != null) aller(index - 1, false);
                return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: case KeyEvent.KEYCODE_SPACE:
                basculerPause(null); return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY: basculerPause(false); return true;
            case KeyEvent.KEYCODE_MEDIA_PAUSE: basculerPause(true); return true;
            case KeyEvent.KEYCODE_BACK:
                if (vue.info != null || vue.test != null) { cacherInfo.run(); finTest.run(); return true; }
                break;
        }
        return super.onKeyDown(k, e);
    }
}
