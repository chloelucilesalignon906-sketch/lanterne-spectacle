package fr.lanterne.ecranhall;

import android.content.Context;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Réseau du boîtier, port 7609 (prochain port libre de la suite Lanterne au 17/11/2026) :
 *  - UDP 7609 : annonce toutes les 2 s (diffusion) {"type":"ecranhall", id, nom, version, port, n, titre, index, ip} ;
 *    répond aussi tout de suite à {"type":"ecranhall_cherche"}.
 *  - TCP 7609 : une ligne JSON par message (comme la suite) ; après {"type":"fichier", nom, taille} viennent les octets.
 *    Premier message {"type":"bonjour", code} : le code à 4 chiffres montré par l'écran (5 faux = bloqué 1 min).
 *    debut / fichier… / fin : nouveau diaporama (remplace l'ancien seulement quand tout est arrivé) ;
 *    reglages, test, cmd, nom, etat, ping.
 */
final class Serveur {
    static final int PORT = 7609;
    private static final int MAX_LIGNE = 2 * 1024 * 1024;
    private static final long MAX_FICHIER = 2100L * 1024 * 1024;   // 1.2 : vidéos jusqu'à 2 Go

    private final Context ctx;
    private volatile boolean actif = false;
    private ServerSocket ss;
    private DatagramSocket ds;
    private final Map<String, int[]> essais = new HashMap<>();      // adresse -> {nombre de codes faux}
    private final Map<String, Long> bloque = new HashMap<>();       // adresse -> bloquée jusqu'à
    private final Object reception = new Object();                  // un seul diaporama reçu à la fois

    Serveur(Context c) { ctx = c.getApplicationContext(); }

    void demarrer() {
        if (actif) return;
        actif = true;
        Thread t = new Thread(new Runnable() { public void run() { boucleTcp(); } }, "ecranhall-tcp");
        t.setDaemon(true); t.start();
        Thread u = new Thread(new Runnable() { public void run() { boucleUdp(); } }, "ecranhall-udp");
        u.setDaemon(true); u.start();
    }

    void arreter() {
        actif = false;
        try { if (ss != null) ss.close(); } catch (Exception ignored) {}
        try { if (ds != null) ds.close(); } catch (Exception ignored) {}
    }

    /* ---------------------------------------------------------------- UDP : annonce */
    private void boucleUdp() {
        while (actif) {
            try {
                ds = new DatagramSocket(null);
                ds.setReuseAddress(true);
                ds.setBroadcast(true);
                ds.bind(new java.net.InetSocketAddress(PORT));
                ds.setSoTimeout(2000);
                long prochaine = 0;
                byte[] buf = new byte[2048];
                while (actif) {
                    long now = System.currentTimeMillis();
                    if (now >= prochaine) { annoncer(null); prochaine = now + 2000; }
                    try {
                        DatagramPacket p = new DatagramPacket(buf, buf.length);
                        ds.receive(p);
                        String s = new String(p.getData(), 0, p.getLength(), "UTF-8");
                        if (s.contains("\"ecranhall_cherche\"")) annoncer(p.getAddress());
                    } catch (SocketTimeoutException ignored) {}
                }
            } catch (Exception e) {
                try { if (ds != null) ds.close(); } catch (Exception ignored) {}
                dormir(3000);
            }
        }
    }

    private void annoncer(InetAddress vers) {
        try {
            JSONObject o = new JSONObject();
            o.put("type", "ecranhall");
            o.put("id", Stock.id(ctx));
            o.put("nom", Stock.nom(ctx));
            o.put("version", Stock.VERSION);
            o.put("port", PORT);
            o.put("n", Etat.nombre);
            o.put("index", Etat.index);
            o.put("titre", Etat.titre);
            o.put("noir", Etat.noir);
            o.put("ip", ip());
            byte[] d = o.toString().getBytes("UTF-8");
            Set<InetAddress> cibles = new HashSet<>();
            if (vers != null) cibles.add(vers);
            else {
                cibles.add(InetAddress.getByName("255.255.255.255"));
                for (InetAddress b : diffusions()) cibles.add(b);
            }
            for (InetAddress a : cibles) {
                try { ds.send(new DatagramPacket(d, d.length, a, PORT)); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
    }

    private static List<InetAddress> diffusions() {
        List<InetAddress> l = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) if (ia.getBroadcast() != null) l.add(ia.getBroadcast());
            }
        } catch (Exception ignored) {}
        return l;
    }

    /** Adresse IPv4 du boîtier sur le réseau local (Ethernet ou Wi-Fi). */
    static String ip() {
        String best = "";
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!(a instanceof Inet4Address) || a.isLoopbackAddress()) continue;
                    String s = a.getHostAddress();
                    if (ni.getName().startsWith("eth")) return s;     // câble réseau en priorité
                    if (best.isEmpty() || ni.getName().startsWith("wlan")) best = s;
                }
            }
        } catch (Exception ignored) {}
        return best;
    }

    /* ---------------------------------------------------------------- TCP */
    private void boucleTcp() {
        while (actif) {
            try {
                ss = new ServerSocket();
                ss.setReuseAddress(true);
                ss.bind(new java.net.InetSocketAddress(PORT));
                while (actif) {
                    final Socket s = ss.accept();
                    Thread t = new Thread(new Runnable() { public void run() { client(s); } }, "ecranhall-client");
                    t.setDaemon(true); t.start();
                }
            } catch (Exception e) {
                try { if (ss != null) ss.close(); } catch (Exception ignored) {}
                dormir(3000);
            }
        }
    }

    private void client(Socket s) {
        String adr = s.getInetAddress().getHostAddress();
        File dossier = null;
        try {
            s.setSoTimeout(30000);           // rien reçu depuis 30 s (l'ordinateur envoie ping toutes les 5 s) : fermée
            s.setTcpNoDelay(true);
            InputStream in = new BufferedInputStream(s.getInputStream(), 65536);
            OutputStream out = s.getOutputStream();
            boolean ok = s.getInetAddress().isLoopbackAddress();
            JSONObject debut = null;
            Set<String> recus = new HashSet<>();
            while (actif) {
                String l = ligne(in);
                if (l == null) break;
                if (l.isEmpty()) continue;
                JSONObject m;
                try { m = new JSONObject(l); } catch (Exception e) { envoyer(out, err("message illisible")); continue; }
                String type = m.optString("type");
                if ("ping".equals(type)) { envoyer(out, new JSONObject().put("type", "pong")); continue; }
                if (!ok) {
                    if (!"bonjour".equals(type)) { envoyer(out, new JSONObject().put("type", "code_requis")); continue; }
                    Long b; synchronized (essais) { b = bloque.get(adr); }
                    if (b != null && b > System.currentTimeMillis()) {
                        envoyer(out, new JSONObject().put("type", "bloque").put("secondes", (b - System.currentTimeMillis()) / 1000 + 1));
                        continue;
                    }
                    if (!Stock.code(ctx).equals(m.optString("code"))) {
                        synchronized (essais) {
                            int[] n = essais.get(adr); if (n == null) { n = new int[1]; essais.put(adr, n); }
                            if (++n[0] >= 5) { n[0] = 0; bloque.put(adr, System.currentTimeMillis() + 60000); }
                        }
                        envoyer(out, new JSONObject().put("type", m.has("code") && !m.optString("code").isEmpty() ? "code_faux" : "code_requis"));
                        continue;
                    }
                    synchronized (essais) { essais.remove(adr); }
                    ok = true;
                    envoyer(out, etat().put("type", "bienvenue"));
                    continue;
                }
                switch (type) {
                    case "bonjour":
                    case "etat":
                        envoyer(out, etat());
                        break;
                    case "debut": {
                        JSONArray d = m.optJSONArray("diapos");
                        if (d == null || d.length() == 0 || d.length() > 2000) { envoyer(out, err("liste des diapos vide")); break; }
                        long total = m.optLong("taille", 0);
                        File racine = Stock.racine(ctx);
                        if (racine.getUsableSpace() < total + 50L * 1024 * 1024) { envoyer(out, err("plus assez de place sur le boîtier")); break; }
                        for (int i = 0; i < d.length(); i++) {
                            if (!nomOk(d.getJSONObject(i).optString("f"))) { envoyer(out, err("nom de fichier refusé")); d = null; break; }
                        }
                        if (d == null) break;
                        synchronized (reception) {
                            dossier = Stock.recu(ctx);
                            Stock.supprimer(dossier);
                            if (!dossier.mkdirs()) { envoyer(out, err("dossier de réception impossible")); dossier = null; break; }
                        }
                        debut = m; recus.clear();
                        envoyer(out, new JSONObject().put("type", "pret"));
                        break;
                    }
                    case "fichier": {
                        String nom = m.optString("nom");
                        long taille = m.optLong("taille", -1);
                        if (taille < 0 || taille > MAX_FICHIER) { envoyer(out, err("taille refusée")); s.close(); return; }
                        // les octets arrivent quoi qu'il en soit : on les lit (et on les jette si le fichier est refusé)
                        boolean garder = dossier != null && nomOk(nom);
                        File f = garder ? new File(dossier, nom) : null;
                        OutputStream fo = garder ? new FileOutputStream(new File(dossier, nom + ".tmp")) : null;
                        try {
                            byte[] buf = new byte[65536];
                            long reste = taille;
                            while (reste > 0) {
                                int n = in.read(buf, 0, (int) Math.min(buf.length, reste));
                                if (n < 0) throw new IOException("liaison coupée pendant l'envoi");
                                if (fo != null) fo.write(buf, 0, n);
                                reste -= n;
                            }
                        } finally { if (fo != null) { try { ((FileOutputStream) fo).getFD().sync(); } catch (Exception ignored) {} fo.close(); } }
                        if (!garder) { envoyer(out, err("fichier reçu sans « debut » ou nom refusé")); break; }
                        if (!new File(dossier, nom + ".tmp").renameTo(f)) { envoyer(out, err("écriture impossible")); break; }
                        recus.add(nom);
                        envoyer(out, new JSONObject().put("type", "recu").put("nom", nom));
                        break;
                    }
                    case "fin": {
                        if (dossier == null || debut == null) { envoyer(out, err("aucun diaporama en cours")); break; }
                        JSONArray d = debut.getJSONArray("diapos");
                        String manque = null;
                        for (int i = 0; i < d.length(); i++) { String n = d.getJSONObject(i).optString("f"); if (!recus.contains(n)) { manque = n; break; } }
                        if (manque != null) { envoyer(out, err("image manquante : " + manque)); break; }
                        JSONObject dia = new JSONObject();
                        for (String k : new String[] { "id", "titre", "orientation", "ajuste", "fond", "transition", "diapos", "source", "son" })
                            if (debut.has(k)) dia.put(k, debut.get(k));
                        dia.put("orientation", Stock.propreOrientation(dia.optString("orientation")));
                        dia.put("recuLe", System.currentTimeMillis());
                        dia.put("depuis", m.optString("ordinateur", adr));
                        synchronized (reception) {
                            Stock.ecrire(new File(dossier, "diaporama.json"), dia.toString(1).getBytes("UTF-8"));
                            Stock.installer(ctx, dossier);
                        }
                        Stock.setOrientation(ctx, dia.optString("orientation"));
                        dossier = null; debut = null;
                        if (!Etat.signaler("diaporama", dia)) EcranService.devant(ctx);
                        envoyer(out, new JSONObject().put("type", "installe").put("n", d.length()));
                        break;
                    }
                    case "reglages": {
                        JSONObject dia = Stock.lireDiaporama(ctx);
                        String o = m.has("orientation") ? Stock.propreOrientation(m.optString("orientation")) : null;
                        if (o != null) Stock.setOrientation(ctx, o);
                        if (dia != null) {
                            for (String k : new String[] { "orientation", "ajuste", "fond", "transition", "son" }) if (m.has(k)) dia.put(k, m.get(k));
                            if (o != null) dia.put("orientation", o);
                            JSONArray durees = m.optJSONArray("durees");
                            JSONArray ld = dia.getJSONArray("diapos");
                            if (durees != null && durees.length() == ld.length())
                                for (int i = 0; i < ld.length(); i++) ld.getJSONObject(i).put("d", durees.optDouble(i, 8));
                            // 1.2 : rotation de chaque vidéo (0, 90, 180, 270)
                            JSONArray rots = m.optJSONArray("rotations");
                            if (rots != null && rots.length() == ld.length())
                                for (int i = 0; i < ld.length(); i++) if (ld.getJSONObject(i).has("v")) ld.getJSONObject(i).put("r", rots.optInt(i, 0));
                            Stock.ecrireDiaporama(ctx, dia);
                            Etat.signaler("diaporama", dia);
                        } else Etat.signaler("orientation", m);
                        envoyer(out, etat());
                        break;
                    }
                    case "test":
                        if (!Etat.signaler("test", m)) { EcranService.devant(ctx); dormir(1500); Etat.signaler("test", m); }
                        envoyer(out, new JSONObject().put("type", "ok"));
                        break;
                    case "cmd":
                        if ("devant".equals(m.optString("action"))) EcranService.devant(ctx);
                        else if ("noir".equals(m.optString("action"))) {
                            // noir gardé ici aussi : vaut même si l'écran n'est pas devant (il le lira en s'ouvrant)
                            boolean on = m.has("on") ? m.optBoolean("on") : !Etat.noir;
                            Stock.setNoir(ctx, on); Etat.noir = on; m.put("on", on);
                            if (!Etat.signaler("cmd", m)) EcranService.devant(ctx);
                        }
                        else Etat.signaler("cmd", m);
                        envoyer(out, new JSONObject().put("type", "ok").put("noir", Etat.noir));
                        break;
                    case "nom": {
                        String n = m.optString("nom").trim();
                        if (n.length() > 40) n = n.substring(0, 40);
                        if (!n.isEmpty()) Stock.setNom(ctx, n);
                        Etat.signaler("info", m);
                        envoyer(out, etat());
                        break;
                    }
                    default:
                        envoyer(out, err("commande inconnue : " + type));
                }
            }
        } catch (Exception ignored) {
        } finally {
            try { s.close(); } catch (Exception ignored) {}
        }
    }

    private JSONObject etat() throws Exception {
        JSONObject o = new JSONObject();
        o.put("type", "etat");
        o.put("id", Stock.id(ctx));
        o.put("nom", Stock.nom(ctx));
        o.put("version", Stock.VERSION);
        o.put("ip", ip());
        o.put("n", Etat.nombre);
        o.put("index", Etat.index);
        o.put("titre", Etat.titre);
        o.put("pause", Etat.pause);
        o.put("noir", Etat.noir);
        o.put("devant", Etat.devant);
        o.put("orientation", Stock.orientation(ctx));
        o.put("ecran", new JSONObject().put("w", Etat.largeur).put("h", Etat.hauteur));
        o.put("libre", Stock.racine(ctx).getUsableSpace() / (1024 * 1024));
        o.put("recuLe", Etat.recuLe);
        o.put("appareil", (Build.MANUFACTURER + " " + Build.MODEL).trim());
        o.put("android", Build.VERSION.RELEASE);
        return o;
    }

    private static JSONObject err(String t) throws Exception { return new JSONObject().put("type", "erreur").put("texte", t); }

    private static boolean nomOk(String n) { return n != null && n.matches("[A-Za-z0-9_-]{1,40}\\.(jpg|jpeg|png|mp4|m4v|mov|webm)"); }

    private static void envoyer(OutputStream out, JSONObject o) throws IOException {
        byte[] d = (o.toString() + "\n").getBytes("UTF-8");
        synchronized (out) { out.write(d); out.flush(); }
    }

    /** Une ligne (UTF-8) jusqu'à \n ; null si la liaison est fermée. */
    private static String ligne(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream(256);
        while (true) {
            int c = in.read();
            if (c < 0) return b.size() > 0 ? b.toString("UTF-8") : null;
            if (c == '\n') return b.toString("UTF-8").trim();
            b.write(c);
            if (b.size() > MAX_LIGNE) throw new IOException("ligne trop longue");
        }
    }

    private static void dormir(long ms) { try { Thread.sleep(ms); } catch (InterruptedException ignored) {} }
}
