package fr.lanterne.ecranhall;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

/**
 * Service toujours actif (premier plan) : garde le port 7609 ouvert même quand l'écran n'est pas devant,
 * garde le Wi-Fi éveillé, et remet le diaporama devant quand le boîtier se réveille (télé rallumée par HDMI-CEC).
 */
public class EcranService extends Service {
    private static final String CANAL = "ecranhall";
    private Serveur serveur;
    private WifiManager.WifiLock wifi;
    private final Handler h = new Handler(Looper.getMainLooper());

    static void demarrer(Context c) {
        Intent i = new Intent(c, EcranService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
        } catch (Exception ignored) {}
    }

    /** Met l'écran du diaporama devant (droit « afficher par-dessus les autres applis » donné à l'installation). */
    static void devant(Context c) {
        Intent ouvrir = new Intent(c, MainActivity.class);
        ouvrir.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try { c.startActivity(ouvrir); } catch (Exception ignored) {}
    }

    private final BroadcastReceiver reveil = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            // l'accueil du boîtier s'affiche au réveil : on repasse devant, deux fois (après lui)
            h.removeCallbacksAndMessages(null);
            h.postDelayed(new Runnable() { public void run() { devant(EcranService.this); } }, 1500);
            h.postDelayed(new Runnable() { public void run() { if (!Etat.devant) devant(EcranService.this); } }, 6000);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(CANAL, "Écran Hall", NotificationManager.IMPORTANCE_MIN));
            b = new Notification.Builder(this, CANAL);
        } else b = new Notification.Builder(this);
        Notification n = b.setContentTitle("Écran Hall").setContentText("Prêt à recevoir un diaporama (port " + Serveur.PORT + ")")
                .setSmallIcon(android.R.drawable.ic_menu_slideshow).setOngoing(true).build();
        startForeground(7609, n);
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                wifi = wm.createWifiLock(Build.VERSION.SDK_INT >= 29 ? 4 /* WIFI_MODE_FULL_LOW_LATENCY */ : WifiManager.WIFI_MODE_FULL_HIGH_PERF, "ecranhall");
                wifi.acquire();
            }
        } catch (Exception ignored) {}
        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_USER_PRESENT);
        f.addAction("android.intent.action.DREAMING_STOPPED");
        registerReceiver(reveil, f);
        serveur = new Serveur(this);
        serveur.demarrer();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }

    @Override
    public void onDestroy() {
        try { unregisterReceiver(reveil); } catch (Exception ignored) {}
        if (serveur != null) serveur.arreter();
        try { if (wifi != null && wifi.isHeld()) wifi.release(); } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
