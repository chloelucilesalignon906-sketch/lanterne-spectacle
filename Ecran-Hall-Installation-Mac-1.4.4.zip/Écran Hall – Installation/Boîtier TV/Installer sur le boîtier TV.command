#!/bin/bash
# =============================================================
#  Écran Hall — installe l'appli « Écran Hall » sur le boîtier TV du hall
#  (Google TV / Android TV / Fire TV branché en HDMI sur la télé), depuis ce Mac, par le réseau (Wi-Fi ou câble).
#  1. outils de compilation (Java 17 + outils Android de Google) : ceux du dossier « thomson » s'ils sont là,
#     sinon téléchargés une seule fois dans ~/Library/Application Support/Écran Hall/outils-android
#  2. compile l'appli (dossier boitier-src) et la signe (même clé à chaque fois : les mises à jour s'installent par-dessus)
#  3. se relie au boîtier (débogage réseau), installe l'appli, lui permet de revenir devant toute seule
#     (démarrage du boîtier, télé rallumée), et l'ouvre.
#  Sur le boîtier, avant : activer les options pour les développeurs et le débogage (voir LISEZMOI).
#  « Desinstaller du boîtier TV.command » retire l'appli.
# =============================================================
cd "$(dirname "$0")" || exit 1
DOSSIER="$(pwd)"
SRC="$DOSSIER/boitier-src"
PKG="fr.lanterne.ecranhall"
OUTILS="$HOME/Library/Application Support/Écran Hall/outils-android"
LOG="$OUTILS/journal.txt"
mkdir -p "$OUTILS"
exec > >(tee -a "$LOG") 2>&1
BT_VER="34.0.0"; PF="android-34"
APK="$OUTILS/Ecran-Hall.apk"

echec() { echo ""; echo "❌ $1"; echo ""; echo "Journal : $LOG"; read -r -p "Appuie sur Entrée pour fermer." _; exit 1; }
etape() { echo ""; echo "→ $1"; }

echo ""
echo "=== Écran Hall — installation sur le boîtier TV ($(date '+%d/%m/%Y %H:%M')) ==="
[ -f "$SRC/AndroidManifest.xml" ] || echec "Le dossier « boitier-src » doit être à côté de ce script."

# ---------------------------------------------------------------- 1. outils
# déjà installés pour la Télécommande FDR (dossier thomson) ? on s'en sert
THOMSON="$HOME/Desktop/donnée/thomson"
[ -d "$THOMSON" ] || THOMSON="$(ls -d "$HOME"/Desktop/donn*e/thomson 2>/dev/null | head -1)"
JDK=""; SDK=""; ADB=""
if [ -n "$THOMSON" ] && [ -x "$THOMSON/outils/jdk/Contents/Home/bin/javac" ]; then JDK="$THOMSON/outils/jdk"; fi
if [ -n "$THOMSON" ] && [ -f "$THOMSON/outils/android-sdk/platforms/$PF/android.jar" ] && [ -x "$THOMSON/outils/android-sdk/build-tools/$BT_VER/aapt2" ]; then SDK="$THOMSON/outils/android-sdk"; fi
if [ -n "$THOMSON" ] && [ -x "$THOMSON/platform-tools/adb" ]; then ADB="$THOMSON/platform-tools/adb"; fi
[ -n "$JDK" ] || JDK="$OUTILS/jdk"
[ -n "$SDK" ] || SDK="$OUTILS/android-sdk"
[ -n "$ADB" ] || ADB="$OUTILS/platform-tools/adb"

if [ ! -x "$JDK/Contents/Home/bin/javac" ]; then
  etape "Téléchargement de Java (une seule fois, ~190 Mo)…"
  JARCH=aarch64; [ "$(uname -m)" = "x86_64" ] && JARCH=x64
  curl -fL --progress-bar -o "$OUTILS/jdk.tar.gz" \
    "https://api.adoptium.net/v3/binary/latest/17/ga/mac/$JARCH/jdk/hotspot/normal/eclipse" || echec "téléchargement de Java impossible (connexion Internet ?)"
  rm -rf "$OUTILS/jdk-tmp"; mkdir -p "$OUTILS/jdk-tmp"
  tar xzf "$OUTILS/jdk.tar.gz" -C "$OUTILS/jdk-tmp" || echec "archive Java abîmée"
  rm -rf "$OUTILS/jdk"; mv "$OUTILS"/jdk-tmp/*/ "$OUTILS/jdk" && rm -rf "$OUTILS/jdk-tmp" "$OUTILS/jdk.tar.gz"
  xattr -dr com.apple.quarantine "$OUTILS/jdk" 2>/dev/null
  JDK="$OUTILS/jdk"
fi
export JAVA_HOME="$JDK/Contents/Home"
export PATH="$JAVA_HOME/bin:$PATH"
"$JAVA_HOME/bin/java" -version 2>&1 | head -1 | sed 's/^/   /'

BT="$SDK/build-tools/$BT_VER"; AJAR="$SDK/platforms/$PF/android.jar"
if [ ! -x "$BT/aapt2" ] || [ ! -f "$AJAR" ]; then
  SDKM="$SDK/cmdline-tools/latest/bin/sdkmanager"
  if [ ! -x "$SDKM" ]; then
    etape "Téléchargement des outils Android de Google (une seule fois)…"
    OK=0
    for V in 13114758 11076708 10406996; do
      if curl -fL --progress-bar -o "$OUTILS/cmdline.zip" "https://dl.google.com/android/repository/commandlinetools-mac-${V}_latest.zip"; then OK=1; break; fi
    done
    [ "$OK" = 1 ] || echec "téléchargement des outils Android impossible"
    rm -rf "$OUTILS/cmdline-tmp"; mkdir -p "$OUTILS/cmdline-tmp" "$SDK/cmdline-tools"
    unzip -q -o "$OUTILS/cmdline.zip" -d "$OUTILS/cmdline-tmp" || echec "archive des outils Android abîmée"
    rm -rf "$SDK/cmdline-tools/latest"; mv "$OUTILS/cmdline-tmp/cmdline-tools" "$SDK/cmdline-tools/latest"
    rm -rf "$OUTILS/cmdline-tmp" "$OUTILS/cmdline.zip"
    xattr -dr com.apple.quarantine "$SDK" 2>/dev/null
  fi
  if [ ! -f "$SDK/licenses/android-sdk-license" ]; then
    echo ""
    echo "──────────────────────────────────────────────────────────────"
    echo " Google demande d'accepter la licence du kit de développement"
    echo " Android (SDK) pour pouvoir télécharger ses outils."
    echo " Texte complet : https://developer.android.com/studio/terms"
    echo "──────────────────────────────────────────────────────────────"
    read -r -p " Tape  o  puis Entrée pour accepter (autre touche = annuler) : " REP
    case "$REP" in o|O|oui|OUI|y|Y) ;; *) echec "licence Android non acceptée : rien n'a été installé" ;; esac
    yes | "$SDKM" --sdk_root="$SDK" --licenses >/dev/null 2>&1
  fi
  etape "Téléchargement des outils de compilation Android (une seule fois)…"
  "$SDKM" --sdk_root="$SDK" "build-tools;$BT_VER" "platforms;$PF" 2>&1 | grep -vE "^\[|^$" | tail -5
  [ -x "$BT/aapt2" ] && [ -f "$AJAR" ] || echec "installation des outils de compilation incomplète"
  xattr -dr com.apple.quarantine "$SDK" 2>/dev/null
fi

if [ ! -x "$ADB" ]; then
  etape "Téléchargement d'adb (liaison avec le boîtier, une seule fois)…"
  curl -fL --progress-bar -o "$OUTILS/pt.zip" "https://dl.google.com/android/repository/platform-tools-latest-darwin.zip" || echec "téléchargement d'adb impossible"
  rm -rf "$OUTILS/platform-tools"; unzip -q -o "$OUTILS/pt.zip" -d "$OUTILS" || echec "archive adb abîmée"
  rm -f "$OUTILS/pt.zip"; xattr -dr com.apple.quarantine "$OUTILS/platform-tools" 2>/dev/null
  ADB="$OUTILS/platform-tools/adb"
fi

# ---------------------------------------------------------------- 2. compilation
etape "Compilation de l'appli Écran Hall…"
# compilation dans un dossier temporaire sans espace ni accent (le dossier d'installation peut s'appeler
# « ecran hall/Écran Hall – Installation/Boîtier TV » : les listes de fichiers passées à javac et d8 doivent rester entières)
BUILD="$(mktemp -d /tmp/ecranhall-build.XXXXXX)" || echec "dossier temporaire impossible"
trap 'rm -rf "$BUILD"' EXIT
mkdir -p "$BUILD/gen" "$BUILD/classes" "$BUILD/dex"
cp -R "$SRC" "$BUILD/src" || echec "copie des sources"
"$BT/aapt2" compile --dir "$BUILD/src/res" -o "$BUILD/res.zip" || echec "ressources (aapt2 compile)"
"$BT/aapt2" link -o "$BUILD/base.apk" -I "$AJAR" --manifest "$BUILD/src/AndroidManifest.xml" \
  --java "$BUILD/gen" --min-sdk-version 22 --target-sdk-version 28 "$BUILD/res.zip" || echec "manifeste (aapt2 link)"
find "$BUILD/src/src" "$BUILD/gen" -name '*.java' > "$BUILD/sources.txt"
"$JAVA_HOME/bin/javac" -encoding UTF-8 --release 8 -Xlint:-options -nowarn \
  -classpath "$AJAR" -d "$BUILD/classes" @"$BUILD/sources.txt" || echec "code Java (javac)"
CLASSES=(); while IFS= read -r f; do CLASSES+=("$f"); done < <(find "$BUILD/classes" -name '*.class')
"$BT/d8" --release --min-api 22 --lib "$AJAR" --output "$BUILD/dex" "${CLASSES[@]}" || echec "conversion Android (d8)"
cp "$BUILD/base.apk" "$BUILD/non-signe.apk"
( cd "$BUILD/dex" && zip -q -j "$BUILD/non-signe.apk" classes.dex ) || echec "assemblage"
"$BT/zipalign" -f -p 4 "$BUILD/non-signe.apk" "$BUILD/aligne.apk" || echec "zipalign"
# clé de signature gardée ici : la même pour toutes les mises à jour (sinon le boîtier refuse de remplacer l'appli)
if [ ! -f "$OUTILS/ecranhall.jks" ]; then
  "$JAVA_HOME/bin/keytool" -genkeypair -keystore "$OUTILS/ecranhall.jks" -storepass lanterne -keypass lanterne \
    -alias lanterne -keyalg RSA -keysize 2048 -validity 20000 -dname "CN=Lanterne Ecran Hall" >/dev/null 2>&1 || echec "clé de signature"
fi
"$BT/apksigner" sign --ks "$OUTILS/ecranhall.jks" --ks-pass pass:lanterne --key-pass pass:lanterne \
  --out "$APK" "$BUILD/aligne.apk" || echec "signature"
cp "$APK" "$DOSSIER/Ecran-Hall.apk" 2>/dev/null
echo "   ✓ Ecran-Hall.apk ($(du -h "$APK" | cut -f1 | tr -d ' '))"

# ---------------------------------------------------------------- 3. liaison avec le boîtier
DERN="$OUTILS/derniere-adresse.txt"
ANCIENNE="$(cat "$DERN" 2>/dev/null)"
echo ""
echo "──────────────────────────────────────────────────────────────"
echo " Adresse IP du boîtier : sur le boîtier, Paramètres › Réseau et"
echo " Internet › (ton réseau) — ou, si Écran Hall y est déjà, touche"
echo " OK de la télécommande."
echo "──────────────────────────────────────────────────────────────"
read -r -p " Adresse IP du boîtier${ANCIENNE:+ [Entrée = $ANCIENNE]} : " IP
IP="${IP:-$ANCIENNE}"
IP="$(echo "$IP" | tr -d ' ')"
echo "$IP" | grep -Eq '^[0-9]{1,3}(\.[0-9]{1,3}){3}(:[0-9]+)?$' || echec "adresse IP attendue, par exemple 192.168.1.42"
echo "$IP" > "$DERN"
case "$IP" in *:*) CIBLE="$IP" ;; *) CIBLE="$IP:5555" ;; esac

"$ADB" start-server >/dev/null 2>&1
relie() { [ "$("$ADB" -s "$CIBLE" get-state 2>/dev/null)" = "device" ]; }
etape "Liaison avec le boîtier ($CIBLE)…"
"$ADB" connect "$CIBLE" 2>&1 | sed 's/^/   /'
if ! relie; then
  echo ""
  echo "   Sur la télé, une fenêtre « Autoriser le débogage ? » peut s'afficher :"
  echo "   coche « Toujours autoriser depuis cet ordinateur » puis OK (60 s pour le faire)."
  for i in $(seq 1 30); do
    relie && break
    sleep 2
    "$ADB" connect "$CIBLE" >/dev/null 2>&1
  done
fi
if ! relie; then
  # Google TV récent (Android 11 et plus, « Débogage sans fil ») : association avec un code
  echo ""
  echo "   Pas de liaison directe. Si ton boîtier a « Débogage sans fil » (Google TV récent) :"
  echo "   Options pour les développeurs › Débogage sans fil › Associer l'appareil avec un code."
  read -r -p "   Adresse et port affichés pour l'association (ex. 192.168.1.42:37123), ou Entrée pour abandonner : " PAIR
  [ -n "$PAIR" ] || echec "boîtier injoignable. Vérifie : même réseau que ce Mac, débogage activé sur le boîtier, adresse IP."
  read -r -p "   Code d'association à 6 chiffres : " CODE
  "$ADB" pair "$PAIR" "$CODE" 2>&1 | sed 's/^/   /'
  read -r -p "   Adresse et port du « Débogage sans fil » (écran précédent, ex. 192.168.1.42:41567) : " CIBLE
  echo "$CIBLE" > "$DERN"
  "$ADB" connect "$CIBLE" 2>&1 | sed 's/^/   /'
  for i in $(seq 1 10); do relie && break; sleep 2; done
  relie || echec "boîtier injoignable après l'association."
fi
SH() { "$ADB" -s "$CIBLE" shell "$@" 2>&1 | tr -d '\r'; }
echo "   ✓ relié : $(SH getprop ro.product.manufacturer) $(SH getprop ro.product.model), Android $(SH getprop ro.build.version.release)"

# ---------------------------------------------------------------- 4. installation
etape "Installation de l'appli sur le boîtier…"
R="$("$ADB" -s "$CIBLE" install -r "$APK" 2>&1 | tr -d '\r' | tail -2)"
echo "   $R"
if echo "$R" | grep -q "INSTALL_FAILED_UPDATE_INCOMPATIBLE"; then
  echo "   Une ancienne Écran Hall signée autrement est sur le boîtier : on la retire puis on réinstalle."
  "$ADB" -s "$CIBLE" uninstall "$PKG" >/dev/null 2>&1
  R="$("$ADB" -s "$CIBLE" install -r "$APK" 2>&1 | tr -d '\r' | tail -2)"; echo "   $R"
fi
echo "$R" | grep -q "Success" || echec "installation refusée par le boîtier (une fenêtre est peut-être ouverte sur la télé)"

# revenir devant tout seul au démarrage du boîtier et quand la télé se rallume : droit « afficher par-dessus les autres applis »
SH appops set $PKG SYSTEM_ALERT_WINDOW allow >/dev/null
echo "   ✓ retour devant automatique autorisé ($(SH appops get $PKG SYSTEM_ALERT_WINDOW))"
# jamais endormie par l'économie d'énergie (le port 7609 reste ouvert pour recevoir un nouveau diaporama)
SH dumpsys deviceidle whitelist +$PKG >/dev/null
SH cmd appops set $PKG RUN_IN_BACKGROUND allow >/dev/null 2>&1
echo "   ✓ jamais mise en veille par Android"

etape "Ouverture d'Écran Hall sur la télé…"
SH am start -n $PKG/.MainActivity >/dev/null
sleep 2
echo ""
echo "✅ Terminé. La télé montre « En attente d'un diaporama », avec l'adresse et le code du boîtier."
echo "   Ouvre l'appli « Écran Hall » sur ce Mac (ou un PC) : le boîtier y apparaît tout seul."
echo "   Le code à 4 chiffres est demandé une seule fois."
echo ""
read -r -p "Appuie sur Entrée pour fermer." _
