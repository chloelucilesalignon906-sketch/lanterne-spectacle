#!/bin/bash
# Installer Banque.app : une question, l'installation (fenêtre « en cours »), puis le résultat.
# Tout se fait dans des fenêtres macOS ; le détail va dans ~/Library/Logs/Banque-installation.log.
if [ "$(/usr/sbin/sysctl -n sysctl.proc_translated 2>/dev/null)" = "1" ] && [ -z "${LS_NATIVE:-}" ] && /usr/bin/arch -arm64 /bin/bash -c true 2>/dev/null; then
  export LS_NATIVE=1
  exec /usr/bin/arch -arm64 /bin/bash "$0" "$@"
fi
RES="$(cd "$(dirname "$0")/../Resources" && pwd)"
CMD="${RES}/Installer Banque.command"
LOG="${HOME}/Library/Logs/Banque-installation.log"
mkdir -p "$(dirname "${LOG}")"
printf 'Installation de Banque · %s · macOS %s · %s\n\n' "$(date)" "$(sw_vers -productVersion 2>/dev/null)" "$(uname -m)" > "${LOG}"
T="Banque"
dlg() { /usr/bin/osascript -e "activate" -e "$1" 2>>"${LOG}"; }
if [ ! -f "${CMD}" ]; then dlg "display dialog \"Les fichiers de l'installateur sont incomplets. Retélécharge le dossier d'installation.\" with title \"${T}\" buttons {\"Fermer\"} default button 1 with icon stop" >/dev/null; exit 1; fi
R="$(dlg "display dialog \"Installer Banque ?

Échange de fichiers entre les ordinateurs du réseau local : une banque principale où chacun prend des fichiers, et l'envoi direct d'un ordinateur à l'autre.

Il s'installe dans Applications. Internet est nécessaire si aucun logiciel Lanterne n'est encore installé ici.\" with title \"${T}\" buttons {\"Annuler\", \"Installer\"} default button 2 with icon note
return button returned of result")"
[ "${R}" = "Installer" ] || exit 0
# fenêtre « en cours » pendant l'installation
F="$(mktemp "${TMPDIR:-/tmp}/lanterne.XXXXXX")"
printf '%s\n' "activate" "display dialog \"Installation de Banque en cours (1 à 2 minutes)…\" with title \"${T}\" buttons {\"Masquer\"} default button 1 giving up after 900 with icon note" > "${F}"
( /usr/bin/osascript "${F}" >/dev/null 2>&1; rm -f "${F}" ) &
WAIT=$!
DESTF="$(mktemp "${TMPDIR:-/tmp}/lanterne-dest.XXXXXX")"
LS_DEST_FILE="${DESTF}" NO_OPEN=1 /bin/bash "${CMD}" >> "${LOG}" 2>&1
RC=$?
pkill -P "${WAIT}" >/dev/null 2>&1; kill "${WAIT}" >/dev/null 2>&1
DEST="$(cat "${DESTF}" 2>/dev/null)"; rm -f "${DESTF}"
if [ ${RC} -eq 0 ]; then
  R="$(dlg "display dialog \"Banque est installé dans ${DEST:-Applications}, avec un raccourci sur le Bureau.

Au premier lancement, macOS demande l'accès au réseau local : réponds Autoriser.\" with title \"${T}\" buttons {\"Fermer\", \"Ouvrir\"} default button 2 with icon note
return button returned of result")"
  [ "${R}" = "Ouvrir" ] && open "${DEST:-/Applications}/Banque.app"
  exit 0
fi
TAILTXT="$(grep -v '^\s*$' "${LOG}" | tail -n 3 | sed -e 's/\x1b\[[0-9;]*m//g' -e 's/"/ /g' -e 's/\\/ /g')"
R="$(dlg "display dialog \"L'installation s'est arrêtée.

${TAILTXT}\" with title \"${T}\" buttons {\"Voir le journal\", \"Fermer\"} default button 2 with icon stop
return button returned of result")"
[ "${R}" = "Voir le journal" ] && { open -e "${LOG}" 2>/dev/null || open "${LOG}"; }
exit 1
