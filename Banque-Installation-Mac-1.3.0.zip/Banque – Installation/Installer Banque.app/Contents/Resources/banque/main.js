'use strict';
// Banque — échange de fichiers entre ordinateurs du réseau local (logiciel à part, dans le style de Lanterne Spectacle).
//   Mode 1 « Banque principale » : un ordinateur partage sa banque ; les autres la parcourent et récupèrent des fichiers
//          dans leur propre banque (même rangement de dossiers). Dépôt dans la banque principale si elle l'autorise.
//   Mode 2 « Envoyer » : un fichier ou un dossier envoyé directement à un autre ordinateur qui a Banque ; il accepte ou refuse.
//   Plus tard : banque en ligne (voir SOURCES plus bas : une banque = une source avec liste / arbre / téléchargement / dépôt).
//   1.1.0 : liaison avec Lanterne Spectacle (même ordinateur) — accès local pour Lanterne PPT, Player et Son (local.json + /v1/local/…),
//           écran « Intervenants » (listes de PPT lancés dans Lanterne PPT, retour ici à la fin du diaporama), préparable d'un autre ordinateur ;
//   1.2.0 : plusieurs listes d'intervenants nommées (salles, matin, après-midi…), chacune dans son sous-dossier d'Intervenants.
//   1.3.0 : mises à jour depuis GitHub (bandeau au lancement, installation en un clic, retour à la version d'avant).
// Réseau : annonces UDP 7610 (broadcast de chaque sous-réseau + 127.0.0.1), échanges HTTP sur le port TCP 7611
// (port libre au hasard si 7611 est pris ; le vrai port est dans l'annonce). Tout l'accès au réseau se fait ici,
// dans le processus principal (règle macOS « Réseau local »).
const { app, BrowserWindow, ipcMain, dialog, Menu, shell, protocol, Notification } = require('electron');
const path = require('path');
const fs = require('fs');
const fsp = fs.promises;
const os = require('os');
const http = require('http');
const dgram = require('dgram');
const crypto = require('crypto');
const net = require('net');
const { execFile, spawn } = require('child_process');

app.setName('Banque');
const isMac = process.platform === 'darwin', isWin = process.platform === 'win32';
const APP_ICON = isMac ? undefined : path.join(__dirname, 'icon.png');
if (isWin) app.setAppUserModelId('fr.lanterne.banque');
// essais : plusieurs Banque sur un même ordinateur, chacune avec son profil (BANQUE_PROFIL=dossier)
if (process.env.BANQUE_PROFIL) app.setPath('userData', path.resolve(process.env.BANQUE_PROFIL));
const fiab = require('./fiabilite')({ app, ipcMain, dialog, gpu: false });
if (!process.env.BANQUE_PROFIL && !app.requestSingleInstanceLock()) app.exit(0);
app.on('second-instance', () => montrer());

const UDP_PORT = +process.env.BANQUE_UDP || 7610;
const TCP_PORT = +process.env.BANQUE_PORT || 7611;
const PROTO = 1;            // version du protocole entre deux Banque
const PERDU_MS = 7000;      // plus d'annonce depuis 7 s : ordinateur parti
const PARTIEL = '.banque-partiel';
const IGNORES = new Set(['.DS_Store', 'Thumbs.db', 'desktop.ini', '.localized']);
const RECUS = 'Reçus';
const INTERV_DOSSIER = 'Intervenants';   // PPT de l'écran Intervenants envoyés d'un autre ordinateur

/* ---------- fichiers de la page ---------- */
protocol.registerSchemesAsPrivileged([{ scheme: 'banque', privileges: { standard: true, secure: true, supportFetchAPI: true } }]);
const MIME = { html: 'text/html; charset=utf-8', js: 'text/javascript; charset=utf-8', css: 'text/css; charset=utf-8', png: 'image/png', svg: 'image/svg+xml', json: 'application/json' };
function setupProtocol() {
  protocol.handle('banque', async (req) => {
    const u = new URL(req.url);
    const p = path.normalize(path.join(__dirname, decodeURIComponent(u.pathname)));
    if (u.host !== 'app' || !p.startsWith(__dirname)) return new Response('Interdit', { status: 403 });
    try {
      const data = await fsp.readFile(p);
      return new Response(data, { headers: { 'Content-Type': MIME[path.extname(p).slice(1)] || 'application/octet-stream' } });
    } catch (e) { return new Response('Introuvable', { status: 404 }); }
  });
}

/* ---------- préférences ---------- */
const prefsFile = () => path.join(app.getPath('userData'), 'prefs.json');
const nomParDefaut = () => { let n = os.hostname().replace(/\.(local|lan|home|localdomain)$/i, ''); return (n || 'Ordinateur').slice(0, 40); };
let prefs = {};
function loadPrefs() {
  try { prefs = JSON.parse(fs.readFileSync(prefsFile(), 'utf8')) || {}; } catch (e) { prefs = {}; }
  if (!prefs.id) prefs.id = crypto.randomUUID();
  if (!prefs.nom) prefs.nom = nomParDefaut();
  if (!prefs.dossier) prefs.dossier = process.env.BANQUE_DOSSIER ? path.resolve(process.env.BANQUE_DOSSIER) : path.join(app.getPath('documents'), 'Banque');
  if (typeof prefs.principale !== 'boolean') prefs.principale = false;
  if (typeof prefs.depot !== 'boolean') prefs.depot = false;
  if (!['deux', 'remplacer', 'passer'].includes(prefs.conflit)) prefs.conflit = 'deux';
  if (!Array.isArray(prefs.confiance)) prefs.confiance = [];   // [{id, nom}] : envois acceptés sans question
  if (!Array.isArray(prefs.manuels)) prefs.manuels = [];       // adresses IP ajoutées à la main (réseau qui bloque les annonces)
  if (typeof prefs.visible !== 'boolean') prefs.visible = true;
  savePrefs();
}
function savePrefs() { try { fs.mkdirSync(path.dirname(prefsFile()), { recursive: true }); fiab.ecrire(prefsFile(), JSON.stringify(prefs, null, 2)); } catch (e) { fiab.log('prefs', e && e.message); } }
const racine = () => prefs.dossier;
// liaison avec les logiciels Lanterne du même ordinateur : port et jeton dans <userData>/local.json (lisible par l'utilisateur seul)
const JETON_LOCAL = crypto.randomBytes(18).toString('hex');
const localFile = () => path.join(app.getPath('userData'), 'local.json');
function ecrireLocal() {
  if (!portTcp) return;
  try { fiab.ecrire(localFile(), JSON.stringify({ banque: PROTO, port: portTcp, jeton: JETON_LOCAL, pid: process.pid, version: app.getVersion(), dossier: racine(), nom: prefs.nom }, null, 2)); try { fs.chmodSync(localFile(), 0o600); } catch (e) {} } catch (e) { fiab.log('local', e && e.message); }
}
function effacerLocal() { try { const j = JSON.parse(fs.readFileSync(localFile(), 'utf8')); if (j && j.pid === process.pid) fs.unlinkSync(localFile()); } catch (e) {} }
function assurerBanque() { try { fs.mkdirSync(racine(), { recursive: true }); return true; } catch (e) { fiab.log('banque', e && e.message); return false; } }

/* ---------- chemins : toujours relatifs à la banque, avec « / », jamais en dehors ---------- */
const INTERDIT_WIN = /[<>:"|?*\\\x00-\x1f]/g;
function nettoyerNom(s) {
  // nom de fichier valable sur Mac comme sur Windows (un fichier envoyé d'un Mac peut arriver sur un PC)
  let n = String(s).normalize('NFC').replace(INTERDIT_WIN, '_').replace(/[. ]+$/, '');
  if (/^(con|prn|aux|nul|com\d|lpt\d)(\..*)?$/i.test(n)) n = '_' + n;
  return n.slice(0, 240);
}
function relValide(rel) {
  // « a/b/c.txt » : renvoie la liste des morceaux, ou null si le chemin sort de la banque
  if (typeof rel !== 'string' || rel.length > 4000) return null;
  const parts = rel.split('/').filter(p => p !== '');
  for (const p of parts) if (p === '.' || p === '..' || p.includes('\\') || /[\x00]/.test(p) || (isWin && /:/.test(p))) return null;
  return parts;
}
function absDansBanque(rel, { ecriture = false } = {}) {
  const parts = relValide(rel || '');
  if (!parts) return null;
  const root = path.resolve(racine());
  const abs = path.resolve(root, ...(ecriture ? parts.map(nettoyerNom) : parts));
  if (abs !== root && !abs.startsWith(root + path.sep)) return null;
  return abs;
}
// lecture : le vrai chemin (liens symboliques résolus) doit rester dans la banque
async function absLecture(rel) {
  const abs = absDansBanque(rel);
  if (!abs) return null;
  try {
    const root = await fsp.realpath(racine()), real = await fsp.realpath(abs);
    if (real !== root && !real.startsWith(root + path.sep)) return null;
    return real;
  } catch (e) { return null; }
}
const cache = (n) => n.startsWith('.') || IGNORES.has(n) || n.endsWith(PARTIEL);

async function lister(abs) {
  const out = [];
  let ents = [];
  try { ents = await fsp.readdir(abs, { withFileTypes: true }); } catch (e) { return null; }
  for (const d of ents) {
    if (cache(d.name)) continue;
    try {
      const st = await fsp.stat(path.join(abs, d.name));
      if (st.isDirectory()) out.push({ nom: d.name, dossier: true, date: st.mtimeMs });
      else if (st.isFile()) out.push({ nom: d.name, dossier: false, taille: st.size, date: st.mtimeMs });
    } catch (e) {}
  }
  out.sort((a, b) => (b.dossier - a.dossier) || a.nom.localeCompare(b.nom, 'fr', { numeric: true, sensitivity: 'base' }));
  return out;
}
// tous les fichiers sous un dossier (pour récupérer ou envoyer un dossier entier)
async function arbre(abs, prefixe, out, max = 50000) {
  let ents = [];
  try { ents = await fsp.readdir(abs, { withFileTypes: true }); } catch (e) { return out; }
  for (const d of ents) {
    if (out.length >= max) break;
    if (cache(d.name)) continue;
    const p = path.join(abs, d.name), rel = prefixe ? `${prefixe}/${d.name}` : d.name;
    try {
      const st = await fsp.stat(p);
      if (st.isDirectory()) await arbre(p, rel, out, max);
      else if (st.isFile()) out.push({ chemin: rel, taille: st.size, date: st.mtimeMs, abs: p });
    } catch (e) {}
  }
  return out;
}
async function tailleDossier(abs) { const l = await arbre(abs, '', [], 200000); return { n: l.length, taille: l.reduce((s, f) => s + f.taille, 0) }; }

/* ---------- ordinateurs du réseau ---------- */
const PAIRS = new Map();   // id -> { id, nom, adresse, port, version, principale, depot, plateforme, vuAt, manuel }
let win = null;
const toPage = (canal, ...a) => { if (win && !win.isDestroyed()) win.webContents.send(canal, ...a); };
let pubT = null;
function publierPairs() { clearTimeout(pubT); pubT = setTimeout(() => toPage('pairs', [...PAIRS.values()].map(resumePair)), 80); }
const resumePair = (p) => ({ id: p.id, nom: p.nom, adresse: p.adresse, port: p.port, version: p.version, principale: !!p.principale, depot: !!p.depot, plateforme: p.plateforme, perdu: Date.now() - p.vuAt > PERDU_MS, manuel: !!p.manuel, proto: p.proto });
const locales = () => { const s = new Set(['127.0.0.1']); for (const l of Object.values(os.networkInterfaces())) for (const a of l || []) if (a.family === 'IPv4') s.add(a.address); return s; };

function diffusions() {
  const out = new Set();
  for (const list of Object.values(os.networkInterfaces())) for (const a of list || []) {
    if (a.family !== 'IPv4' || a.internal) continue;
    const ip = a.address.split('.').map(Number), m = String(a.netmask || '255.255.255.0').split('.').map(Number);
    if (ip.length === 4 && m.length === 4) out.add(ip.map((v, i) => (v | (~m[i] & 255)) & 255).join('.'));
  }
  out.add('127.0.0.1');
  return [...out];
}
let portTcp = 0;
const annonce = (question = false) => Buffer.from(JSON.stringify({ banque: PROTO, id: prefs.id, nom: prefs.nom, port: portTcp, version: app.getVersion(),
  principale: !!prefs.principale, depot: !!(prefs.principale && prefs.depot), plateforme: process.platform, question: question || undefined }));

let udp = null, udpPret = false;
function ecouter() {
  udp = dgram.createSocket({ type: 'udp4', reuseAddr: true });
  udp.on('error', (e) => { fiab.log('udp', String(e && e.message || e)); udpPret = false; try { udp.close(); } catch (err) {} udp = null; setTimeout(ecouter, 5000); });
  udp.on('message', (b, ri) => {
    if (b.length > 2000) return;
    let m; try { m = JSON.parse(b.toString('utf8')); } catch (e) { return; }
    if (!m || m.banque !== PROTO || typeof m.id !== 'string' || m.id === prefs.id || !(+m.port > 0)) return;
    if (m.bye) { if (PAIRS.delete(m.id)) publierPairs(); return; }
    vu(m, ri.address);
    // un nouveau venu demande qui est là : réponse directe, sans attendre la prochaine annonce
    if (m.question && prefs.visible && udpPret && portTcp) { try { udp.send(annonce(), UDP_PORT, ri.address); } catch (e) {} }
  });
  udp.bind(UDP_PORT, () => { try { udp.setBroadcast(true); } catch (e) {} udpPret = true; annoncer(true); });
}
function vu(m, adresse, manuel = false) {
  const id = String(m.id).slice(0, 80);
  let p = PAIRS.get(id);
  const neuf = !p;
  if (!p) { p = { id }; PAIRS.set(id, p); }
  // le même ordinateur entendu par 127.0.0.1 et par le réseau : on garde l'adresse du réseau
  if (!(adresse === '127.0.0.1' && p.adresse && p.adresse !== '127.0.0.1' && Date.now() - p.vuAt < PERDU_MS)) p.adresse = adresse;
  const avant = JSON.stringify(resumePair(p));
  Object.assign(p, { nom: String(m.nom || id).slice(0, 60), port: +m.port, version: String(m.version || '').slice(0, 20), principale: !!m.principale, depot: !!m.depot,
    plateforme: String(m.plateforme || '').slice(0, 10), proto: m.banque, vuAt: Date.now(), manuel: manuel || p.manuel });
  if (neuf || JSON.stringify(resumePair(p)) !== avant) publierPairs();
}
function annoncer(question = false) {
  if (!udp || !udpPret || !portTcp) return;
  if (!prefs.visible && !question) return;
  const msg = prefs.visible ? annonce(question) : Buffer.from(JSON.stringify({ banque: PROTO, id: prefs.id, bye: true, port: portTcp }));
  for (const b of diffusions()) { try { udp.send(msg, UDP_PORT, b, () => {}); } catch (e) {} }
}
// ordinateurs ajoutés à la main (Wi-Fi qui bloque les annonces) : on leur demande /v1/info
async function sonderManuels() {
  for (const adr of prefs.manuels) {
    const [h, pt] = String(adr).split(':');
    try { const info = await getJSON({ adresse: h, port: +pt || TCP_PORT }, '/v1/info', 2500); if (info && info.id && info.id !== prefs.id) vu(Object.assign({ banque: PROTO }, info), h, true); } catch (e) {}
  }
}
setInterval(() => {
  annoncer();
  let ch = false;
  for (const [id, p] of PAIRS) {
    const age = Date.now() - p.vuAt;
    if (age > 120000) { PAIRS.delete(id); ch = true; }   // parti depuis 2 min : oublié
    else if (age > PERDU_MS && !p.perduSignale) { p.perduSignale = true; ch = true; }
    else if (age <= PERDU_MS && p.perduSignale) { p.perduSignale = false; ch = true; }
  }
  if (ch) publierPairs();
}, 2000);
setInterval(sonderManuels, 3000);

/* ---------- client HTTP vers un autre Banque ---------- */
function requete(p, methode, chemin, { corps = null, entetes = {}, timeout = 15000 } = {}) {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: p.adresse, port: p.port, method: methode, path: chemin, headers: Object.assign({ 'X-Banque-Id': prefs.id, 'X-Banque-Nom': encodeURIComponent(prefs.nom) }, entetes), timeout }, resolve);
    req.on('timeout', () => req.destroy(new Error('Pas de réponse de l’autre ordinateur.')));
    req.on('error', reject);
    if (corps != null) req.end(corps); else req.end();
  });
}
function lireTout(res, max = 64e6) {
  return new Promise((resolve, reject) => {
    const bufs = []; let n = 0;
    res.on('data', d => { n += d.length; if (n > max) { res.destroy(); reject(new Error('Réponse trop longue')); } else bufs.push(d); });
    res.on('end', () => resolve(Buffer.concat(bufs)));
    res.on('error', reject);
  });
}
async function getJSON(p, chemin, timeout = 15000) {
  const res = await requete(p, 'GET', chemin, { timeout });
  const b = await lireTout(res);
  let j; try { j = JSON.parse(b.toString('utf8')); } catch (e) { throw new Error('Réponse illisible de l’autre ordinateur.'); }
  if (res.statusCode >= 400) throw new Error(j && j.erreur || `Erreur ${res.statusCode}`);
  return j;
}
async function postJSON(p, chemin, obj, timeout = 15000) {
  const corps = Buffer.from(JSON.stringify(obj));
  const res = await requete(p, 'POST', chemin, { corps, entetes: { 'Content-Type': 'application/json', 'Content-Length': corps.length }, timeout });
  const b = await lireTout(res);
  let j; try { j = JSON.parse(b.toString('utf8')); } catch (e) { throw new Error('Réponse illisible de l’autre ordinateur.'); }
  if (res.statusCode >= 400 && !(j && 'ok' in j)) throw new Error(j && j.erreur || `Erreur ${res.statusCode}`);
  return j;
}
const pair = (id) => { const p = PAIRS.get(id); if (!p) throw new Error('Cet ordinateur n’est plus visible sur le réseau.'); return p; };

/* ---------- serveur : ce que les autres peuvent demander ---------- */
const DEMANDES = new Map();   // rid -> { resolve, timer }  (envoi qui attend la réponse de l'utilisateur)
const JETONS = new Map();     // jeton -> { de, nom, base, fichiers: [{chemin, taille, fait}], tid, finA }
function repondre(res, code, obj) { const b = Buffer.from(JSON.stringify(obj)); res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': b.length }); res.end(b); }
async function lireCorpsJSON(req, max = 8e6) {
  const bufs = []; let n = 0;
  for await (const d of req) { n += d.length; if (n > max) throw new Error('trop long'); bufs.push(d); }
  return JSON.parse(Buffer.concat(bufs).toString('utf8'));
}
const deQui = (req) => ({ id: String(req.headers['x-banque-id'] || '').slice(0, 80), nom: (() => { try { return decodeURIComponent(String(req.headers['x-banque-nom'] || '')).slice(0, 60); } catch (e) { return ''; } })() });

async function serveur(req, res) {
  const u = new URL(req.url, 'http://x');
  const q = (k) => u.searchParams.get(k) || '';
  try {
    if (req.method === 'GET' && u.pathname === '/v1/info') {
      return repondre(res, 200, { banque: PROTO, id: prefs.id, nom: prefs.nom, port: portTcp, version: app.getVersion(), principale: !!prefs.principale, depot: !!(prefs.principale && prefs.depot), plateforme: process.platform });
    }
    // ---- logiciels Lanterne du même ordinateur (Lanterne PPT, Player, Son) : adresse locale + jeton de local.json ----
    if (u.pathname.startsWith('/v1/local/')) return await serveurLocal(req, res, u);
    // ---- écran Intervenants préparé d'un autre ordinateur (ordinateur accepté une fois, « toujours accepter ») ----
    if (u.pathname === '/v1/intervenants' || u.pathname === '/v1/intervenants/acces') {
      const qui = deQui(req);
      if (u.pathname === '/v1/intervenants/acces' && req.method === 'POST') {
        if (prefs.confiance.some(c => c.id === qui.id)) return repondre(res, 200, { ok: true });
        const rep = await demanderAccord({ id: qui.id, nom: qui.nom || 'Un ordinateur', sorte: 'intervenants', n: 0, total: 0, liste: [] });
        if (!rep.accepte) return repondre(res, 200, { ok: false, raison: rep.raison || 'Refusé.' });
        if (qui.id && !prefs.confiance.some(c => c.id === qui.id)) { prefs.confiance.push({ id: qui.id, nom: qui.nom || qui.id }); savePrefs(); toPage('prefs'); }
        return repondre(res, 200, { ok: true });
      }
      if (!qui.id || !prefs.confiance.some(c => c.id === qui.id)) return repondre(res, 403, { erreur: 'Cet ordinateur doit d’abord accepter le tien.', accord: true });
      if (req.method === 'GET') return repondre(res, 200, vueInterv());
      if (req.method === 'POST') { const op = await lireCorpsJSON(req, 1e6); const r = opInterv(op, qui.nom, { distant: true }); return repondre(res, 200, Object.assign({ ok: r.ok !== false, raison: r.raison || '', nouvelle: r.nouvelle || '' }, vueInterv())); }
    }
    // ---- mode 1 : parcourir et récupérer la banque principale ----
    if (req.method === 'GET' && (u.pathname === '/v1/liste' || u.pathname === '/v1/arbre' || u.pathname === '/v1/fichier')) {
      if (!prefs.principale) return repondre(res, 403, { erreur: 'Cet ordinateur ne partage plus sa banque.' });
      const abs = await absLecture(q('chemin'));
      if (!abs) return repondre(res, 404, { erreur: 'Introuvable dans la banque.' });
      if (u.pathname === '/v1/liste') {
        const l = await lister(abs);
        if (!l) return repondre(res, 404, { erreur: 'Dossier introuvable dans la banque.' });
        return repondre(res, 200, { chemin: q('chemin'), entrees: l });
      }
      if (u.pathname === '/v1/arbre') {
        const st = await fsp.stat(abs);
        const l = st.isDirectory() ? await arbre(abs, '', []) : [{ chemin: '', taille: st.size, date: st.mtimeMs }];
        return repondre(res, 200, { fichiers: l.map(f => ({ chemin: f.chemin, taille: f.taille, date: f.date })) });
      }
      // fichier, avec reprise (Range: bytes=N-)
      const st = await fsp.stat(abs);
      if (!st.isFile()) return repondre(res, 404, { erreur: 'Ce n’est pas un fichier.' });
      let debut = 0;
      const m = /^bytes=(\d+)-$/.exec(String(req.headers.range || ''));
      if (m) debut = Math.min(+m[1], st.size);
      res.writeHead(debut ? 206 : 200, { 'Content-Type': 'application/octet-stream', 'Content-Length': st.size - debut, 'X-Banque-Taille': st.size, 'X-Banque-Date': Math.round(st.mtimeMs),
        ...(debut ? { 'Content-Range': `bytes ${debut}-${st.size - 1}/${st.size}` } : {}) });
      if (st.size - debut === 0) return res.end();
      const rs = fs.createReadStream(abs, { start: debut, highWaterMark: 1 << 20 });
      rs.on('error', () => res.destroy());
      return rs.pipe(res);
    }
    // ---- mode 2 : quelqu'un veut m'envoyer des fichiers (ou déposer dans ma banque principale) ----
    if (req.method === 'POST' && u.pathname === '/v1/demande') {
      const d = await lireCorpsJSON(req);
      const qui = deQui(req);
      const fichiers = Array.isArray(d.fichiers) ? d.fichiers.slice(0, 50000) : [];
      if (!fichiers.length) return repondre(res, 400, { ok: false, raison: 'Aucun fichier.' });
      for (const f of fichiers) if (!relValide(f.chemin) || !relValide(f.chemin).length || !(+f.taille >= 0)) return repondre(res, 400, { ok: false, raison: 'Nom de fichier refusé.' });
      const total = fichiers.reduce((s, f) => s + (+f.taille || 0), 0);
      const nom = String(d.nom || qui.nom || 'Un ordinateur').slice(0, 60);
      let base, lv = null;
      if (d.depot) {
        if (!prefs.principale || !prefs.depot) return repondre(res, 200, { ok: false, raison: 'Cette banque n’accepte pas les dépôts.' });
        base = String(d.dossier || '');
        if (!relValide(base)) return repondre(res, 200, { ok: false, raison: 'Dossier refusé.' });
      } else {
        const confiance = prefs.confiance.some(c => c.id === qui.id);
        let rep = { accepte: confiance };
        if (!confiance) rep = await demanderAccord({ id: qui.id, nom, sorte: d.intervenants ? 'intervenants-envoi' : '', n: fichiers.length, total, liste: fichiers.slice(0, 200).map(f => ({ chemin: f.chemin, taille: +f.taille })) });
        if (!rep.accepte) return repondre(res, 200, { ok: false, raison: rep.raison || 'Envoi refusé.' });
        if (d.intervenants) { lv = listeDe({ liste: typeof d.liste === 'string' ? d.liste : '' }) || listeOuverte(); base = lv.dossier; }
        else base = `${RECUS}/${nettoyerNom(nom) || 'Inconnu'}`;
      }
      if (!assurerBanque()) return repondre(res, 200, { ok: false, raison: 'La banque de l’ordinateur qui reçoit est inaccessible.' });
      const jeton = crypto.randomBytes(18).toString('hex');
      const tid = nouveauTransfert({ sens: d.depot ? 'depot-recu' : 'recu', pairNom: nom, n: fichiers.length, total, dossier: base });
      JETONS.set(jeton, { de: qui.id, nom, base, intervenants: !d.depot && !!d.intervenants, liste: lv ? lv.id : '', fichiers: fichiers.map(f => ({ chemin: f.chemin, taille: +f.taille, date: +f.date || 0, fait: false })), tid, vuA: Date.now() });
      return repondre(res, 200, { ok: true, jeton });
    }
    if (req.method === 'PUT' && u.pathname === '/v1/recevoir') {
      const j = JETONS.get(q('jeton'));
      const i = +q('i');
      if (!j || !j.fichiers[i] || j.fichiers[i].fait) return repondre(res, 403, { erreur: 'Envoi inconnu ou terminé.' });
      return recevoirFichier(req, res, j, i);
    }
    if (req.method === 'POST' && u.pathname === '/v1/fin') {
      const j = JETONS.get(q('jeton'));
      if (j) { JETONS.delete(q('jeton')); const t = TRANSFERTS.get(j.tid); if (t && t.etat === 'en cours') majTransfert(j.tid, q('annule') ? { etat: 'annule' } : { etat: j.fichiers.every(f => f.fait) ? 'fini' : 'erreur', erreur: j.fichiers.every(f => f.fait) ? '' : 'Envoi interrompu.' }); }
      return repondre(res, 200, { ok: true });
    }
    return repondre(res, 404, { erreur: 'Inconnu' });
  } catch (e) {
    fiab.log('serveur', e && e.stack || e);
    if (!res.headersSent) repondre(res, 500, { erreur: 'Erreur sur l’ordinateur distant.' }); else res.destroy();
  }
}
async function recevoirFichier(req, res, j, i) {
  const f = j.fichiers[i];
  const rel = `${j.base ? j.base + '/' : ''}${f.chemin}`;
  let abs = absDansBanque(rel, { ecriture: true });
  if (!abs) return repondre(res, 403, { erreur: 'Chemin refusé.' });
  j.vuA = Date.now();
  majTransfert(j.tid, { etat: 'en cours', fichier: f.chemin });
  try {
    await fsp.mkdir(path.dirname(abs), { recursive: true });
    abs = await destination(abs, f.taille, f.date);
    if (!abs) { req.resume(); f.fait = true; avancer(j.tid, f.taille, true); if (j.intervenants) ajouterRecuInterv(absDansBanque(rel, { ecriture: true }), j.nom, j.liste); return repondre(res, 200, { ok: true, passe: true }); }
    const tmp = abs + PARTIEL;
    const ws = fs.createWriteStream(tmp);
    let n = 0;
    await new Promise((resolve, reject) => {
      req.on('data', d => { n += d.length; avancer(j.tid, d.length); j.vuA = Date.now(); if (n > f.taille) { req.destroy(); reject(new Error('Fichier plus long que prévu')); } });
      req.on('aborted', () => reject(new Error('Envoi interrompu')));
      req.on('error', reject); ws.on('error', reject);
      ws.on('finish', resolve);
      req.pipe(ws);
    });
    if (n !== f.taille) throw new Error('Fichier incomplet');
    await fsp.rename(tmp, abs);
    if (f.date) { try { const t = new Date(f.date); await fsp.utimes(abs, t, t); } catch (e) {} }
    f.fait = true;
    avancer(j.tid, 0, true);
    if (j.intervenants) ajouterRecuInterv(abs, j.nom, j.liste);
    repondre(res, 200, { ok: true });
  } catch (e) {
    try { await fsp.unlink(abs + PARTIEL); } catch (er) {}
    majTransfert(j.tid, { etat: 'erreur', erreur: e.message || String(e) });
    if (!res.headersSent) repondre(res, 500, { erreur: e.message || 'Erreur' });
  }
}
// envoi abandonné sans « fin » (ordinateur éteint) : jeton oublié après 2 min sans nouvelles
setInterval(() => { for (const [k, j] of JETONS) if (Date.now() - j.vuA > 120000) { JETONS.delete(k); const t = TRANSFERTS.get(j.tid); if (t && (t.etat === 'en cours' || t.etat === 'attente')) majTransfert(j.tid, { etat: 'erreur', erreur: 'L’envoi s’est arrêté.' }); } }, 10000);

// fichier déjà présent : garder les deux (« nom (2).ext »), remplacer, ou passer ; identique (taille et date) : passé
async function destination(abs, taille, date) {
  let st = null;
  try { st = await fsp.stat(abs); } catch (e) { return abs; }
  if (st.isFile() && st.size === taille && (!date || Math.abs(st.mtimeMs - date) < 2000)) return null;
  if (prefs.conflit === 'passer') return null;
  if (prefs.conflit === 'remplacer' && st.isFile()) return abs;
  const ext = path.extname(abs), b = abs.slice(0, abs.length - ext.length);
  for (let k = 2; k < 10000; k++) { const c = `${b} (${k})${ext}`; try { await fsp.stat(c); } catch (e) { return c; } }
  return null;
}

function demanderAccord(info) {
  return new Promise((resolve) => {
    if (!win || win.isDestroyed()) return resolve({ accepte: false, raison: 'Banque est fermée sur l’ordinateur qui reçoit.' });
    const rid = crypto.randomBytes(8).toString('hex');
    const timer = setTimeout(() => { DEMANDES.delete(rid); toPage('demande-fin', rid); resolve({ accepte: false, raison: 'Pas de réponse sur l’ordinateur qui reçoit (2 minutes).' }); }, 120000);
    DEMANDES.set(rid, { resolve, timer, info });
    toPage('demande', Object.assign({ rid }, info));
    montrer(true);
    try { if (Notification.isSupported()) new Notification({ title: 'Banque', body: `${info.nom} veut t’envoyer ${info.n} fichier${info.n > 1 ? 's' : ''}.`, silent: false }).show(); } catch (e) {}
  });
}
ipcMain.handle('repondre', (_e, rid, accepte, toujours) => {
  const d = DEMANDES.get(rid);
  if (!d) return false;
  DEMANDES.delete(rid); clearTimeout(d.timer);
  if (accepte && toujours && d.info.id && !prefs.confiance.some(c => c.id === d.info.id)) { prefs.confiance.push({ id: d.info.id, nom: d.info.nom }); savePrefs(); toPage('prefs', prefs); }
  d.resolve({ accepte: !!accepte, raison: accepte ? '' : 'L’autre ordinateur a refusé l’envoi.' });
  return true;
});

let srv = null;
function demarrerServeur() {
  return new Promise((resolve) => {
    srv = http.createServer(serveur);
    srv.requestTimeout = 0; srv.headersTimeout = 20000; srv.keepAliveTimeout = 5000;
    srv.on('error', (e) => {
      if (e.code === 'EADDRINUSE' && !srv._repli) { srv._repli = true; fiab.log('serveur', `port ${TCP_PORT} pris, port libre au hasard`); srv.listen(0, '0.0.0.0'); }
      else { fiab.log('serveur', e && e.message); resolve(); }
    });
    srv.on('listening', () => { portTcp = srv.address().port; ecrireLocal(); resolve(); });
    srv.listen(TCP_PORT, '0.0.0.0');
  });
}

/* ---------- transferts (récupérer, envoyer, déposer, recevoir) ---------- */
const TRANSFERTS = new Map();   // tid -> { tid, sens, pairNom, n, total, fait, nFait, etat, erreur, debut, vitesse, fichier, dossier, annuler }
let tSeq = 0, pubTr = null;
const resumeT = (t) => { const { annuler, _v, destinations, ...r } = t; return r; };
function publierTransferts() { if (pubTr) return; pubTr = setTimeout(() => { pubTr = null; toPage('transferts', [...TRANSFERTS.values()].map(resumeT)); }, 150); }
function nouveauTransfert(o) {
  const tid = ++tSeq;
  TRANSFERTS.set(tid, Object.assign({ tid, fait: 0, nFait: 0, etat: 'attente', erreur: '', debut: Date.now(), vitesse: 0, fichier: '' }, o));
  publierTransferts();
  return tid;
}
function majTransfert(tid, o) {
  const t = TRANSFERTS.get(tid); if (!t) return;
  if (['fini', 'erreur', 'annule', 'refuse'].includes(t.etat)) return;   // un transfert terminé ne bouge plus
  Object.assign(t, o);
  if (o.etat && ['fini', 'erreur', 'annule', 'refuse'].includes(o.etat)) { t.finA = Date.now(); if (o.etat === 'fini' && t.sens !== 'envoi' && t.sens !== 'depot') signalerFin(t); }
  publierTransferts();
}
function avancer(tid, octets, fichierFini = false) {
  const t = TRANSFERTS.get(tid); if (!t) return;
  t.fait += octets; if (fichierFini) t.nFait++;
  const now = Date.now();
  if (!t._v) t._v = { at: now, fait: t.fait };
  if (now - t._v.at >= 700) { const v = (t.fait - t._v.fait) / ((now - t._v.at) / 1000); t.vitesse = t.vitesse ? t.vitesse * 0.5 + v * 0.5 : v; t._v = { at: now, fait: t.fait }; }
  publierTransferts();
}
function signalerFin(t) {
  if (t.sens === 'recu' || t.sens === 'depot-recu') {
    try { if (Notification.isSupported() && !(win && win.isFocused())) new Notification({ title: 'Banque', body: `${t.n} fichier${t.n > 1 ? 's' : ''} reçu${t.n > 1 ? 's' : ''} de ${t.pairNom}.` }).show(); } catch (e) {}
  }
}

// mode 1 : récupérer des fichiers ou dossiers d'une banque principale dans ma banque (même rangement)
async function recuperer(pairId, chemins, onTid) {
  const p = pair(pairId);
  const tid = nouveauTransfert({ sens: 'recup', pairNom: p.nom, n: 0, total: 0, dossier: '' });
  if (onTid) onTid(tid);
  const t = TRANSFERTS.get(tid);
  t.destinations = {};   // chemin dans la banque principale -> fichier de ma banque (« nom (2) » si un autre fichier avait ce nom)
  let annule = false, reqEnCours = null;
  t.annuler = () => { annule = true; if (reqEnCours) reqEnCours.destroy(new Error('Annulé')); };
  try {
    if (!assurerBanque()) throw new Error('Ta banque est inaccessible (Réglages › Dossier de la banque).');
    const liste = [];
    for (const c of chemins) {
      const a = await getJSON(p, `/v1/arbre?chemin=${encodeURIComponent(c)}`, 60000);
      for (const f of a.fichiers) liste.push({ chemin: f.chemin ? `${c}/${f.chemin}` : c, taille: f.taille, date: f.date });
    }
    majTransfert(tid, { n: liste.length, total: liste.reduce((s, f) => s + f.taille, 0), etat: 'en cours', dossier: commun(chemins) });
    for (const f of liste) {
      if (annule) break;
      majTransfert(tid, { fichier: f.chemin });
      let abs = absDansBanque(f.chemin, { ecriture: true });
      if (!abs) throw new Error(`Nom refusé : ${f.chemin}`);
      await fsp.mkdir(path.dirname(abs), { recursive: true });
      const voulu = abs;
      abs = await destination(abs, f.taille, f.date);
      if (!abs) { t.destinations[f.chemin] = voulu; avancer(tid, f.taille, true); continue; }
      // reprise : un morceau déjà reçu (transfert coupé) est complété au lieu d'être refait
      const tmp = abs + PARTIEL;
      let deja = 0; try { deja = (await fsp.stat(tmp)).size; } catch (e) {}
      if (deja > f.taille) { deja = 0; try { await fsp.unlink(tmp); } catch (e) {} }
      if (deja) avancer(tid, deja);
      await new Promise((resolve, reject) => {
        const req = http.request({ host: p.adresse, port: p.port, method: 'GET', path: `/v1/fichier?chemin=${encodeURIComponent(f.chemin)}`, headers: Object.assign({ 'X-Banque-Id': prefs.id }, deja ? { Range: `bytes=${deja}-` } : {}), timeout: 30000 }, (res) => {
          if (res.statusCode !== 200 && res.statusCode !== 206) { lireTout(res).then(b => { let m = `Erreur ${res.statusCode}`; try { m = JSON.parse(b).erreur || m; } catch (e) {} reject(new Error(m)); }, reject); return; }
          if (res.statusCode === 200 && deja) { avancer(tid, -deja); deja = 0; }
          const ws = fs.createWriteStream(tmp, { flags: deja ? 'a' : 'w' });
          res.on('data', d => avancer(tid, d.length));
          res.on('aborted', () => reject(new Error('Transfert coupé')));
          res.on('error', reject); ws.on('error', reject);
          ws.on('finish', resolve);
          res.pipe(ws);
        });
        reqEnCours = req;
        req.on('timeout', () => req.destroy(new Error('Plus de nouvelles de la banque principale.')));
        req.on('error', reject);
        req.end();
      });
      reqEnCours = null;
      const st = await fsp.stat(tmp);
      if (st.size !== f.taille) throw new Error(`Fichier incomplet : ${f.chemin}`);
      await fsp.rename(tmp, abs);
      if (f.date) { try { const d = new Date(f.date); await fsp.utimes(abs, d, d); } catch (e) {} }
      t.destinations[f.chemin] = abs;
      avancer(tid, 0, true);
    }
    majTransfert(tid, annule ? { etat: 'annule' } : { etat: 'fini', fichier: '' });
  } catch (e) {
    majTransfert(tid, annule ? { etat: 'annule' } : { etat: 'erreur', erreur: e.message || String(e) });
  }
  toPage('banque-change');
  return tid;
}
const commun = (chemins) => { if (chemins.length !== 1) return ''; const c = chemins[0]; return c; };

// mode 2 (et dépôt dans une banque principale) : envoyer des fichiers ou dossiers de cet ordinateur
async function envoyer(pairId, absListe, { depot = false, dossier = '', intervenants = false, listeId = '', listeNom = '' } = {}) {
  const p = pair(pairId);
  const tid = nouveauTransfert({ sens: depot ? 'depot' : 'envoi', pairNom: p.nom, n: 0, total: 0, dossier: intervenants ? (listeNom ? `${INTERV_DOSSIER} › ${listeNom}` : INTERV_DOSSIER) : dossier, intervenants });
  const t = TRANSFERTS.get(tid);
  let annule = false, reqEnCours = null, jeton = null;
  t.annuler = () => { annule = true; if (reqEnCours) reqEnCours.destroy(new Error('Annulé')); };
  try {
    const liste = [];
    for (const a of absListe) {
      const st = await fsp.stat(a);
      const nom = path.basename(a);
      if (st.isDirectory()) await arbre(a, nom, liste);
      else if (st.isFile()) liste.push({ chemin: nom, taille: st.size, date: st.mtimeMs, abs: a });
    }
    if (!liste.length) throw new Error('Rien à envoyer (dossier vide ?).');
    const total = liste.reduce((s, f) => s + f.taille, 0);
    majTransfert(tid, { n: liste.length, total, etat: 'demande' });
    const rep = await postJSON(p, '/v1/demande', { nom: prefs.nom, depot, dossier, intervenants: intervenants || undefined, liste: (intervenants && listeId) || undefined, fichiers: liste.map(f => ({ chemin: f.chemin, taille: f.taille, date: Math.round(f.date) })) }, 130000);
    if (annule) { majTransfert(tid, { etat: 'annule' }); return; }
    if (!rep.ok) { majTransfert(tid, { etat: 'refuse', erreur: rep.raison || 'Refusé' }); return; }
    jeton = rep.jeton;
    majTransfert(tid, { etat: 'en cours', debut: Date.now() });
    for (let i = 0; i < liste.length; i++) {
      if (annule) break;
      const f = liste[i];
      majTransfert(tid, { fichier: f.chemin });
      await new Promise((resolve, reject) => {
        const req = http.request({ host: p.adresse, port: p.port, method: 'PUT', path: `/v1/recevoir?jeton=${jeton}&i=${i}`, headers: { 'Content-Type': 'application/octet-stream', 'Content-Length': f.taille, 'X-Banque-Id': prefs.id }, timeout: 30000 }, (res) => {
          lireTout(res).then(b => { if (res.statusCode === 200) resolve(); else { let m = `Erreur ${res.statusCode}`; try { m = JSON.parse(b).erreur || m; } catch (e) {} reject(new Error(m)); } }, reject);
        });
        reqEnCours = req;
        req.on('timeout', () => req.destroy(new Error('Plus de nouvelles de l’autre ordinateur.')));
        req.on('error', reject);
        const rs = fs.createReadStream(f.abs, { highWaterMark: 1 << 20 });
        rs.on('data', d => avancer(tid, d.length));
        rs.on('error', reject);
        rs.pipe(req);
      });
      reqEnCours = null;
      avancer(tid, 0, true);
    }
    try { await postJSON(p, `/v1/fin?jeton=${jeton}${annule ? '&annule=1' : ''}`, {}, 5000); } catch (e) {}
    majTransfert(tid, annule ? { etat: 'annule' } : { etat: 'fini', fichier: '' });
  } catch (e) {
    if (jeton) { try { await postJSON(p, `/v1/fin?jeton=${jeton}&annule=1`, {}, 3000); } catch (er) {} }
    majTransfert(tid, annule ? { etat: 'annule' } : { etat: 'erreur', erreur: e.message || String(e) });
  }
}

/* ---------- sources de banque ----------
   Aujourd'hui une seule sorte : « reseau » (une banque principale du réseau local). Plus tard : « en-ligne »
   (stockage gratuit sur Internet) avec les mêmes quatre actions, sans toucher à la page. */
const SOURCES = {
  reseau: {
    liste: (id, chemin) => getJSON(pair(id), `/v1/liste?chemin=${encodeURIComponent(chemin || '')}`),
    recuperer: (id, chemins) => { recuperer(id, chemins); return true; },
    deposer: (id, dossier, absListe) => { envoyer(id, absListe, { depot: true, dossier }); return true; },
  },
};

/* ---------- écran Intervenants ----------
   Une liste de diaporamas PowerPoint de ma banque (un par intervenant), lancés un par un dans Lanterne PPT.
   À la fin d'un diaporama (un appui de plus sur l'écran noir « Fin du diaporama »), Lanterne PPT se cache en gardant
   sa sortie noire et Banque revient devant, sur cette liste. Un autre ordinateur accepté (« toujours accepter »)
   peut préparer les listes à distance : ses PPT arrivent dans <banque>/Intervenants/<liste> et s'ajoutent tout seuls.
   1.2.0 : plusieurs listes nommées (une par salle, matin, après-midi…). */
const PPT_RE = /\.(pptx|ppsx|pptm|ppsm)$/i;
const intervFile = () => path.join(app.getPath('userData'), 'intervenants.json');
// Plusieurs listes nommées (salles, matin, après-midi…) ; chaque liste range ses PPT dans <banque>/Intervenants/<nom de la liste>.
// listes : [{ id, nom, dossier, liste: [{ id, nom, fichier (chemin dans ma banque), fait, par }] }] ; ouverte : liste montrée ici.
// Un même PPT peut être dans plusieurs listes ; l'id d'un intervenant est unique dans toutes les listes.
const LISTES_MAX = 60;
let INTERV = { rev: 0, listes: [], ouverte: '', courant: null };
const nouvelleListe = (nom, dossier) => ({ id: crypto.randomUUID(), nom, dossier, liste: [] });
const itemsPropres = (l) => (Array.isArray(l) ? l : []).filter(x => x && typeof x.fichier === 'string' && relValide(x.fichier))
  .map(x => ({ id: String(x.id || crypto.randomUUID()).slice(0, 60), nom: String(x.nom || '').slice(0, 120), fichier: x.fichier, fait: !!x.fait, par: String(x.par || '').slice(0, 60) }));
const dossierValide = (d) => typeof d === 'string' && (d === INTERV_DOSSIER || d.startsWith(INTERV_DOSSIER + '/')) && !!relValide(d);
function loadInterv() {
  let j = null; try { j = JSON.parse(fs.readFileSync(intervFile(), 'utf8')); } catch (e) {}
  const listes = [], vus = new Set();
  if (j && Array.isArray(j.listes)) for (const l of j.listes.slice(0, LISTES_MAX)) {
    if (!l || typeof l !== 'object') continue;
    let id = String(l.id || '').slice(0, 60); if (!id || vus.has(id)) id = crypto.randomUUID(); vus.add(id);
    listes.push({ id, nom: String(l.nom || '').trim().slice(0, 80) || 'Liste', dossier: dossierValide(l.dossier) ? l.dossier : INTERV_DOSSIER, liste: itemsPropres(l.liste) });
  }
  else if (j && Array.isArray(j.liste)) listes.push(Object.assign(nouvelleListe('Intervenants', INTERV_DOSSIER), { liste: itemsPropres(j.liste) }));   // liste unique de Banque 1.1
  if (!listes.length) listes.push(nouvelleListe('Liste 1', INTERV_DOSSIER + '/Liste 1'));
  INTERV = { rev: +(j && j.rev) || 0, listes, ouverte: listes.some(l => l.id === (j && j.ouverte)) ? j.ouverte : listes[0].id, courant: null };
}
function relDe(abs) { if (!abs) return null; const r = path.relative(path.resolve(racine()), path.resolve(abs)); if (!r || r.startsWith('..') || path.isAbsolute(r)) return null; return r.split(path.sep).join('/'); }
const nomDe = (rel) => path.basename(rel).replace(/\.[^.]+$/, '');
const listeOuverte = () => INTERV.listes.find(l => l.id === INTERV.ouverte) || INTERV.listes[0];
// liste visée par une demande : op.liste ; sans liste (Banque 1.1 de l'autre côté) : la liste ouverte ici
const listeDe = (op) => (op && op.liste) ? (INTERV.listes.find(l => l.id === op.liste) || null) : listeOuverte();
function trouverItem(id) { for (const l of INTERV.listes) { const i = l.liste.findIndex(x => x.id === id); if (i >= 0) return { l, i, x: l.liste[i] }; } return null; }
const memeNom = (a, b) => String(a).normalize('NFC').toLowerCase() === String(b).normalize('NFC').toLowerCase();
function nomLibre(base, sauf) {
  base = String(base || '').trim().slice(0, 80) || 'Nouvelle liste';
  const pris = (n) => INTERV.listes.some(l => l !== sauf && memeNom(l.nom, n));
  if (!pris(base)) return base;
  for (let k = 2; ; k++) { const n = `${base.slice(0, 74)} ${k}`; if (!pris(n)) return n; }
}
function dossierPour(nom, sauf) {
  const b = nettoyerNom(String(nom).replace(/[\/\\]/g, '_')).replace(/^[. ]+/, '') || 'Liste';
  const pris = (d) => INTERV.listes.some(l => l !== sauf && memeNom(l.dossier, d));
  let d = `${INTERV_DOSSIER}/${b}`;
  for (let k = 2; pris(d); k++) d = `${INTERV_DOSSIER}/${b} (${k})`;
  return d;
}
// la liste change de nom : son sous-dossier aussi (s'il existe, si la place est libre et si rien n'y arrive en ce moment)
function renommerDossier(l, nouveau) {
  const ancien = l.dossier;
  if (ancien === nouveau) return;
  let deplace = false;
  if (ancien !== INTERV_DOSSIER && ![...JETONS.values()].some(j => j.base === ancien)) {
    const a = absDansBanque(ancien), b = absDansBanque(nouveau, { ecriture: true });
    try { if (a && b && fs.statSync(a).isDirectory() && !fs.existsSync(b)) { fs.renameSync(a, b); deplace = true; } }
    catch (e) { fiab.log('intervenants', 'dossier non renommé : ' + (e && e.message)); }
  }
  if (deplace) { const p = ancien + '/'; for (const L of INTERV.listes) for (const x of L.liste) if (x.fichier.startsWith(p)) x.fichier = nouveau + '/' + x.fichier.slice(p.length); }
  l.dossier = nouveau;
}
function vueItems(l) {
  return l.liste.map(x => {
    const abs = absDansBanque(x.fichier); let existe = false, taille = 0;
    try { const st = fs.statSync(abs); existe = st.isFile(); taille = st.size; } catch (e) {}
    return Object.assign({}, x, { existe, taille });
  });
}
function vueInterv() {
  const listes = INTERV.listes.map(l => ({ id: l.id, nom: l.nom, dossier: l.dossier, liste: vueItems(l) }));
  const o = listes.find(l => l.id === INTERV.ouverte) || listes[0];
  // « liste » : la liste ouverte, pour une Banque 1.1 qui prépare d'un autre ordinateur
  return { nom: prefs.nom, rev: INTERV.rev, courant: INTERV.courant, ouverte: o.id, listes, liste: o.liste };
}
let intervT = null;
function intervChange() {
  INTERV.rev++;
  try { fs.mkdirSync(path.dirname(intervFile()), { recursive: true }); fiab.ecrire(intervFile(), JSON.stringify({ format: 2, rev: INTERV.rev, ouverte: INTERV.ouverte, listes: INTERV.listes }, null, 2)); } catch (e) { fiab.log('intervenants', e && e.message); }
  clearTimeout(intervT); intervT = setTimeout(() => toPage('intervenants', vueInterv()), 50);
}
function opInterv(op, par = '', { distant = false } = {}) {
  if (!op || typeof op.op !== 'string') return { ok: false, raison: 'Demande inconnue.' };
  const plusLa = { ok: false, raison: 'Cette liste n’existe plus.' };
  switch (op.op) {
    // ---- les listes ----
    case 'liste-creer': {
      if (INTERV.listes.length >= LISTES_MAX) return { ok: false, raison: `${LISTES_MAX} listes au plus.` };
      const nom = nomLibre(op.nom);
      const l = nouvelleListe(nom, dossierPour(nom));
      INTERV.listes.push(l);
      if (!distant) INTERV.ouverte = l.id;
      intervChange(); return { ok: true, nouvelle: l.id };
    }
    case 'liste-renommer': {
      const l = INTERV.listes.find(x => x.id === op.liste); if (!l) return plusLa;
      const nom = String(op.nom || '').trim().slice(0, 80);
      if (!nom) return { ok: false, raison: 'Donne un nom à la liste.' };
      if (INTERV.listes.some(x => x !== l && memeNom(x.nom, nom))) return { ok: false, raison: `Une autre liste s’appelle déjà « ${nom} ».` };
      if (nom === l.nom) return { ok: true };
      l.nom = nom; renommerDossier(l, dossierPour(nom, l));
      intervChange(); return { ok: true };
    }
    case 'liste-supprimer': {
      const i = INTERV.listes.findIndex(x => x.id === op.liste); if (i < 0) return plusLa;
      if (INTERV.listes.length === 1) return { ok: false, raison: 'Il faut garder au moins une liste.' };
      const [l] = INTERV.listes.splice(i, 1);
      if (INTERV.courant && l.liste.some(x => x.id === INTERV.courant)) INTERV.courant = null;
      if (INTERV.ouverte === l.id) INTERV.ouverte = INTERV.listes[Math.min(i, INTERV.listes.length - 1)].id;
      intervChange(); return { ok: true };
    }
    case 'liste-deplacer': {   // liste placée juste avant « avant » (null : à la fin)
      const i = INTERV.listes.findIndex(x => x.id === op.liste); if (i < 0) return plusLa;
      const [l] = INTERV.listes.splice(i, 1);
      let j = op.avant ? INTERV.listes.findIndex(x => x.id === op.avant) : -1; if (j < 0) j = INTERV.listes.length;
      INTERV.listes.splice(j, 0, l); intervChange(); return { ok: true };
    }
    case 'ouvrir': {   // liste montrée sur cet ordinateur (pas depuis un autre ordinateur)
      if (distant) return { ok: false, raison: 'La liste ouverte se choisit sur l’ordinateur lui-même.' };
      const l = INTERV.listes.find(x => x.id === op.liste); if (!l) return plusLa;
      if (INTERV.ouverte !== l.id) { INTERV.ouverte = l.id; intervChange(); }
      return { ok: true };
    }
    // ---- les intervenants d'une liste ----
    case 'ajouter': {
      const l = listeDe(op); if (!l) return plusLa;
      const L = l.liste, fichiers = (Array.isArray(op.fichiers) ? op.fichiers : [op.fichier]).slice(0, 500);
      let n = 0, deja = 0;
      for (const f of fichiers) {
        if (typeof f !== 'string' || !PPT_RE.test(f) || !relValide(f) || !relValide(f).length || !absDansBanque(f)) continue;
        if (L.some(x => x.fichier === f)) { deja++; continue; }
        L.push({ id: crypto.randomUUID(), nom: nomDe(f), fichier: f, fait: false, par: String(par || '').slice(0, 60) }); n++;
      }
      if (n) intervChange();
      return { ok: true, n, deja, liste: l.id, listeNom: l.nom };
    }
    case 'retirer': {
      const t = trouverItem(op.id); if (!t) return { ok: false, raison: 'Déjà retiré de la liste.' };
      t.l.liste.splice(t.i, 1); if (INTERV.courant === op.id) INTERV.courant = null; intervChange(); return { ok: true };
    }
    case 'deplacer': {   // id placé juste avant « avant » (null : à la fin), dans sa liste
      const t = trouverItem(op.id); if (!t) return { ok: false, raison: 'Introuvable.' };
      const L = t.l.liste; L.splice(t.i, 1);
      let j = op.avant ? L.findIndex(y => y.id === op.avant) : -1; if (j < 0) j = L.length;
      L.splice(j, 0, t.x); intervChange(); return { ok: true };
    }
    case 'renommer': { const t = trouverItem(op.id); if (!t) return { ok: false, raison: 'Introuvable.' }; t.x.nom = String(op.nom || '').trim().slice(0, 120) || nomDe(t.x.fichier); intervChange(); return { ok: true }; }
    case 'fait': { const t = trouverItem(op.id); if (!t) return { ok: false, raison: 'Introuvable.' }; t.x.fait = !!op.fait; intervChange(); return { ok: true }; }
    case 'remettre': { const l = listeDe(op); if (!l) return plusLa; for (const x of l.liste) x.fait = false; if (l.liste.some(x => x.id === INTERV.courant)) INTERV.courant = null; intervChange(); return { ok: true }; }
    case 'vider': { const l = listeDe(op); if (!l) return plusLa; if (l.liste.some(x => x.id === INTERV.courant)) INTERV.courant = null; l.liste.length = 0; intervChange(); return { ok: true }; }
  }
  return { ok: false, raison: 'Demande inconnue.' };
}
// PPT reçu d'un autre ordinateur « pour les intervenants » : ajouté à sa liste (liste disparue entre-temps : la liste ouverte)
function ajouterRecuInterv(abs, par, liste) {
  if (!abs || !PPT_RE.test(abs)) return;
  const rel = relDe(abs); if (!rel) return;
  opInterv({ op: 'ajouter', fichier: rel, liste: INTERV.listes.some(l => l.id === liste) ? liste : undefined }, par);
}

/* ---------- Lanterne PPT (même ordinateur) : ouvrir un diaporama, revenir ici à la fin ----------
   Port de contrôle de Lanterne PPT (TCP 7602, 127.0.0.1, sans code en local). Lanterne PPT fermé : il est lancé avec le fichier.
   {"cmd":"ppt_banque","path":…,"id":…} → Lanterne PPT ouvre le fichier (s'il ne l'a pas déjà) en « mode banque » ;
   à la fin il envoie {"type":"ppt_banque_fin","id":…}. */
const PPT_PORT = +process.env.BANQUE_PPT_PORT || 7602;
const PPT_VERSION_MIN = [1, 5, 0];
let pptSock = null, pptVersion = '', pptSession = null;   // pptSession : { id, abs, depuis } diaporama ouvert depuis Banque
function trouverPpt() {
  if (isMac) {
    const h = app.getPath('home');
    for (const r of ['/Applications/Lanterne Spectacle', path.join(h, 'Applications', 'Lanterne Spectacle'), '/Applications', path.join(h, 'Applications')]) { const p = path.join(r, 'Lanterne PPT.app'); if (fs.existsSync(p)) return p; }
    return null;
  }
  if (isWin) { for (const r of [path.join(process.env.LOCALAPPDATA || '', 'Programs', 'Lanterne Spectacle')]) { const p = path.join(r, 'Lanterne PPT', 'Lanterne PPT.exe'); if (fs.existsSync(p)) return p; } return null; }
  return null;
}
function lancerPpt(abs) {
  return new Promise((resolve) => {
    if (process.env.BANQUE_PPT_LANCER) { try { spawn(process.env.BANQUE_PPT_LANCER, [abs], { detached: true, stdio: 'ignore' }).unref(); resolve(true); } catch (e) { resolve(false); } return; }
    const p = trouverPpt();
    if (!p) return resolve(false);
    // le fichier passé au lancement : Lanterne PPT l'ouvre au lieu de rouvrir sa dernière sauvegarde
    if (isMac) execFile('open', ['-a', p, '--args', abs], (err) => resolve(!err));
    else { try { spawn(p, [abs], { detached: true, stdio: 'ignore', cwd: path.dirname(p) }).unref(); resolve(true); } catch (e) { resolve(false); } }
  });
}
const versionOk = (v) => { const a = String(v || '0').split('.').map(n => +n || 0); for (let i = 0; i < 3; i++) { if ((a[i] || 0) !== PPT_VERSION_MIN[i]) return (a[i] || 0) > PPT_VERSION_MIN[i]; } return true; };
// lien avec Lanterne PPT ; vrai quand son bonjour est arrivé
function connecterPpt(attenteMs) {
  if (pptSock) return Promise.resolve(true);
  return new Promise((resolve) => {
    const fin = Date.now() + attenteMs;
    const essai = () => {
      const s = net.connect({ host: '127.0.0.1', port: PPT_PORT });
      let buf = '', ok = false;
      const t = setTimeout(() => s.destroy(), 3000);
      s.setEncoding('utf8'); s.setNoDelay(true);
      s.on('data', (d) => {
        buf += d; if (buf.length > 8e6) buf = '';
        let i;
        while ((i = buf.indexOf('\n')) >= 0) {
          const line = buf.slice(0, i); buf = buf.slice(i + 1);
          if (!line || line[0] !== '{') continue;
          let m; try { m = JSON.parse(line); } catch (e) { continue; }
          if (!ok) {
            if (m.type === 'hello' && /PPT/.test(String(m.app || ''))) {
              ok = true; clearTimeout(t); pptSock = s; pptVersion = String(m.version || '');
              try { s.write(JSON.stringify({ cmd: 'hello', app: 'Banque' }) + '\n'); } catch (e) {}
              resolve(true);
            }
          } else if (m.type === 'ppt_banque_fin') finPpt(m);
        }
      });
      s.on('error', () => {});
      s.on('close', () => {
        clearTimeout(t);
        if (pptSock === s) { pptSock = null; if (pptSession) setTimeout(() => { if (pptSession && !pptSock) connecterPpt(60000); }, 2000); }   // Lanterne PPT relancé : on se relie de nouveau
        if (!ok) { if (Date.now() < fin) setTimeout(essai, 700); else resolve(false); }
      });
    };
    essai();
  });
}
function devant() {
  montrer();
  if (!win) return;
  try { if (isMac) app.focus({ steal: true }); else { win.setAlwaysOnTop(true); win.focus(); setTimeout(() => { try { win.setAlwaysOnTop(false); } catch (e) {} }, 400); } } catch (e) {}
}
function finPpt(m) {
  const s = pptSession; pptSession = null;
  const id = String((m && m.id) || (s && s.id) || '');
  const t = id && trouverItem(id), x = t && t.x;
  if (x) x.fait = true;
  if (x || INTERV.courant) { INTERV.courant = null; intervChange(); }
  devant();
  toPage('ppt-fin', { id, depuis: s ? s.depuis : (x ? 'interv' : '') });
}
async function ouvrirDansPpt(abs, { id = '', depuis = 'mabanque', nom = '' } = {}) {
  try { if (!abs || !fs.statSync(abs).isFile()) throw new Error(); } catch (e) { return { ok: false, erreur: 'Ce fichier n’est plus dans la banque.' }; }
  let ok = await connecterPpt(1000);
  if (!ok) {
    if (!(await lancerPpt(abs))) return { ok: false, erreur: (trouverPpt() || process.env.BANQUE_PPT_LANCER) ? 'Lanterne PPT ne s’est pas ouvert.' : 'Lanterne PPT n’est pas installé sur cet ordinateur (suite Lanterne Spectacle 2.28.0 ou plus récente).' };
    ok = await connecterPpt(45000);
    if (!ok) return { ok: false, erreur: 'Lanterne PPT s’est ouvert mais ne répond pas (port 7602).' };
  }
  if (!versionOk(pptVersion)) return { ok: false, erreur: `Lanterne PPT ${pptVersion} est trop ancien : installe la suite Lanterne Spectacle 2.28.0 ou plus récente.` };
  pptSession = { id, abs, depuis };
  try { pptSock.write(JSON.stringify({ cmd: 'ppt_banque', path: abs, id, nom }) + '\n'); } catch (e) { pptSession = null; return { ok: false, erreur: 'Liaison avec Lanterne PPT coupée.' }; }
  if (id) { INTERV.courant = id; intervChange(); }
  return { ok: true };
}

/* ---------- accès local pour les logiciels Lanterne (Lanterne PPT, Player, Son du même ordinateur) ----------
   Seulement depuis 127.0.0.1, avec le jeton de <userData>/local.json. Leur panneau « Depuis Banque » parcourt ma banque
   lui-même (dossier lu dans prefs.json) et passe par ici pour les banques principales du réseau et les récupérations. */
const estLocal = (req) => ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress);
async function serveurLocal(req, res, u) {
  if (!estLocal(req) || req.headers['x-banque-local'] !== JETON_LOCAL) return repondre(res, 403, { erreur: 'Interdit' });
  const q = (k) => u.searchParams.get(k) || '';
  try {
    if (u.pathname === '/v1/local/etat') {
      return repondre(res, 200, { nom: prefs.nom, dossier: racine(), version: app.getVersion(),
        sources: [...PAIRS.values()].filter(p => p.principale).map(resumePair).map(p => ({ id: p.id, nom: p.nom, adresse: p.adresse, perdu: p.perdu })) });
    }
    if (u.pathname === '/v1/local/liste') {
      const chemin = q('chemin');
      const r = await SOURCES.reseau.liste(q('id'), chemin);
      const base = absDansBanque(chemin);
      const entrees = [];
      for (const e of r.entrees || []) {
        let chez = false, local = null;
        if (base) { try { const p = path.join(base, e.nom), st = await fsp.stat(p); chez = e.dossier ? st.isDirectory() : (st.isFile() && st.size === e.taille); if (chez && !e.dossier) local = p; } catch (er) {} }
        entrees.push(Object.assign({}, e, { chez, local }));
      }
      return repondre(res, 200, { chemin, entrees });
    }
    if (u.pathname === '/v1/local/recuperer' && req.method === 'POST') {
      const d = await lireCorpsJSON(req, 1e6);
      const chemins = (Array.isArray(d.chemins) ? d.chemins : []).filter(c => typeof c === 'string' && relValide(c) && relValide(c).length).slice(0, 5000);
      if (!chemins.length) return repondre(res, 400, { erreur: 'Rien à récupérer.' });
      pair(String(d.id || ''));
      let tid = 0;
      recuperer(String(d.id), chemins, (t) => { tid = t; }).catch(e => fiab.log('recuperer', e && e.message));
      return repondre(res, 200, { tid });
    }
    if (u.pathname === '/v1/local/transfert') {
      const t = TRANSFERTS.get(+q('tid'));
      if (!t) return repondre(res, 404, { erreur: 'Récupération inconnue.' });
      return repondre(res, 200, Object.assign(resumeT(t), t.etat === 'fini' ? { destinations: t.destinations || {} } : {}));
    }
    if (u.pathname === '/v1/local/annuler' && req.method === 'POST') { const t = TRANSFERTS.get(+q('tid')); if (t && t.annuler) t.annuler(); return repondre(res, 200, { ok: true }); }
    if (u.pathname === '/v1/local/montrer' && req.method === 'POST') { devant(); return repondre(res, 200, { ok: true }); }
    return repondre(res, 404, { erreur: 'Inconnu' });
  } catch (e) {
    return repondre(res, 500, { erreur: e && e.message || 'Erreur dans Banque.' });
  }
}

/* ---------- échanges avec la page ---------- */
ipcMain.handle('etat', () => ({ interv: vueInterv(), prefs, pairs: [...PAIRS.values()].map(resumePair), transferts: [...TRANSFERTS.values()].map(resumeT), port: portTcp, plateforme: process.platform, version: app.getVersion(),
  adresses: [...locales()].filter(a => a !== '127.0.0.1'), demandes: [...DEMANDES].map(([rid, d]) => Object.assign({ rid }, d.info)) }));
ipcMain.handle('source-liste', (_e, sorte, id, chemin) => SOURCES[sorte].liste(id, chemin));
ipcMain.handle('source-recuperer', (_e, sorte, id, chemins) => SOURCES[sorte].recuperer(id, chemins));
ipcMain.handle('source-deposer', (_e, sorte, id, dossier, absListe) => SOURCES[sorte].deposer(id, dossier, absListe));
ipcMain.handle('envoyer', (_e, id, absListe) => { envoyer(id, absListe); return true; });
ipcMain.handle('annuler', (_e, tid) => { const t = TRANSFERTS.get(tid); if (t && t.annuler) t.annuler(); else if (t) majTransfert(tid, { etat: 'annule' }); return true; });
ipcMain.handle('effacer-termines', () => { for (const [k, t] of TRANSFERTS) if (['fini', 'erreur', 'annule', 'refuse'].includes(t.etat)) TRANSFERTS.delete(k); publierTransferts(); return true; });
ipcMain.handle('tailles', async (_e, absListe) => {
  const out = [];
  for (const a of absListe) { try { const st = await fsp.stat(a); out.push(st.isDirectory() ? Object.assign({ abs: a, nom: path.basename(a), dossier: true }, await tailleDossier(a)) : { abs: a, nom: path.basename(a), dossier: false, n: 1, taille: st.size }); } catch (e) {} }
  return out;
});
// ma banque
ipcMain.handle('ma-liste', async (_e, chemin) => {
  assurerBanque();
  const abs = absDansBanque(chemin || '');
  if (!abs) return { entrees: [], erreur: 'Chemin refusé' };
  const l = await lister(abs);
  return l ? { entrees: l } : { entrees: [], erreur: 'Dossier introuvable' };
});
ipcMain.handle('ma-presence', async (_e, chemin, entrees) => {
  // pour la banque principale affichée : quels fichiers sont déjà chez moi (même taille)
  const abs = absDansBanque(chemin || '');
  const out = {};
  if (!abs) return out;
  for (const en of entrees || []) {
    try { const st = await fsp.stat(path.join(abs, en.nom)); out[en.nom] = en.dossier ? st.isDirectory() : (st.isFile() && st.size === en.taille); } catch (e) { out[en.nom] = false; }
  }
  return out;
});
ipcMain.handle('ajouter', (_e, dossier, absListe) => ajouterFichiers(dossier, absListe));
// copie des fichiers ou dossiers de cet ordinateur dans ma banque ; rels : où chaque fichier se trouve dans la banque
async function ajouterFichiers(dossier, absListe) {
  const base = absDansBanque(dossier || '', { ecriture: true });
  if (!base || !assurerBanque()) return { ok: false, erreur: 'Banque inaccessible' };
  let n = 0;
  const rels = [];
  for (const a of absListe) {
    try {
      const st = await fsp.stat(a);
      const fichiers = st.isDirectory() ? await arbre(a, path.basename(a), []) : [{ chemin: path.basename(a), taille: st.size, date: st.mtimeMs, abs: a }];
      for (const f of fichiers) {
        let dest = path.join(base, ...f.chemin.split('/').map(nettoyerNom));
        if (path.resolve(dest) === path.resolve(f.abs)) { rels.push(relDe(dest)); continue; }
        await fsp.mkdir(path.dirname(dest), { recursive: true });
        const voulu = dest;
        dest = await destination(dest, f.taille, f.date);
        if (!dest) { rels.push(relDe(voulu)); continue; }
        await fsp.copyFile(f.abs, dest); n++;
        try { const d = new Date(f.date); await fsp.utimes(dest, d, d); } catch (e) {}
        rels.push(relDe(dest));
      }
    } catch (e) { fiab.log('ajouter', e && e.message); }
  }
  return { ok: true, n, rels: rels.filter(Boolean) };
}
ipcMain.handle('nouveau-dossier', async (_e, dossier, nom) => {
  const abs = absDansBanque(`${dossier ? dossier + '/' : ''}${nettoyerNom(nom || '')}`, { ecriture: true });
  if (!abs || !nom) return false;
  await fsp.mkdir(abs, { recursive: true }); return true;
});
ipcMain.handle('corbeille', async (_e, chemins) => {
  for (const c of chemins) { const abs = absDansBanque(c); if (abs && abs !== path.resolve(racine())) { try { await shell.trashItem(abs); } catch (e) { fiab.log('corbeille', e && e.message); } } }
  return true;
});
ipcMain.handle('ouvrir', (_e, chemin, montrerSeul) => {
  assurerBanque();
  const abs = absDansBanque(chemin || '');
  if (!abs) return false;
  if (montrerSeul) shell.showItemInFolder(abs); else shell.openPath(abs);
  return true;
});
// écran Intervenants (cet ordinateur)
ipcMain.handle('interv', () => vueInterv());
ipcMain.handle('interv-op', (_e, op) => Object.assign(opInterv(op, ''), { vue: vueInterv() }));
ipcMain.handle('interv-lancer', (_e, id) => {
  const t = trouverItem(id), x = t && t.x;
  if (!x) return { ok: false, erreur: 'Cet intervenant n’est plus dans la liste.' };
  return ouvrirDansPpt(absDansBanque(x.fichier), { id: x.id, depuis: 'interv', nom: x.nom });
});
ipcMain.handle('interv-importer', async (_e, absListe, liste) => {
  // PPT pris ailleurs sur cet ordinateur : copiés dans ma banque › Intervenants › <liste>, puis ajoutés à la liste
  const l = (absListe || []).filter(a => PPT_RE.test(a));
  if (!l.length) return { ok: false, erreur: 'Choisis des fichiers PowerPoint (.pptx).' };
  const lv = listeDe({ liste }); if (!lv) return { ok: false, erreur: 'Cette liste n’existe plus.' };
  const r = await ajouterFichiers(lv.dossier, l);
  if (!r.ok) return r;
  return Object.assign(opInterv({ op: 'ajouter', fichiers: r.rels, liste: lv.id }, ''), { copies: r.n, dossier: lv.dossier });
});
ipcMain.handle('ppt-ouvrir', (_e, chemin) => ouvrirDansPpt(absDansBanque(chemin || ''), { depuis: 'mabanque' }));
// écran Intervenants d'un autre ordinateur (préparé d'ici)
async function intervDistant(id, methode, op) {
  const p = pair(id);
  const corps = op ? Buffer.from(JSON.stringify(op)) : null;
  const res = await requete(p, methode, '/v1/intervenants', corps ? { corps, entetes: { 'Content-Type': 'application/json', 'Content-Length': corps.length } } : {});
  const b = await lireTout(res);
  let j = {}; try { j = JSON.parse(b.toString('utf8')); } catch (e) { throw new Error('Réponse illisible de l’autre ordinateur.'); }
  if (res.statusCode === 404) return { ancien: true };   // Banque 1.0 de l'autre côté
  if (res.statusCode === 403) return { accord: true, erreur: j.erreur };
  if (res.statusCode >= 400) throw new Error(j.erreur || `Erreur ${res.statusCode}`);
  return j;
}
ipcMain.handle('interv-distant', (_e, id) => intervDistant(id, 'GET'));
ipcMain.handle('interv-distant-op', (_e, id, op) => intervDistant(id, 'POST', op));
ipcMain.handle('interv-distant-acces', (_e, id) => postJSON(pair(id), '/v1/intervenants/acces', {}, 130000));
ipcMain.handle('interv-distant-envoyer', (_e, id, absListe, liste, listeNom) => {
  const l = (absListe || []).filter(a => PPT_RE.test(a));
  if (!l.length) return { ok: false, erreur: 'Choisis des fichiers PowerPoint (.pptx).' };
  envoyer(id, l, { intervenants: true, listeId: typeof liste === 'string' ? liste : '', listeNom: typeof listeNom === 'string' ? listeNom.slice(0, 80) : '' }); return { ok: true, n: l.length };
});
ipcMain.handle('abs', (_e, chemin) => absDansBanque(chemin || ''));
ipcMain.handle('plein-ecran', () => { if (win) win.setFullScreen(!win.isFullScreen()); return win ? win.isFullScreen() : false; });
ipcMain.handle('choisir', async (_e, sorte) => {
  const r = await dialog.showOpenDialog(win, { title: sorte === 'dossier' ? 'Choisir des dossiers' : sorte === 'ppt' ? 'Choisir des diaporamas PowerPoint' : 'Choisir des fichiers', properties: sorte === 'dossier' ? ['openDirectory', 'multiSelections'] : ['openFile', 'multiSelections'],
    filters: sorte === 'ppt' ? [{ name: 'PowerPoint', extensions: ['pptx', 'ppsx', 'pptm', 'ppsm'] }] : undefined });
  return r.canceled ? [] : r.filePaths;
});
ipcMain.handle('choisir-banque', async () => {
  const r = await dialog.showOpenDialog(win, { title: 'Dossier de la banque', defaultPath: racine(), properties: ['openDirectory', 'createDirectory'] });
  if (r.canceled || !r.filePaths[0]) return prefs;
  prefs.dossier = r.filePaths[0]; savePrefs(); ecrireLocal(); toPage('banque-change'); toPage('intervenants', vueInterv());
  return prefs;
});
ipcMain.handle('set-pref', (_e, k, v) => {
  if (k === 'nom' && typeof v === 'string' && v.trim()) prefs.nom = v.trim().slice(0, 40);
  if (k === 'principale') prefs.principale = !!v;
  if (k === 'depot') prefs.depot = !!v;
  if (k === 'visible') prefs.visible = !!v;
  if (k === 'conflit' && ['deux', 'remplacer', 'passer'].includes(v)) prefs.conflit = v;
  if (k === 'majAuto') prefs.majAuto = !!v;
  if (k === 'oublier-confiance') prefs.confiance = prefs.confiance.filter(c => c.id !== v);
  if (k === 'manuel-ajouter' && typeof v === 'string' && /^[\w.-]+(:\d+)?$/.test(v.trim()) && !prefs.manuels.includes(v.trim())) { prefs.manuels.push(v.trim()); sonderManuels(); }
  if (k === 'manuel-retirer') prefs.manuels = prefs.manuels.filter(x => x !== v);
  savePrefs(); annoncer(); buildMenu(); toPage('prefs'); if (k === 'nom') ecrireLocal();
  return prefs;
});

/* ---------- mises à jour (GitHub) ----------
   Au lancement (puis toutes les 6 h), Banque lit derniere.json dans la branche « banque-mises-a-jour » du dépôt GitHub
   des mises à jour de Lanterne Spectacle (le même que Lanterne Launcher) : version, notes, fichier .banquemaj et zips complets.
   Plus récente que cette Banque : le fichier est téléchargé et vérifié (signature Ed25519 avec la clé de Lanterne Spectacle,
   empreinte de chaque fichier), puis un bandeau la propose. « Mettre à jour » : copie du code actuel (Réglages › Revenir à la
   version d'avant), écriture du nouveau code dans Banque installé (Mac : Banque.app/Contents/Resources/app, Info.plist mis à
   la nouvelle version et app resignée sur place ; Windows : %LOCALAPPDATA%\Programs\Banque\resources\app), puis Banque
   redémarre. Un autre moteur (Electron) ou une Banque lancée depuis ses sources : le bandeau propose le zip complet.
   Fichier fait par sources/outils/maj-banque.js, publié par sources/outils/publier-banque.py. Internet : seulement ici. */
const zlib = require('zlib');
const { net: enet } = require('electron');
const MAJ_CLE = 'MCowBQYDK2VwAyEAcBOKSZdO54+MqE8ytkJMn7t+ipcTpkU4Q+h1pnjiuT4=';
const MAJ_DEPOT = 'chloelucilesalignon906-sketch/lanterne-spectacle';
const MAJ_BRANCHE = 'banque-mises-a-jour';
const majRaw = () => process.env.BANQUE_MAJ_RAW || 'https://raw.githubusercontent.com';   // essais : serveur local
const majBase = () => `${majRaw()}/${process.env.BANQUE_MAJ_DEPOT || MAJ_DEPOT}/${MAJ_BRANCHE}`;
const majPage = () => `https://github.com/${process.env.BANQUE_MAJ_DEPOT || MAJ_DEPOT}/tree/${MAJ_BRANCHE}`;
const cmpVer = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d > 0 ? 1 : -1; } return 0; };
const shaHex = (b) => crypto.createHash('sha256').update(b).digest('hex');
const majSauveDir = () => path.join(app.getPath('userData'), 'maj-sauvegarde');
const majEnLigneDir = () => path.join(app.getPath('userData'), 'maj-en-ligne');
// dossier du code de Banque installé (là où la mise à jour écrit) ; null quand Banque tourne depuis ses sources
function codeDir() {
  const p = app.getAppPath();
  return /[\\/](Contents[\\/]Resources|resources)[\\/]app$/.test(p) ? p : null;
}
const relSur = (r) => typeof r === 'string' && r.length < 300 && !r.startsWith('/') && !/^[A-Za-z]:/.test(r) && !r.split(/[\\/]/).some(x => x === '..' || x === '.' || x === '');
// lit et vérifie un fichier .banquemaj : { p } ou { erreur }
function lireMaj(file) {
  let d;
  try { if (fs.statSync(file).size > 50e6) return { erreur: 'Fichier trop gros pour une mise à jour de Banque.' }; d = JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch (e) { return { erreur: 'Fichier de mise à jour illisible.' }; }
  if (!d || d.type !== 'banque-maj' || typeof d.payload !== 'string' || typeof d.sig !== 'string') return { erreur: 'Ce fichier n’est pas une mise à jour de Banque.' };
  let ok = false;
  try { ok = crypto.verify(null, Buffer.from(d.payload, 'utf8'), crypto.createPublicKey({ key: Buffer.from(MAJ_CLE, 'base64'), format: 'der', type: 'spki' }), Buffer.from(d.sig, 'base64')); } catch (e) {}
  if (!ok) return { erreur: 'Signature refusée : ce fichier n’a pas été fait pour Banque, ou il a été modifié. Rien n’est installé.' };
  let q; try { q = JSON.parse(d.payload); } catch (e) { return { erreur: 'Mise à jour abîmée.' }; }
  if (!q || q.type !== 'banque-maj' || !/^\d+\.\d+\.\d+$/.test(String(q.version || '')) || !q.files || typeof q.files !== 'object' || !q.files['package.json'] || !q.files['main.js']) return { erreur: 'Mise à jour abîmée.' };
  for (const [r, f] of Object.entries(q.files)) if (!relSur(r) || !f || typeof f.gz !== 'string' || !/^[0-9a-f]{64}$/.test(String(f.h))) return { erreur: 'Mise à jour abîmée (fichier refusé).' };
  return { p: q };
}
// une mise à jour faite pour un autre moteur (numéro principal d'Electron) demande le zip complet
const moteurOk = (q) => !q.moteur || String(process.versions.electron || '').split('.')[0] === String(q.moteur).split('.')[0];
const zipDeCetOrdi = (n) => /\.zip$/i.test(n) && (isWin ? /-Windows-/i.test(n) : (isMac && process.arch === 'x64') ? /-Mac-Intel-/i.test(n) : /-Mac-\d/i.test(n));
async function majFetch(url, accept) {
  const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 60000);
  try { return await enet.fetch(url, { headers: { Accept: accept, 'User-Agent': `Banque/${app.getVersion()}` }, cache: 'no-store', signal: ctl.signal }); }
  finally { clearTimeout(t); }
}
let MAJ = { etat: 'rien' }, majCours = null, majEnCours = false;
async function majChercher() {
  let r;
  try { r = await majFetch(`${majBase()}/derniere.json?t=${Date.now()}`, 'application/json'); } catch (e) { return { etat: 'erreur', erreur: 'Pas de connexion à Internet (ou GitHub ne répond pas).', horsLigne: true }; }
  if (r.status === 404) return { etat: 'erreur', erreur: 'Aucune version de Banque publiée pour l’instant.' };
  if (!r.ok) return { etat: 'erreur', erreur: `GitHub répond ${r.status}.` };
  let j; try { j = await r.json(); } catch (e) { return { etat: 'erreur', erreur: 'Réponse de GitHub illisible.' }; }
  const version = /^\d+\.\d+\.\d+$/.test(String(j && j.version || '')) ? String(j.version) : '';
  if (!version) return { etat: 'erreur', erreur: 'Annonce de mise à jour illisible.' };
  const res = { version, date: String(j.date || ''), notes: (Array.isArray(j.notes) ? j.notes : []).map(String).filter(Boolean).slice(0, 20) };
  const z = (Array.isArray(j.zips) ? j.zips : []).find(n => typeof n === 'string' && /^[\w.-]+\.zip$/i.test(n) && zipDeCetOrdi(n));
  if (z) res.zip = `${majBase()}/${encodeURIComponent(z)}`;
  if (cmpVer(version, app.getVersion()) <= 0) return Object.assign(res, { etat: 'ajour' });
  res.etat = 'dispo';
  const f = typeof j.maj === 'string' && /^[\w.-]+\.banquemaj$/i.test(j.maj) ? j.maj : '';
  if (!f) return Object.assign(res, { leger: false, pourquoi: 'Cette version s’installe avec le zip complet.' });
  if (!codeDir()) return Object.assign(res, { leger: false, pourquoi: 'Banque tourne depuis ses sources : installe le zip complet.' });
  const file = path.join(majEnLigneDir(), f);
  try {
    let deja = false; try { const m = lireMaj(file); deja = !m.erreur && m.p.version === version; } catch (e) {}
    if (!deja) {
      const g = await majFetch(`${majBase()}/${encodeURIComponent(f)}`, 'application/octet-stream');
      if (!g.ok) throw new Error(`GitHub répond ${g.status}`);
      const buf = Buffer.from(await g.arrayBuffer());
      if (buf.length > 50e6) throw new Error('fichier trop gros');
      await fsp.mkdir(majEnLigneDir(), { recursive: true });
      fiab.ecrire(file, buf);
      try { for (const n of fs.readdirSync(majEnLigneDir())) if (n !== f && !n.startsWith('.')) fs.rmSync(path.join(majEnLigneDir(), n), { force: true }); } catch (e) {}
    }
  } catch (e) { return Object.assign(res, { leger: false, pourquoi: `La mise à jour n’a pas pu être téléchargée (${e.message || e}).` }); }
  const m = lireMaj(file);
  if (m.erreur) { try { fs.rmSync(file, { force: true }); } catch (e) {} return Object.assign(res, { leger: false, pourquoi: m.erreur }); }
  if (m.p.version !== version) return Object.assign(res, { leger: false, pourquoi: `Le fichier en ligne est la version ${m.p.version}, pas ${version}.` });
  if (!moteurOk(m.p)) return Object.assign(res, { leger: false, pourquoi: `Cette version demande un nouveau moteur (Electron ${m.p.moteur}) : installe le zip complet.` });
  return Object.assign(res, { leger: true, fichier: file });
}
function majRetourInfo() {
  try {
    const d = JSON.parse(fs.readFileSync(path.join(majSauveDir(), 'derniere.json'), 'utf8'));
    return d && d.dir && d.to === app.getVersion() && fs.existsSync(path.join(d.dir, 'sauvegarde.json')) ? { from: d.from, to: d.to, dir: d.dir } : null;
  } catch (e) { return null; }
}
function vueMaj() {
  const r = majRetourInfo();
  return { etat: MAJ.etat, version: MAJ.version || '', date: MAJ.date || '', notes: MAJ.notes || [], leger: !!MAJ.leger, pourquoi: MAJ.pourquoi || '', erreur: MAJ.erreur || '',
    zip: !!MAJ.zip, installee: app.getVersion(), installable: !!codeDir(), auto: prefs.majAuto !== false, at: MAJ.at || 0, retour: r ? r.from : '', enCours: majEnCours };
}
function majVerifier(force) {
  if (majCours) return majCours;
  if (!force && MAJ.at && Date.now() - MAJ.at < 6 * 3600e3 && MAJ.etat !== 'erreur') return Promise.resolve(vueMaj());
  MAJ = Object.assign({}, MAJ, { etat: 'cherche' }); toPage('maj', vueMaj());
  majCours = majChercher().catch(e => ({ etat: 'erreur', erreur: String(e && e.message || e) })).then(r => {
    majCours = null; MAJ = Object.assign({ at: Date.now() }, r);
    if (r.etat === 'erreur' && !r.horsLigne) fiab.log('mise à jour', r.erreur);
    toPage('maj', vueMaj()); return vueMaj();
  });
  return majCours;
}
async function ecrireSur(dst, buf) {
  await fsp.mkdir(path.dirname(dst), { recursive: true });
  const tmp = `${dst}.maj-tmp`;
  await fsp.writeFile(tmp, buf);
  await fsp.rename(tmp, dst);
}
async function remettre(dir, bdir, info) {
  for (const rel of info.added || []) { try { await fsp.rm(path.join(dir, rel), { force: true }); } catch (e) {} }
  for (const rel of info.saved || []) { try { await ecrireSur(path.join(dir, rel), await fsp.readFile(path.join(bdir, rel))); } catch (e) {} }
}
// après l'écriture : Mac, numéro de version de l'app puis signature locale sur place ; Windows, version affichée dans Paramètres
function apresEcriture(dir, version) {
  return new Promise((res) => {
    const fin = (err) => { if (err) fiab.log('mise à jour', String(err.message || err)); res(); };
    if (isMac) {
      const b = dir.split('/Contents/Resources/app')[0], pl = path.join(b, 'Contents', 'Info.plist');
      if (!b.endsWith('.app') || !fs.existsSync(pl)) return res();
      execFile('plutil', ['-replace', 'CFBundleShortVersionString', '-string', version, pl], () =>
        execFile('plutil', ['-replace', 'CFBundleVersion', '-string', version, pl], () =>
          execFile('xattr', ['-cr', b], () => execFile('codesign', ['--force', '--deep', '--sign', '-', b], { timeout: 120000 }, fin))));
    } else if (isWin) execFile('reg', ['add', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Banque', '/v', 'DisplayVersion', '/d', version, '/f'], { windowsHide: true }, () => res());
    else res();
  });
}
// Banque redémarre sur sa nouvelle version (essais : BANQUE_MAJ_SANS_RELANCE, elle se ferme seulement)
function redemarrer() {
  setTimeout(() => {
    annoncerDepart(); effacerLocal();
    if (!process.env.BANQUE_MAJ_SANS_RELANCE) app.relaunch();
    app.exit(0);
  }, 1500);
}
async function majInstaller() {
  if (majEnCours) return { ok: false, erreur: 'Une mise à jour est déjà en cours.' };
  if (MAJ.etat !== 'dispo' || !MAJ.leger || !MAJ.fichier) return { ok: false, erreur: 'Aucune mise à jour prête à installer.' };
  if (pptSession || INTERV.courant) return { ok: false, erreur: 'Un diaporama lancé depuis Banque est en cours : mets à jour après.' };
  const dir = codeDir(); if (!dir) return { ok: false, erreur: 'Banque tourne depuis ses sources : installe le zip complet.' };
  const m = lireMaj(MAJ.fichier); if (m.erreur) return { ok: false, erreur: m.erreur };
  const q = m.p;
  if (!moteurOk(q)) return { ok: false, erreur: `Cette version demande un nouveau moteur (Electron ${q.moteur}) : installe le zip complet.` };
  majEnCours = true; toPage('maj', vueMaj());
  const from = app.getVersion(), bdir = path.join(majSauveDir(), `${from}-${new Date().toISOString().replace(/[:.]/g, '-')}`);
  const bufs = {};
  try {
    for (const [rel, f] of Object.entries(q.files)) { const b = zlib.gunzipSync(Buffer.from(f.gz, 'base64')); if (shaHex(b) !== f.h) throw new Error(`empreinte fausse : ${rel}`); bufs[rel] = b; }
  } catch (e) { majEnCours = false; toPage('maj', vueMaj()); return { ok: false, erreur: `Mise à jour abîmée (${e.message}). Rien n’est changé.` }; }
  const info = { from, to: q.version, at: Date.now(), dir, saved: [], added: [] };
  try {
    for (const rel of Object.keys(bufs)) {
      const src = path.join(dir, rel);
      if (fs.existsSync(src)) { await fsp.mkdir(path.dirname(path.join(bdir, rel)), { recursive: true }); await fsp.copyFile(src, path.join(bdir, rel)); info.saved.push(rel); }
      else info.added.push(rel);
    }
    await fsp.mkdir(bdir, { recursive: true });
    await fsp.writeFile(path.join(bdir, 'sauvegarde.json'), JSON.stringify(info));
  } catch (e) { majEnCours = false; toPage('maj', vueMaj()); return { ok: false, erreur: `Copie de la version actuelle impossible (${e.code || e.message}). Rien n’est changé.` }; }
  try {
    for (const [rel, b] of Object.entries(bufs)) await ecrireSur(path.join(dir, rel), b);
    for (const [rel, f] of Object.entries(q.files)) if (shaHex(await fsp.readFile(path.join(dir, rel))) !== f.h) throw new Error(`vérification de ${rel}`);
  } catch (e) {
    await remettre(dir, bdir, info); majEnCours = false; toPage('maj', vueMaj());
    const droit = e && (e.code === 'EACCES' || e.code === 'EPERM');
    return { ok: false, erreur: droit ? `Pas le droit d’écrire dans ${dir} : installe le zip complet. Banque reste en ${from}.` : `Mise à jour impossible (${e.message || e}). Banque reste en ${from}.` };
  }
  await apresEcriture(dir, q.version);
  try { fiab.ecrire(path.join(majSauveDir(), 'derniere.json'), JSON.stringify({ dir: bdir, from, to: q.version, at: Date.now() })); } catch (e) {}
  fiab.log('mise à jour', `Banque ${from} → ${q.version}`);
  redemarrer();
  return { ok: true, version: q.version };
}
async function majRetour() {
  const r = majRetourInfo(); if (!r) return { ok: false, erreur: 'Aucune mise à jour à défaire.' };
  if (pptSession || INTERV.courant) return { ok: false, erreur: 'Un diaporama lancé depuis Banque est en cours : reviens en arrière après.' };
  let info; try { info = JSON.parse(fs.readFileSync(path.join(r.dir, 'sauvegarde.json'), 'utf8')); } catch (e) { return { ok: false, erreur: 'La copie d’avant la mise à jour est introuvable.' }; }
  const dir = codeDir();
  if (!dir || path.resolve(dir) !== path.resolve(info.dir)) return { ok: false, erreur: 'Banque a été réinstallé depuis : la copie d’avant ne correspond plus.' };
  majEnCours = true;
  await remettre(dir, r.dir, info);
  await apresEcriture(dir, info.from);
  try { fs.rmSync(path.join(majSauveDir(), 'derniere.json'), { force: true }); } catch (e) {}
  fiab.log('mise à jour', `retour de ${info.to} à ${info.from}`);
  redemarrer();
  return { ok: true, version: info.from };
}
ipcMain.handle('maj-etat', () => vueMaj());
ipcMain.handle('maj-chercher', () => majVerifier(true));
ipcMain.handle('maj-installer', () => majInstaller());
ipcMain.handle('maj-retour', () => majRetour());
ipcMain.handle('maj-zip', () => { const u = MAJ.zip || majPage(); if (/^https:\/\/(github\.com|raw\.githubusercontent\.com)\//.test(u) || process.env.BANQUE_MAJ_RAW) shell.openExternal(u); return true; });

/* ---------- fenêtre ---------- */
function montrer(attention = false) {
  if (!win) { if (app.isReady()) createWindow(); return; }
  if (win.isMinimized()) win.restore();
  win.show();
  if (attention) { if (isMac && app.dock) app.dock.bounce('critical'); else win.flashFrame(true); }
  win.focus();
}
function createWindow() {
  win = new BrowserWindow({
    width: 1180, height: 780, minWidth: 760, minHeight: 500, backgroundColor: '#0f1217', title: 'Banque', show: false, icon: APP_ICON,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: false },
  });
  win.loadURL('banque://app/index.html');
  win.once('ready-to-show', () => win.show());
  win.on('focus', () => { try { win.flashFrame(false); } catch (e) {} });
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e, url) => { e.preventDefault(); if (/^https?:\/\//.test(url)) shell.openExternal(url); });
  fiab.watch(win);
  win.on('closed', () => {
    win = null;
    for (const [rid, d] of DEMANDES) { clearTimeout(d.timer); d.resolve({ accepte: false, raison: 'Banque a été fermée sur l’ordinateur qui reçoit.' }); DEMANDES.delete(rid); }
  });
}

/* ---------- menus ---------- */
const send = (cmd, arg) => toPage('menu', cmd, arg);
function buildMenu() {
  const t = [
    ...(isMac ? [{ label: 'Banque', submenu: [
      { label: 'À propos de Banque', role: 'about' }, { label: 'Rechercher une mise à jour…', click: () => send('maj-chercher') }, { type: 'separator' },
      { label: 'Réglages…', accelerator: 'Cmd+,', click: () => send('reglages') }, { type: 'separator' },
      { label: 'Masquer Banque', role: 'hide' }, { label: 'Masquer les autres', role: 'hideOthers' }, { label: 'Tout afficher', role: 'unhide' },
      { type: 'separator' }, { label: 'Quitter Banque', role: 'quit' }] }] : []),
    { label: 'Fichier', submenu: [
      { label: 'Envoyer des fichiers…', accelerator: 'CmdOrCtrl+E', click: () => send('onglet', 'envoyer') },
      { label: 'Ajouter à ma banque…', accelerator: 'CmdOrCtrl+O', click: () => send('ajouter') },
      { label: 'Ouvrir ma banque dans le ' + (isMac ? 'Finder' : 'Explorateur'), accelerator: 'CmdOrCtrl+Shift+O', click: () => { assurerBanque(); shell.openPath(racine()); } },
      ...(isMac ? [] : [{ type: 'separator' }, { label: 'Réglages…', accelerator: 'Ctrl+,', click: () => send('reglages') }, { type: 'separator' }, { label: 'Quitter', role: 'quit' }]),
    ] },
    { label: 'Édition', submenu: [{ label: 'Annuler', role: 'undo' }, { label: 'Rétablir', role: 'redo' }, { type: 'separator' }, { label: 'Couper', role: 'cut' }, { label: 'Copier', role: 'copy' }, { label: 'Coller', role: 'paste' }, { label: 'Tout sélectionner', role: 'selectAll' }] },
    { label: 'Réseau', submenu: [
      { label: 'Cet ordinateur est une banque principale', type: 'checkbox', checked: !!prefs.principale, click: (it) => { prefs.principale = it.checked; savePrefs(); annoncer(); send('prefs'); } },
      { label: 'Autoriser les dépôts dans ma banque principale', type: 'checkbox', enabled: !!prefs.principale, checked: !!prefs.depot, click: (it) => { prefs.depot = it.checked; savePrefs(); annoncer(); send('prefs'); } },
      { type: 'separator' },
      { label: 'Visible sur le réseau', type: 'checkbox', checked: prefs.visible !== false, click: (it) => { prefs.visible = it.checked; savePrefs(); if (!it.checked) annoncer(true); annoncer(); send('prefs'); } },
    ] },
    { label: 'Affichage', submenu: [
      { label: 'Banques du réseau', accelerator: 'CmdOrCtrl+1', click: () => send('onglet', 'reseau') },
      { label: 'Envoyer', accelerator: 'CmdOrCtrl+2', click: () => send('onglet', 'envoyer') },
      { label: 'Ma banque', accelerator: 'CmdOrCtrl+3', click: () => send('onglet', 'mabanque') },
      { label: 'Intervenants', accelerator: 'CmdOrCtrl+4', click: () => send('onglet', 'interv') },
      { type: 'separator' }, { label: 'Plein écran', role: 'togglefullscreen' },
    ] },
    { label: 'Fenêtre', submenu: [{ label: 'Réduire', role: 'minimize' }, isMac ? { label: 'Agrandir', role: 'zoom' } : { label: 'Agrandir', click: () => { if (win) (win.isMaximized() ? win.unmaximize() : win.maximize()); } }, { type: 'separator' }, { label: 'Outils de développement', role: 'toggleDevTools', accelerator: 'Alt+CmdOrCtrl+J' }] },
    { label: 'Aide', role: 'help', submenu: [{ label: 'Mode d’emploi de Banque', click: () => send('aide') }, { label: 'Rechercher une mise à jour…', click: () => send('maj-chercher') }] },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(t));
}

app.whenReady().then(async () => {
  try { app.setAboutPanelOptions({ applicationName: 'Banque', applicationVersion: app.getVersion(), copyright: 'Échange de fichiers entre les ordinateurs du réseau' }); } catch (e) {}
  loadPrefs();
  loadInterv();
  assurerBanque();
  setupProtocol();
  buildMenu();
  await demarrerServeur();
  createWindow();
  ecouter();
  sonderManuels();
  app.on('activate', () => montrer());
  setTimeout(() => { if (prefs.majAuto !== false) majVerifier(false); }, 4000);
  setInterval(() => { if (prefs.majAuto !== false) majVerifier(false); }, 6 * 3600e3 + 60e3);
});
let auRevoir = false;
function annoncerDepart() {
  if (!udp || !udpPret) return;
  try { const msg = Buffer.from(JSON.stringify({ banque: PROTO, id: prefs.id, bye: true, port: portTcp })); for (const b of diffusions()) udp.send(msg, UDP_PORT, b, () => {}); } catch (er) {}
}
app.on('before-quit', (e) => {
  // on prévient les autres tout de suite (sinon ils attendent 7 s avant de voir que l'ordinateur est parti)
  if (auRevoir || !udp || !udpPret) return;
  auRevoir = true;
  annoncerDepart();
  const enCours = [...TRANSFERTS.values()].some(t => ['en cours', 'demande'].includes(t.etat));
  if (enCours && win) {
    const r = dialog.showMessageBoxSync(win, { type: 'warning', buttons: ['Quitter quand même', 'Annuler'], defaultId: 1, cancelId: 1, message: 'Des transferts sont en cours.', detail: 'Quitter Banque les arrête. Une récupération arrêtée reprendra où elle en était la prochaine fois.' });
    if (r === 1) { e.preventDefault(); auRevoir = false; }
  }
});
app.on('will-quit', () => { effacerLocal(); try { if (pptSock) pptSock.destroy(); } catch (e) {} });
app.on('window-all-closed', () => app.quit());
