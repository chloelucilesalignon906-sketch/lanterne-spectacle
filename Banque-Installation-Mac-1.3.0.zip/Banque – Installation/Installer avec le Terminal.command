#!/bin/bash
# Installateur de secours (Banque), quand macOS refuse d'ouvrir « Installer Banque ».
# Utilisation : dans le Terminal, tape « bash » puis une espace, glisse ce fichier dans la fenêtre, Entrée.
D="$(cd "$(dirname "$0")" && pwd)"
CMD="${D}/Installer Banque.app/Contents/Resources/Installer Banque.command"
if [ ! -f "${CMD}" ]; then
  echo "« Installer Banque » est introuvable à côté de ce fichier. Retélécharge le dossier d'installation."
  exit 1
fi
xattr -cr "${D}" 2>/dev/null || true
echo "Installation de Banque dans le Terminal…"
/bin/bash "${CMD}"
RC=$?
echo
[ ${RC} -eq 0 ] && echo "Terminé. Tu peux fermer cette fenêtre." || echo "L'installation s'est arrêtée (code ${RC}). Envoie une capture de cette fenêtre."
exit ${RC}
