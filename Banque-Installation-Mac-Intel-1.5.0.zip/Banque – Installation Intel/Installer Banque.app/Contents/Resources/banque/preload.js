'use strict';
// Pont entre la page de Banque et le processus principal (tout le réseau et les fichiers passent par main.js)
const { contextBridge, ipcRenderer, webUtils } = require('electron');
window.addEventListener('error', e => ipcRenderer.send('fiab-log', 'erreur', `${e.message} (${e.filename}:${e.lineno})`));
window.addEventListener('unhandledrejection', e => ipcRenderer.send('fiab-log', 'promesse', String(e.reason && e.reason.stack || e.reason)));
const on = (canal) => (fn) => ipcRenderer.on(canal, (_e, ...a) => fn(...a));
contextBridge.exposeInMainWorld('banque', {
  etat: () => ipcRenderer.invoke('etat'),
  sourceListe: (sorte, id, chemin) => ipcRenderer.invoke('source-liste', sorte, id, chemin),
  sourceRecuperer: (sorte, id, chemins) => ipcRenderer.invoke('source-recuperer', sorte, id, chemins),
  sourceDeposer: (sorte, id, dossier, abs) => ipcRenderer.invoke('source-deposer', sorte, id, dossier, abs),
  envoyer: (id, abs) => ipcRenderer.invoke('envoyer', id, abs),
  annuler: (tid) => ipcRenderer.invoke('annuler', tid),
  effacerTermines: () => ipcRenderer.invoke('effacer-termines'),
  tailles: (abs) => ipcRenderer.invoke('tailles', abs),
  maListe: (chemin) => ipcRenderer.invoke('ma-liste', chemin),
  maPresence: (chemin, entrees) => ipcRenderer.invoke('ma-presence', chemin, entrees),
  ajouter: (dossier, abs) => ipcRenderer.invoke('ajouter', dossier, abs),
  nouveauDossier: (dossier, nom) => ipcRenderer.invoke('nouveau-dossier', dossier, nom),
  // onglets de ma banque (salles, lieux)
  onglets: () => ipcRenderer.invoke('onglets'),
  ongletOp: (op) => ipcRenderer.invoke('onglet-op', op),
  corbeille: (chemins) => ipcRenderer.invoke('corbeille', chemins),
  ouvrir: (chemin, montrerSeul) => ipcRenderer.invoke('ouvrir', chemin, montrerSeul),
  choisir: (sorte) => ipcRenderer.invoke('choisir', sorte),
  choisirBanque: () => ipcRenderer.invoke('choisir-banque'),
  setPref: (k, v) => ipcRenderer.invoke('set-pref', k, v),
  repondre: (rid, ok, toujours) => ipcRenderer.invoke('repondre', rid, ok, toujours),
  // écran Intervenants et Lanterne PPT
  interv: () => ipcRenderer.invoke('interv'),
  intervOp: (op) => ipcRenderer.invoke('interv-op', op),
  intervLancer: (id) => ipcRenderer.invoke('interv-lancer', id),
  intervImporter: (abs, liste) => ipcRenderer.invoke('interv-importer', abs, liste),
  intervDistant: (id) => ipcRenderer.invoke('interv-distant', id),
  intervDistantOp: (id, op) => ipcRenderer.invoke('interv-distant-op', id, op),
  intervDistantAcces: (id) => ipcRenderer.invoke('interv-distant-acces', id),
  intervDistantEnvoyer: (id, abs, liste, listeNom) => ipcRenderer.invoke('interv-distant-envoyer', id, abs, liste, listeNom),
  pptOuvrir: (chemin) => ipcRenderer.invoke('ppt-ouvrir', chemin),
  abs: (chemin) => ipcRenderer.invoke('abs', chemin),
  pleinEcran: () => ipcRenderer.invoke('plein-ecran'),
  onInterv: on('intervenants'), onPptFin: on('ppt-fin'),
  chemin: (file) => { try { return webUtils.getPathForFile(file) || ''; } catch (e) { return ''; } },
  onPairs: on('pairs'), onTransferts: on('transferts'), onDemande: on('demande'), onDemandeFin: on('demande-fin'),
  onMenu: on('menu'), onPrefs: on('prefs'), onBanqueChange: on('banque-change'),
  // mises à jour (GitHub)
  majEtat: () => ipcRenderer.invoke('maj-etat'),
  majChercher: () => ipcRenderer.invoke('maj-chercher'),
  majInstaller: () => ipcRenderer.invoke('maj-installer'),
  majRetour: () => ipcRenderer.invoke('maj-retour'),
  majZip: () => ipcRenderer.invoke('maj-zip'),
  onMaj: on('maj'),
});
