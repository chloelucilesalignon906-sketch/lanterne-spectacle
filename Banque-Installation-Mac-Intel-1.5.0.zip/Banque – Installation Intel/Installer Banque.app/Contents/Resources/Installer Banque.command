#!/bin/bash
# Mac à puce Apple : si ce script tourne en mode Intel (Rosetta), il se relance en natif (moteur arm64).
if [ "$(/usr/sbin/sysctl -n sysctl.proc_translated 2>/dev/null)" = "1" ] && [ -z "${LS_NATIVE:-}" ] && /usr/bin/arch -arm64 /bin/bash -c true 2>/dev/null; then
  export LS_NATIVE=1
  exec /usr/bin/arch -arm64 /bin/bash "$0" "$@"
fi
# ─────────────────────────────────────────────────────────────
#  Installe Banque sur ce Mac (logiciel à part, hors de la suite Lanterne Spectacle et de Launcher).
#  1. moteur Electron : celui d'un logiciel Lanterne déjà installé (fait pour ce processeur), sinon téléchargé
#     depuis GitHub (version figée 44.7.0, comme la suite) et vérifié avec son empreinte officielle
#  2. assemble « Banque.app » (icône, réglages macOS, identifiant réseau local propre), le signe localement
#  3. le range dans Applications,
#     avec un raccourci sur le Bureau (LS_DESKTOP=0 : sans), puis l'ouvre (NO_OPEN=1 : non)
# ─────────────────────────────────────────────────────────────
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
ELECTRON_FIXE="44.7.0"
BANQUE_VERSION="1.5.0"
NAME="Banque"
DESK="${LS_DESKTOP:-1}"

say()  { printf '\n\033[1;33m▸ %s\033[0m\n' "${1}"; }
ok()   { printf '\033[1;32m✓ %s\033[0m\n' "${1}"; }
fail() { printf '\n\033[1;31m✗ %s\033[0m\n' "${1}"; exit 1; }
trap 'fail "L installation s est arrêtée (ligne ${LINENO}). Vérifie ta connexion Internet et relance."' ERR

[ "$(uname)" = "Darwin" ] || fail "Ce script est fait pour macOS."
[ -d "${HERE}/banque" ] && [ -f "${HERE}/${NAME}.icns" ] || fail "Le dossier « banque » et ${NAME}.icns doivent être à côté de ce script."

if [ "$(/usr/sbin/sysctl -n hw.optional.arm64 2>/dev/null)" = "1" ]; then ARCH=arm64
else
  case "$(uname -m)" in
    arm64)  ARCH=arm64 ;;
    x86_64) ARCH=x64 ;;
    *) fail "Processeur non reconnu : $(uname -m)" ;;
  esac
fi
engine_ok() {
  local f; f="$(file -bL "${1}/Contents/Frameworks/Electron Framework.framework/Electron Framework" 2>/dev/null || true)"
  case "${ARCH}" in arm64) [[ "${f}" == *arm64* ]] ;; *) [[ "${f}" == *x86_64* ]] ;; esac
}

WORK="$(mktemp -d)"
trap 'rm -rf "${WORK:?}"' EXIT
printf '\033[1m\nInstallation de %s %s\033[0m\n' "${NAME}" "${BANQUE_VERSION}"

# ── où installer : Applications (Banque n'est pas rangé avec la suite Lanterne) ──
FOLDER="Lanterne Spectacle"   # seulement pour retrouver un moteur Electron déjà installé
if [ -w "/Applications" ]; then DEST="/Applications"; else DEST="${HOME}/Applications"; fi
mkdir -p "${DEST}"

# ── moteur : un logiciel Lanterne déjà installé (fait pour ce processeur), sinon téléchargement ──
EXIST=""
for n in "${NAME}" "Lanterne Tableau de bord" "Lanterne Launcher" "Lanterne Player" "Lanterne FDR" "Lanterne Timer" "Lanterne Son" "Lanterne Prompteur" "Lanterne VP" "Lanterne Titrage" "Lanterne Infodécor" "Lanterne PPT" "Lanterne Rec et Stream" "Lanterne Cam" "Lanterne Mélangeur"; do
  for d in "/Applications/${FOLDER}" "${HOME}/Applications/${FOLDER}" "/Applications" "${HOME}/Applications"; do
    if [ -d "${d}/${n}.app/Contents/Frameworks/Electron Framework.framework" ] && engine_ok "${d}/${n}.app"; then EXIST="${d}/${n}.app"; break 2; fi
  done
done
if [ -n "${EXIST}" ] && [ -z "${FORCE:-}" ]; then
  say "Moteur déjà présent sur ce Mac (${EXIST##*/}) : installation rapide, sans téléchargement…"
  ditto "${EXIST}" "${WORK}/base.app"
  BASEAPP="${WORK}/base.app"
else
  VERSION="${ELECTRON_VERSION:-${ELECTRON_FIXE}}"
  ZIP="electron-v${VERSION}-darwin-${ARCH}.zip"
  URL="https://github.com/electron/electron/releases/download/v${VERSION}"
  say "Téléchargement du moteur Electron ${VERSION} (${ARCH}, environ 110 Mo)…"
  curl -fL --progress-bar -o "${WORK}/${ZIP}" "${URL}/${ZIP}" || fail "Le téléchargement du moteur a échoué. Vérifie ta connexion Internet et relance."
  curl -fsSL -o "${WORK}/SHASUMS256.txt" "${URL}/SHASUMS256.txt" || fail "Impossible de joindre GitHub. Vérifie ta connexion Internet et relance."
  EXPECTED="$(awk -v f="*${ZIP}" '$2 == f { print $1 }' "${WORK}/SHASUMS256.txt")"
  ACTUAL="$(shasum -a 256 "${WORK}/${ZIP}" | awk '{ print $1 }')"
  [ -n "${EXPECTED}" ] && [ "${EXPECTED}" = "${ACTUAL}" ] || fail "Le fichier téléchargé ne correspond pas à l'empreinte officielle. Relance l'installation."
  ok "Empreinte vérifiée"
  unpack_ok() { [ -x "${WORK}/x/Electron.app/Contents/MacOS/Electron" ] && [ -e "${WORK}/x/Electron.app/Contents/Frameworks/Electron Framework.framework/Electron Framework" ]; }
  # ditto, sinon unzip, sinon tar (sur un Mac Intel sous macOS 15, ditto a répondu « Operation not permitted »)
  ditto -x -k "${WORK}/${ZIP}" "${WORK}/x" && unpack_ok || {
    rm -rf "${WORK:?}/x"; mkdir -p "${WORK}/x"
    /usr/bin/unzip -q -o "${WORK}/${ZIP}" -d "${WORK}/x" && unpack_ok
  } || {
    rm -rf "${WORK:?}/x"; mkdir -p "${WORK}/x"
    /usr/bin/tar -xf "${WORK}/${ZIP}" -C "${WORK}/x" && unpack_ok
  } || fail "Impossible de décompresser le moteur Electron (${ZIP})."
  BASEAPP="${WORK}/x/Electron.app"
fi

# ── assemblage ──
say "Assemblage de ${NAME}…"
OUT="${WORK}/out/${NAME}.app"
mkdir -p "${WORK}/out"
ditto "${BASEAPP}" "${OUT}"
RES="${OUT}/Contents/Resources" PL="${OUT}/Contents/Info.plist"
rm -f "${RES}/default_app.asar"
rm -rf "${OUT:?}/Contents/Resources/app"; mkdir -p "${RES}/app"
ditto "${HERE}/banque" "${RES}/app"
cp "${HERE}/${NAME}.icns" "${RES}/electron.icns"
plutil -replace CFBundleName               -string "${NAME}" "${PL}"
plutil -replace CFBundleDisplayName        -string "${NAME}" "${PL}"
plutil -replace CFBundleIdentifier         -string "fr.lanterne.banque" "${PL}"
plutil -replace CFBundleShortVersionString -string "${BANQUE_VERSION}" "${PL}"
plutil -replace CFBundleVersion            -string "${BANQUE_VERSION}" "${PL}"
plutil -replace LSApplicationCategoryType  -string "public.app-category.utilities" "${PL}"
plutil -replace NSLocalNetworkUsageDescription -string "Banque trouve les autres ordinateurs du réseau local qui ont Banque et échange des fichiers avec eux." "${PL}"
plutil -remove CFBundleDocumentTypes "${PL}" >/dev/null 2>&1 || true
# Réseau local (macOS) : l'autorisation suit l'identifiant interne (UUID) de l'exécutable ; celui-ci reçoit le sien
if [ -f "${OUT}/Contents/MacOS/Electron" ]; then
  /usr/bin/perl -e 'open(F, "+<", $ARGV[0]) or exit 1; binmode F; local $/; my $d = <F>;
my @off; my $m = unpack("N", substr($d, 0, 4));
if ($m == 0xcafebabe) { my $n = unpack("N", substr($d, 4, 4)); for my $i (0 .. $n - 1) { push @off, unpack("N", substr($d, 8 + 20 * $i + 8, 4)); } } else { push @off, 0; }
my $done = 0;
for my $o (@off) {
  next unless unpack("V", substr($d, $o, 4)) == 0xfeedfacf;
  my $nc = unpack("V", substr($d, $o + 16, 4)); my $p = $o + 32;
  for (1 .. $nc) { my ($c, $s) = unpack("VV", substr($d, $p, 8)); last if $s < 8; if ($c == 0x1b) { substr($d, $p + 8, 16) = join("", map { chr(int(rand(256))) } 1 .. 16); $done++; } $p += $s; }
}
exit 2 unless $done; seek(F, 0, 0); print F $d; close F;' "${OUT}/Contents/MacOS/Electron" || true
fi
xattr -cr "${OUT}"
codesign --force --deep --sign - "${OUT}" >/dev/null 2>&1 || fail "La signature locale de ${NAME} a échoué."
codesign --verify --deep "${OUT}" >/dev/null 2>&1 || fail "La vérification de la signature de ${NAME} a échoué."
osascript -e "if application \"${NAME}\" is running then tell application \"${NAME}\" to quit" >/dev/null 2>&1 || true
sleep 1
rm -rf "${DEST:?}/Banque.app"
ditto "${OUT}" "${DEST}/${NAME}.app"
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "${DEST}/${NAME}.app" >/dev/null 2>&1 || true
# une copie rangée ailleurs (installation précédente) est retirée
for d in "/Applications" "${HOME}/Applications" "/Applications/${FOLDER}" "${HOME}/Applications/${FOLDER}"; do
  if [ -d "${d}/${NAME}.app" ] && [ "${d}/${NAME}.app" != "${DEST}/${NAME}.app" ]; then rm -rf "${d:?}/Banque.app" 2>/dev/null || true; fi
done
if [ -L "${HOME}/Desktop/${NAME}" ]; then rm -f "${HOME}/Desktop/${NAME}"; fi
if [ "${DESK}" != "0" ]; then ln -sfn "${DEST}/${NAME}.app" "${HOME}/Desktop/${NAME}" 2>/dev/null || true; fi
ok "${NAME} est dans ${DEST}"
if [ -n "${LS_DEST_FILE:-}" ]; then printf '%s' "${DEST}" > "${LS_DEST_FILE}"; fi
trap - ERR
printf '\n\033[1;32mTerminé.\033[0m\n'
[ -n "${NO_OPEN:-}" ] || open "${DEST}/${NAME}.app"
