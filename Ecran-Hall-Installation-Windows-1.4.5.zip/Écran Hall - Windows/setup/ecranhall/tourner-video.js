'use strict';
// Écran Hall 1.4.4-1.4.5 — vidéo tournée pour de bon (image réencodée), pour les boîtiers Qeedji : leur vidéo est dessinée à part,
// sous la page, et n'obéit ni à la rotation CSS ni à la rotation inscrite dans le fichier (essais d'antoine, 23/11/2026).
// Dans l'atelier (fenêtre cachée) : la vidéo est lue sans le son, chaque image est tournée sur un canevas puis encodée
// en H.264 (WebCodecs : VideoToolbox sur Mac, Media Foundation sous Windows), et le tout est rangé dans un MP4 simple
// (ftyp, mdat, moov) écrit ici. Le son n'est pas repris (le son des vidéos est coupé au départ dans Écran Hall).
// Durée : celle de la vidéo (lecture en temps réel).
(function () {
  // ---------- MP4 ----------
  const u8 = (...l) => { const n = l.reduce((a, b) => a + b.length, 0), o = new Uint8Array(n); let p = 0; for (const b of l) { o.set(b, p); p += b.length; } return o; };
  const u32 = n => { const b = new Uint8Array(4); new DataView(b.buffer).setUint32(0, n >>> 0); return b; };
  const u16 = n => { const b = new Uint8Array(2); new DataView(b.buffer).setUint16(0, n & 0xffff); return b; };
  const str = s => new Uint8Array([...s].map(c => c.charCodeAt(0)));
  const zeros = n => new Uint8Array(n);
  const box = (type, ...l) => { const c = u8(...l); return u8(u32(c.length + 8), str(type), c); };
  const fbox = (type, v, f, ...l) => box(type, new Uint8Array([v, (f >> 16) & 255, (f >> 8) & 255, f & 255]), ...l);
  const MATRICE = u8(u32(0x10000), u32(0), u32(0), u32(0), u32(0x10000), u32(0), u32(0), u32(0), u32(0x40000000));

  // échantillons : [{ data, pts (µs), key }] dans l'ordre de décodage
  function mp4(ech, w, h, avcC) {
    const TS = 90000, n = ech.length;
    const pts = ech.map(e => Math.round(e.pts * TS / 1e6));
    const tries = pts.slice().sort((a, b) => a - b);
    const pas = n > 1 ? Math.max(1, Math.round((tries[n - 1] - tries[0]) / (n - 1))) : 3000;
    const dts = tries.map(x => x - tries[0]);          // instants de décodage = présentations triées
    const dur = dts.map((x, i) => i < n - 1 ? Math.max(1, dts[i + 1] - x) : pas);
    const total = dts[n - 1] + dur[n - 1];
    // stts compressé
    const stts = []; for (const d of dur) { const l = stts[stts.length - 1]; if (l && l[1] === d) l[0]++; else stts.push([1, d]); }
    const ctt = pts.map((p, i) => p - tries[0] - dts[i]);
    const avecCtts = ctt.some(x => x !== 0);
    const ctts = []; for (const c of ctt) { const l = ctts[ctts.length - 1]; if (l && l[1] === c) l[0]++; else ctts.push([1, c]); }
    const cles = []; ech.forEach((e, i) => { if (e.key) cles.push(i + 1); });
    const ftyp = box('ftyp', str('isom'), u32(512), str('isom'), str('iso2'), str('avc1'), str('mp41'));
    const tailleData = ech.reduce((a, e) => a + e.data.length, 0);
    const offset = ftyp.length + 8;   // début des données dans mdat
    const ms = Math.round(total * 1000 / TS);
    const avc1 = box('avc1', zeros(6), u16(1), zeros(16), u16(w), u16(h), u32(0x00480000), u32(0x00480000), u32(0), u16(1), zeros(32), u16(0x18), u16(0xffff),
      box('avcC', avcC));
    const stbl = box('stbl',
      fbox('stsd', 0, 0, u32(1), avc1),
      fbox('stts', 0, 0, u32(stts.length), ...stts.map(([c, d]) => u8(u32(c), u32(d)))),
      ...(avecCtts ? [fbox('ctts', 1, 0, u32(ctts.length), ...ctts.map(([c, d]) => u8(u32(c), u32(d))))] : []),
      fbox('stss', 0, 0, u32(cles.length), ...cles.map(u32)),
      fbox('stsc', 0, 0, u32(1), u32(1), u32(n), u32(1)),
      fbox('stsz', 0, 0, u32(0), u32(n), ...ech.map(e => u32(e.data.length))),
      fbox('stco', 0, 0, u32(1), u32(offset)));
    const moov = box('moov',
      fbox('mvhd', 0, 0, u32(0), u32(0), u32(1000), u32(ms), u32(0x10000), u16(0x100), zeros(10), MATRICE, zeros(24), u32(2)),
      box('trak',
        fbox('tkhd', 0, 3, u32(0), u32(0), u32(1), u32(0), u32(ms), zeros(8), u16(0), u16(0), u16(0), u16(0), MATRICE, u32(w << 16), u32(h << 16)),
        box('mdia',
          fbox('mdhd', 0, 0, u32(0), u32(0), u32(TS), u32(total), u16(0x55c4), u16(0)),
          fbox('hdlr', 0, 0, u32(0), str('vide'), zeros(12), str('VideoHandler'), zeros(1)),
          box('minf', fbox('vmhd', 0, 1, zeros(8)), box('dinf', fbox('dref', 0, 0, u32(1), fbox('url ', 0, 1))), stbl))));
    return u8(ftyp, u32(tailleData + 8), str('mdat'), ...ech.map(e => e.data), moov);
  }

  // ---------- lecture, rotation, encodage ----------
  // o = { src, angle (0|90|180|270, sens horaire), max (plus grand côté), debit (bit/s),
  //       cadre: { w, h } (1.4.5 : image de sortie entière, bandes ou recadrage inscrits dans la vidéo), fit: 'contain'|'cover', fond }
  async function tourner(o) {
    if (typeof VideoEncoder !== 'function') return { error: 'encodeur vidéo absent de ce moteur' };
    const angle = ((+o.angle % 360) + 360) % 360;
    const v = document.createElement('video');
    v.muted = true; v.preload = 'auto'; v.playsInline = true;
    window.__tournerProgres = 0;
    try {
      await new Promise((ok, ko) => { v.onloadeddata = ok; v.onerror = () => ko(new Error('format de vidéo illisible ici')); setTimeout(() => ko(new Error('vidéo trop longue à ouvrir')), 30000); v.src = o.src; });
      const vw = v.videoWidth, vh = v.videoHeight, duree = isFinite(v.duration) ? v.duration : 0;
      if (!vw || !vh) throw new Error('vidéo sans image');
      const quart = angle === 90 || angle === 270;
      const k = Math.min(1, (o.max || 1920) / Math.max(vw, vh));
      let sw = Math.round(vw * k / 2) * 2, sh = Math.round(vh * k / 2) * 2;       // image avant rotation
      let W = quart ? sh : sw, H = quart ? sw : sh;                                // image tournée
      if (o.cadre && o.cadre.w && o.cadre.h) {
        // 1.4.5 : la vidéo tournée est posée dans l'image de sortie entière (bandes de la couleur du fond, ou bords coupés)
        W = Math.round(o.cadre.w / 2) * 2; H = Math.round(o.cadre.h / 2) * 2;
        const rw = quart ? vh : vw, rh = quart ? vw : vh;
        const e = o.fit === 'cover' ? Math.max(W / rw, H / rh) : Math.min(W / rw, H / rh);
        sw = vw * e; sh = vh * e;
      }
      const c = new OffscreenCanvas(W, H), g = c.getContext('2d');
      g.imageSmoothingQuality = 'high';
      const ech = []; let avcC = null, erreur = null;
      const enc = new VideoEncoder({
        output: (chunk, meta) => {
          if (meta && meta.decoderConfig && meta.decoderConfig.description && !avcC) avcC = new Uint8Array(meta.decoderConfig.description.slice ? meta.decoderConfig.description.slice(0) : meta.decoderConfig.description);
          const d = new Uint8Array(chunk.byteLength); chunk.copyTo(d);
          ech.push({ data: d, pts: chunk.timestamp, key: chunk.type === 'key' });
        },
        error: e => { erreur = e; },
      });
      const grand = Math.max(W, H) > 1920;
      const cfg = { codec: grand ? 'avc1.640033' : 'avc1.640028', width: W, height: H, bitrate: o.debit || (grand ? 30e6 : 10e6), framerate: 30, avc: { format: 'avc' } };
      const sup = await VideoEncoder.isConfigSupported(cfg).catch(() => ({ supported: false }));
      if (!sup.supported) { cfg.codec = 'avc1.4d0028'; if (!(await VideoEncoder.isConfigSupported(cfg).catch(() => ({}))).supported) throw new Error(`encodage H.264 ${W}×${H} impossible sur cet ordinateur`); }
      enc.configure(cfg);
      let derniereCle = -1e9, vues = 0, dernierT = -1;
      const dessiner = t => {
        if (t <= dernierT) return; dernierT = t;
        g.setTransform(1, 0, 0, 1, 0, 0); g.fillStyle = o.fond || '#000'; g.fillRect(0, 0, W, H);
        g.translate(W / 2, H / 2); g.rotate(angle * Math.PI / 180); g.drawImage(v, -sw / 2, -sh / 2, sw, sh);
        const us = Math.round(t * 1e6);
        const f = new VideoFrame(c, { timestamp: us });
        const cle = us - derniereCle >= 2e6; if (cle) derniereCle = us;
        enc.encode(f, { keyFrame: cle }); f.close(); vues++;
        window.__tournerProgres = duree ? Math.min(0.99, t / duree) : 0;
      };
      await new Promise((ok, ko) => {
        const suivant = (_now, m) => { if (erreur) return ko(erreur); dessiner(m.mediaTime); if (!v.ended) v.requestVideoFrameCallback(suivant); };
        v.requestVideoFrameCallback(suivant);
        v.onended = () => setTimeout(ok, 100);
        v.onerror = () => ko(new Error('lecture de la vidéo interrompue'));
        // file d'encodage trop pleine : on ralentit la lecture
        const regle = setInterval(() => { if (v.ended) return clearInterval(regle); v.playbackRate = enc.encodeQueueSize > 20 ? 0.5 : 1; }, 250);
        v.currentTime = 0;
        v.play().catch(ko);
        // garde-fou : 3 × la durée + 1 min
        setTimeout(() => ko(new Error('rotation de la vidéo trop longue')), (duree * 3 + 60) * 1000);
      });
      await enc.flush(); enc.close();
      if (erreur) throw erreur;
      if (!ech.length || !avcC) throw new Error('aucune image encodée');
      window.__tournerProgres = 1;
      return { ok: true, data: mp4(ech, W, H, avcC), w: W, h: H, images: vues, duree };
    } catch (e) {
      return { error: String(e && e.message || e) };
    } finally { try { v.removeAttribute('src'); v.load(); } catch (x) {} }
  }
  window.tournerVideo = tourner;
})();
