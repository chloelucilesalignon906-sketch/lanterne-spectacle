@echo off
rem Lanterne Tableau de bord : desinstallation (la suite Lanterne Spectacle n est pas touchee).
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup\installer-tableau.ps1" -Uninstall
