@echo off
rem Lanterne Tableau de bord : installation sous Windows (double-clic). Aucun droit administrateur requis.
title Installation de Lanterne Tableau de bord
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup\installer-tableau.ps1" %*
if errorlevel 1 (
  echo.
  echo L installation ne s est pas terminee. Le journal est dans %LOCALAPPDATA%\Lanterne Spectacle\installation-tableau.log
  pause
)
