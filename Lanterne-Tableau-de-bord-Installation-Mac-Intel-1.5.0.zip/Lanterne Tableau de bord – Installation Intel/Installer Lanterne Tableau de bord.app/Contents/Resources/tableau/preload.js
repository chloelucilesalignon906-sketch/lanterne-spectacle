'use strict';
// Pont entre la page de Lanterne Tableau de bord et le processus principal (onglet Contrôle : commandes passées au processus principal ;
// page téléphone et mises à jour : 1.4.0). Sur un téléphone, tel-pont.js donne la même chose par le réseau.
const { contextBridge, ipcRenderer } = require('electron');
window.addEventListener('error', e => ipcRenderer.send('fiab-log', 'erreur', `${e.message} (${e.filename}:${e.lineno})`));
window.addEventListener('unhandledrejection', e => ipcRenderer.send('fiab-log', 'promesse', String(e.reason && e.reason.stack || e.reason)));
/* ---------- caméras NDI (1.5.0) ----------
   Le processus principal reçoit les caméras (mémoire partagée par caméra, image I420) ; ici, la dernière image de chaque caméra
   est lue et dessinée dans les canevas que la page désigne (par leur id), à la cadence de l'écran. Pour les téléphones qui
   regardent Surveillance ou Personnalisé, un JPEG de 640 px par caméra est envoyé au processus principal deux fois par seconde. */
const NP = require('./ndi-page');
const CAMS = new Map();     // nom -> { h, shm, buf, vf, n, at, w, hh, fps, recuA }
const TOILES = new Map();   // id du canevas -> nom de la caméra
let camJpeg = false;
function camsMaj(v) {
  camJpeg = !!(v && v.jpeg);
  const garder = new Set();
  for (const r of (v && v.recus) || []) {
    garder.add(r.name);
    const c = CAMS.get(r.name);
    if (c && c.shm === r.shm) continue;
    if (c) { NP.lacher(c.h); if (c.vf) c.vf.close(); }
    const h = NP.ouvrir(r.shm);
    CAMS.set(r.name, { h, shm: r.shm, buf: new Uint8Array(1920 * 1080 * 3 / 2), vf: null, n: 0, at: 0, w: 0, hh: 0, fps: 0, recuA: 0 });
  }
  for (const [nom, c] of CAMS) if (!garder.has(nom)) { NP.lacher(c.h); if (c.vf) c.vf.close(); CAMS.delete(nom); }
}
ipcRenderer.on('cams', (_e, v) => camsMaj(v));
const FMT = { I420: 'I420', BGRA: 'BGRA', BGRX: 'BGRX', RGBA: 'RGBA', RGBX: 'RGBX' };
function lire(c) {
  if (c.h < 0) return false;
  let f = NP.image(c.h, c.buf);
  if (f && f.small) { c.buf = new Uint8Array(f.size); f = NP.image(c.h, c.buf); }
  if (!f || f.small || !FMT[f.fourcc]) return false;
  try {
    const vf = new VideoFrame(c.buf.subarray(0, f.size), { format: FMT[f.fourcc], codedWidth: f.w, codedHeight: f.h, timestamp: (c.n + 1) * 33333,
      colorSpace: f.fourcc === 'I420' ? { primaries: 'bt709', transfer: 'bt709', matrix: 'bt709', fullRange: false } : undefined });
    if (c.vf) c.vf.close();
    c.vf = vf; c.n += 1; c.w = f.w; c.hh = f.h; c.fps = f.fps || 0; c.recuA = Date.now();
    return true;
  } catch (e) { return false; }
}
function dessiner() {
  const neuf = new Set();
  for (const [nom, c] of CAMS) if (lire(c)) neuf.add(nom);
  for (const [id, nom] of TOILES) {
    const c = CAMS.get(nom); if (!c || !c.vf || !neuf.has(nom)) continue;
    const cv = document.getElementById(id); if (!cv) { TOILES.delete(id); continue; }
    // canevas à la taille où il est affiché (au plus l'image reçue) : moins de travail que l'image entière
    const r = cv.getBoundingClientRect(), dpr = Math.min(2, window.devicePixelRatio || 1);
    const w = Math.max(2, Math.min(c.w, Math.round(r.width * dpr))), h = Math.max(2, Math.round(w * c.hh / c.w));
    if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
    try { cv.getContext('2d').drawImage(c.vf, 0, 0, w, h); } catch (e) {}
  }
  requestAnimationFrame(dessiner);
}
requestAnimationFrame(dessiner);
// fenêtre cachée (rAF arrêté) : les images restent lues pour les téléphones
setInterval(() => { if (document.hidden) for (const c of CAMS.values()) lire(c); }, 250);
setInterval(async () => {
  if (!camJpeg) return;
  for (const [nom, c] of CAMS) {
    if (!c.vf || Date.now() - c.recuA > 3000) continue;
    try {
      const w = Math.min(640, c.w), h = Math.round(w * c.hh / c.w), oc = new OffscreenCanvas(w, h);
      oc.getContext('2d').drawImage(c.vf, 0, 0, w, h);
      const b = await oc.convertToBlob({ type: 'image/jpeg', quality: 0.7 });
      ipcRenderer.send('cam-jpeg', nom, new Uint8Array(await b.arrayBuffer()));
    } catch (e) {}
  }
}, 500);
window.addEventListener('pagehide', () => { for (const c of CAMS.values()) if (c.vf) c.vf.close(); });

contextBridge.exposeInMainWorld('lanterneTableau', {
  tout: () => ipcRenderer.invoke('tout'),
  prefs: () => ipcRenderer.invoke('prefs'),
  setPref: (k, v) => ipcRenderer.invoke('set-pref', k, v),
  oublier: (cle) => ipcRenderer.invoke('oublier', cle),
  setTitre: (cle, texte) => ipcRenderer.invoke('set-titre', cle, texte),
  setOrdre: (o) => ipcRenderer.invoke('set-ordre', o),
  commande: (cle, msgs) => ipcRenderer.invoke('commande', cle, msgs),
  commandes: (liste) => ipcRenderer.invoke('commandes', liste),
  onLogiciels: (fn) => ipcRenderer.on('logiciels', (_e, l) => fn(l)),
  onEtat: (fn) => ipcRenderer.on('etat', (_e, cle, st, n) => fn(cle, st, n)),
  onVignettes: (fn) => ipcRenderer.on('vignettes', (_e, cle, v) => fn(cle, v)),
  onCharge: (fn) => ipcRenderer.on('charge', (_e, id, c) => fn(id, c)),
  telInfo: () => ipcRenderer.invoke('tel-info'),
  telSet: (k, v) => ipcRenderer.invoke('tel-set', k, v),
  onTel: (fn) => ipcRenderer.on('tel', (_e, i) => fn(i)),
  majEtat: () => ipcRenderer.invoke('maj-etat'),
  majChercher: () => ipcRenderer.invoke('maj-chercher'),
  majInstaller: () => ipcRenderer.invoke('maj-installer'),
  majRetour: () => ipcRenderer.invoke('maj-retour'),
  majZip: () => ipcRenderer.invoke('maj-zip'),
  majAuto: (v) => ipcRenderer.invoke('maj-auto', v),
  onMaj: (fn) => ipcRenderer.on('maj', (_e, v) => fn(v)),
  cams: () => ipcRenderer.invoke('cams').then(v => { camsMaj(v); return v; }),
  onCams: (fn) => ipcRenderer.on('cams', (_e, v) => fn(v)),
  camBesoin: (quoi, v) => ipcRenderer.send('cam-besoin', quoi, !!v),
  // canevas (id) où dessiner une caméra ; nom vide : plus rien dans ce canevas
  camToile: (id, nom) => { if (nom) TOILES.set(String(id), String(nom)); else TOILES.delete(String(id)); },
  camToilesVider: () => TOILES.clear(),
  // { nom: { w, h, fps, age } } : image reçue, cadence, âge de la dernière image (ms)
  camEtat: () => Object.fromEntries([...CAMS].map(([n, c]) => [n, { w: c.w, h: c.hh, fps: Math.round(c.fps), age: c.recuA ? Date.now() - c.recuA : -1 }])),
  setSurv: (s) => ipcRenderer.invoke('set-surv', s),
  setPerso: (p) => ipcRenderer.invoke('set-perso', p),
  onMenu: (fn) => ipcRenderer.on('menu', (_e, cmd, arg) => fn(cmd, arg)),
});
