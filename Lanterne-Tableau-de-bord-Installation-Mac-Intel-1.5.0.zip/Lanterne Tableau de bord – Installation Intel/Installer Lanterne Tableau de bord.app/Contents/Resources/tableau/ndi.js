'use strict';
// Lanterne Spectacle · NDI dans le processus principal (fichier commun : ppt, infodecor, app)
// macOS (réseau local) n'autorise que le processus principal d'un logiciel à parler au réseau : c'est donc lui qui envoie
// et reçoit le NDI, avec le module natif bin/<système>/ndi.node (le même que Lanterne Cam). Les images passent par une
// mémoire partagée : la page les y pose (envoi) ou les y lit (réception) avec ndi-page.js, chargé par preload.js.
// La bibliothèque NDI 6 (30 Mo) est cherchée dans le logiciel, puis dans Lanterne Cam installé à côté, puis dans les
// NDI Tools de l'ordinateur.
// Usage : const ndi = require('./ndi')({ dir: __dirname, nom: 'Lanterne PPT', cle: 'lppt' });
//   ndi.etat()                       -> { ok, version, error }
//   ndi.sources(adresses)            -> [{ name, url }]
//   ndi.recevoir(nom, adresse[, fmt]) -> { h, shm } (h = -1 : refusé)     ndi.fermer(h)      ndi.info(h)
//     fmt 'i420' (par défaut) : image sans alpha en I420 (1,5 octet par point), avec alpha en RGBA ; 'rgba' : toujours RGBX / RGBA
//   ndi.emettre(nomNDI, i/s)         -> { h, shm, name }                  ndi.arreter(h)     ndi.infoEnvoi(h)
//   ndi.toutFermer()
const fs = require('fs');
const path = require('path');

module.exports = function creerNdi(opt) {
  const isMac = process.platform === 'darwin', isWin = process.platform === 'win32';
  const plat = isMac ? 'darwin' : isWin ? 'win32-x64' : 'linux-x64';
  const NDI = { mod: null, ok: false, version: '', error: '', lib: '' };
  const dir = process.env.LANTERNE_NDI_DIR || path.join(opt.dir, 'bin', plat);
  const libName = isMac ? 'libndi.dylib' : isWin ? 'Processing.NDI.Lib.x64.dll' : 'libndi.so';
  let tried = false;
  function charger() {
    if (tried) return NDI;
    tried = true;
    try { NDI.mod = require(path.join(dir, 'ndi.node')); }
    catch (e) { NDI.error = `module NDI introuvable ou refusé (${e.message})`; return NDI; }
    const cands = [path.join(dir, libName)];
    // Lanterne Cam installé à côté (Mac : Lanterne Cam.app ; Windows : dossier Lanterne Cam ; sources : ../cam)
    cands.push(path.resolve(opt.dir, '..', '..', '..', '..', 'Lanterne Cam.app', 'Contents', 'Resources', 'app', 'bin', plat, libName));
    cands.push(path.resolve(opt.dir, '..', '..', '..', 'Lanterne Cam', 'resources', 'app', 'bin', plat, libName));
    cands.push(path.resolve(opt.dir, '..', 'cam', 'bin', plat, libName));
    if (process.env.NDI_RUNTIME_DIR_V6) cands.push(path.join(process.env.NDI_RUNTIME_DIR_V6, libName));
    if (isMac) cands.push('/usr/local/lib/libndi.dylib', '/Library/NDI SDK for Apple/lib/macOS/libndi.dylib', '/Library/NDI Advanced SDK for Apple/lib/macOS/libndi_advanced.dylib');
    if (isWin) cands.push('C:\\Program Files\\NDI\\NDI 6 Runtime\\v6\\' + libName, 'C:\\Program Files\\NDI\\NDI 6 Tools\\Runtime\\' + libName);
    const errs = [];
    for (const p of cands) {
      if (!fs.existsSync(p)) continue;
      let r = null;
      try { r = NDI.mod.load(p); } catch (e) { r = { ok: false, error: e.message }; }
      if (r && r.ok) { NDI.ok = true; NDI.version = r.version || ''; NDI.lib = p; return NDI; }
      errs.push(`${path.basename(p)} : ${r && r.error || 'refusée'}`);
    }
    NDI.error = errs.length ? errs.join(' ; ') : 'bibliothèque NDI introuvable (réinstallez Lanterne Spectacle, ou installez Lanterne Cam)';
    return NDI;
  }
  const rx = new Map(), tx = new Map();   // numéro -> nom de la mémoire partagée
  let n = 0;
  // POSIX : nom court (31 caractères au plus sur Mac) ; Windows : mémoire nommée de la session
  const shmName = () => (isWin ? `Local\\${opt.cle}.${process.pid}.${++n}` : `/${opt.cle}.${process.pid}.${++n}`);
  const api = {
    etat() { const s = charger(); return { ok: s.ok, version: s.version, error: s.error }; },
    sources(ips) { if (!charger().ok) return []; try { return NDI.mod.find(String(ips || '')) || []; } catch (e) { return []; } },
    recevoir(name, url, fmt) {
      if (!charger().ok) return { h: -1, shm: '' };
      const shm = shmName();
      const h = NDI.mod.open(String(name || ''), String(url || ''), opt.nom, shm, fmt === 'rgba' ? 'rgba' : 'i420');
      if (h >= 0) rx.set(h, shm);
      return { h, shm: h >= 0 ? shm : '' };
    },
    fermer(h) { if (!rx.has(h)) return false; rx.delete(h); try { return NDI.mod.close(h); } catch (e) { return false; } },
    info(h) { if (!rx.has(h)) return null; try { return NDI.mod.info(h); } catch (e) { return null; } },
    emettre(name, fps) {
      if (!charger().ok) return { h: -1, shm: '', name: '' };
      const shm = shmName();
      const h = NDI.mod.sendOpen(String(name || opt.nom), shm, +fps || 30);
      if (h < 0) return { h: -1, shm: '', name: '' };
      tx.set(h, shm);
      const i = NDI.mod.sendInfo(h);
      return { h, shm, name: i && i.name || '' };
    },
    arreter(h) { if (!tx.has(h)) return false; tx.delete(h); try { return NDI.mod.sendClose(h); } catch (e) { return false; } },
    infoEnvoi(h) { if (!tx.has(h)) return null; try { return NDI.mod.sendInfo(h); } catch (e) { return null; } },
    toutFermer() { for (const h of [...rx.keys()]) api.fermer(h); for (const h of [...tx.keys()]) api.arreter(h); },
  };
  return api;
};
