'use strict';
// Lanterne Tableau de bord sur un téléphone (1.4.0) : la page est la même que dans le logiciel ; ici, window.lanterneTableau
// passe par le réseau (serveur web du Tableau de bord, port 7612) au lieu du processus principal. Dans le logiciel, ce fichier
// ne fait rien (le pont existe déjà, preload.js).
// La clé vient de l'adresse du code QR (?k=…) ; elle est aussi gardée sur le téléphone pour l'icône de l'écran d'accueil.
(function () {
  if (window.lanterneTableau) return;
  const q = new URLSearchParams(location.search);
  let cle = q.get('k') || '';
  try { if (cle) localStorage.setItem('lanterne-tableau-cle', cle); else cle = localStorage.getItem('lanterne-tableau-cle') || ''; } catch (e) {}
  const k = 'k=' + encodeURIComponent(cle);
  const LOCAL = 'lanterne-tableau-tel';
  let local = { vue: 'vue', taille: 'm' };
  try { Object.assign(local, JSON.parse(localStorage.getItem(LOCAL) || '{}')); } catch (e) {}
  if (!['vue', 'ctl', 'surv', 'perso'].includes(local.vue)) local.vue = 'vue';
  if (!['s', 'm', 'l'].includes(local.taille)) local.taille = 'm';
  let serveur = { titres: {}, ordre: { ordis: [], logs: {} }, periode: 500, telCtl: true, surv: { auto: true, cams: [], sans: [], ips: '' }, perso: { cols: 0, items: [] } };
  const prefs = () => Object.assign({}, serveur, local, serveur.telCtl || local.vue !== 'ctl' ? {} : { vue: 'vue' });
  const get = (u) => fetch(`${u}${u.includes('?') ? '&' : '?'}${k}`, { cache: 'no-store' }).then(r => { if (r.status === 403) throw new Error('cle'); return r.json(); });
  const post = (u, b) => fetch(`${u}?${k}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) }).then(r => r.json()).catch(() => null);
  const H = { logiciels: [], etat: [], vignettes: [], charge: [], menu: [], liaison: [], cams: [] };
  // caméras (1.5.0) : JPEG reçus deux fois par seconde, dessinés dans les canevas désignés par la page
  let monId = '', CAMV = null;
  const CAMI = new Map();   // nom -> { b64, at, w, h }
  const TOILES = new Map(); // id du canevas -> nom
  const dire = () => { if (monId) post('api/vue', { id: monId, vue: prefs().vue }); };
  async function peindre(id, nom) {
    const c = CAMI.get(nom), cv = document.getElementById(id); if (!c || !cv) return;
    try {
      const bmp = await createImageBitmap(await (await fetch('data:image/jpeg;base64,' + c.b64)).blob());
      if (cv.width !== bmp.width || cv.height !== bmp.height) { cv.width = bmp.width; cv.height = bmp.height; }
      cv.getContext('2d').drawImage(bmp, 0, 0); c.w = bmp.width; c.h = bmp.height; bmp.close();
    } catch (e) {}
  }
  const emit = (n, ...a) => { for (const f of H[n]) { try { f(...a); } catch (e) { console.error(e); } } };
  let es = null, ouvert = false, premier = true;
  function flux() {
    es = new EventSource(`flux?${k}&vue=${encodeURIComponent(prefs().vue)}`);
    es.onopen = () => {
      ouvert = true; emit('liaison', true);
      // reconnexion : tout est relu (l'état a pu changer pendant la coupure)
      if (!premier) get('api/tout').then(t => emit('menu', 'tout', t)).catch(() => {});
      premier = false;
    };
    es.onerror = () => {
      if (ouvert) { ouvert = false; emit('liaison', false); }
      // clé refusée (nouveau code QR) : le flux ne reviendra pas ; la page le dit
      get('api/prefs').catch(e => { if (e.message === 'cle') { es.close(); emit('liaison', false, 'cle'); } });
    };
    es.addEventListener('logiciels', e => emit('logiciels', JSON.parse(e.data)));
    es.addEventListener('etat', e => { const d = JSON.parse(e.data); emit('etat', d.cle, d.etat, d.n); });
    es.addEventListener('vignettes', e => { const d = JSON.parse(e.data); emit('vignettes', d.cle, d.v); });
    es.addEventListener('charge', e => { const d = JSON.parse(e.data); emit('charge', d.id, d.c); });
    es.addEventListener('bonjour', e => { monId = JSON.parse(e.data).id; dire(); });
    es.addEventListener('cams', e => { CAMV = JSON.parse(e.data); emit('cams', CAMV); });
    es.addEventListener('camimg', e => { const d = JSON.parse(e.data); const o = CAMI.get(d.name) || {}; CAMI.set(d.name, Object.assign(o, { b64: d.jpeg, at: Date.now() })); for (const [id, n] of TOILES) if (n === d.name) peindre(id, n); });
    es.addEventListener('prefs', e => { serveur = Object.assign(serveur, JSON.parse(e.data)); emit('menu', 'prefs'); });
  }
  window.LANTERNE_TEL = true;
  window.lanterneTableau = {
    tel: true,
    tout: () => get('api/tout'),
    prefs: () => Promise.resolve(prefs()),
    // sur le téléphone : onglet et taille gardés sur le téléphone ; le reste reste celui du Tableau de bord
    setPref: (n, v) => { if (n === 'vue' || n === 'taille') { local[n] = v; try { localStorage.setItem(LOCAL, JSON.stringify(local)); } catch (e) {} if (n === 'vue') dire(); } return Promise.resolve(prefs()); },
    oublier: () => Promise.resolve(true),
    setTitre: () => Promise.resolve(prefs()),
    setOrdre: () => Promise.resolve(prefs()),
    commande: (cle, msgs) => post('api/commande', { cle, msgs }).then(r => r && 'ok' in r ? r : { ok: false, raison: r && r.raison === 'telctl' ? 'telctl' : 'reseau' }),
    commandes: (liste) => post('api/commandes', liste).then(r => Array.isArray(r) ? r : liste.map(() => ({ ok: false, raison: 'reseau' }))),
    onLogiciels: f => H.logiciels.push(f),
    onEtat: f => H.etat.push(f),
    onVignettes: f => H.vignettes.push(f),
    onCharge: f => H.charge.push(f),
    onMenu: f => H.menu.push(f),
    onLiaison: f => H.liaison.push(f),
    cams: () => Promise.resolve(CAMV),
    onCams: f => H.cams.push(f),
    camBesoin: () => {},
    camToile: (id, nom) => { if (nom) { TOILES.set(String(id), String(nom)); peindre(String(id), String(nom)); } else TOILES.delete(String(id)); },
    camToilesVider: () => TOILES.clear(),
    camEtat: () => Object.fromEntries([...CAMI].map(([n, c]) => [n, { w: c.w || 0, h: c.h || 0, fps: 0, age: Date.now() - c.at }])),
    setSurv: () => Promise.resolve(prefs()),
    setPerso: () => Promise.resolve(prefs()),
  };
  flux();
})();
