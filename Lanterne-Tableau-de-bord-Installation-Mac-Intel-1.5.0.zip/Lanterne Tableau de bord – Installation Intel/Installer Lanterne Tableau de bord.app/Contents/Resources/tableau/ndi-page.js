'use strict';
// Lanterne Spectacle · NDI côté page (fichier commun : ppt, infodecor, app), chargé par preload.js.
// Le processus principal envoie et reçoit le NDI (voir ndi.js) ; ici, la page pose ou lit les images dans la mémoire
// partagée qu'il a ouverte, avec le module natif bin/<système>/ndi.node (seules attach / attachW / put / shmFrame servent).
const path = require('path');
let mod = null, err = '';
function module_() {
  if (mod || err) return mod;
  const plat = process.platform === 'darwin' ? 'darwin' : process.platform === 'win32' ? 'win32-x64' : 'linux-x64';
  const dir = process.env.LANTERNE_NDI_DIR || path.join(__dirname, 'bin', plat);
  try { mod = require(path.join(dir, 'ndi.node')); } catch (e) { err = `module NDI refusé dans la page (${e.message})`; }
  return mod;
}
const HANDLES = new Set();
module.exports = {
  erreur: () => { module_(); return err; },
  // réception : ouvrir(nomMémoire) -> poignée ; image(poignée, Uint8Array) -> { w, h, fourcc, ts, rx, n } ou null
  ouvrir(shm) { const m = module_(); if (!m) return -1; const h = m.attach(String(shm)); if (h >= 0) HANDLES.add(h); return h; },
  image(h, buf) { return mod ? mod.shmFrame(h, buf) : null; },
  // envoi : ouvrirEcriture(nomMémoire) -> poignée ; poser(poignée, Uint8Array, largeur, hauteur, 'RGBX' | 'RGBA') -> bool
  ouvrirEcriture(shm) { const m = module_(); if (!m) return -1; const h = m.attachW(String(shm)); if (h >= 0) HANDLES.add(h); return h; },
  poser(h, buf, w, hh, cc) { return mod ? mod.put(h, buf, w, hh, cc || 'RGBX') : false; },
  lacher(h) { if (mod && HANDLES.delete(h)) mod.detach(h); },
  toutLacher() { if (mod) for (const h of [...HANDLES]) { HANDLES.delete(h); try { mod.detach(h); } catch (e) {} } },
};
// page rechargée ou fermée : les mémoires sont rendues
try { window.addEventListener('pagehide', () => module.exports.toutLacher()); } catch (e) {}
