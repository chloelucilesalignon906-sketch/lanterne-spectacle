#!/bin/bash
# Installateur de secours (Lanterne Tableau de bord), quand macOS refuse d'ouvrir « Installer Lanterne Tableau de bord ».
# Utilisation : dans le Terminal, tape « bash » puis une espace, glisse ce fichier dans la fenêtre, Entrée.
D="$(cd "$(dirname "$0")" && pwd)"
CMD="${D}/Installer Lanterne Tableau de bord.app/Contents/Resources/Installer Lanterne Tableau de bord.command"
if [ ! -f "${CMD}" ]; then
  echo "« Installer Lanterne Tableau de bord » est introuvable à côté de ce fichier. Retélécharge le dossier d'installation."
  exit 1
fi
xattr -cr "${D}" 2>/dev/null || true
echo "Installation de Lanterne Tableau de bord dans le Terminal…"
/bin/bash "${CMD}"
RC=$?
echo
[ ${RC} -eq 0 ] && echo "Terminé. Tu peux fermer cette fenêtre." || echo "L'installation s'est arrêtée (code ${RC}). Envoie une capture de cette fenêtre."
exit ${RC}
