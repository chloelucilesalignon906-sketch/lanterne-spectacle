'use strict';
// Lanterne Tableau de bord — une page qui montre tous les logiciels Lanterne ouverts sur le réseau :
// un bloc par ordinateur, une tuile par logiciel (état, charge, vignette de chaque sortie image).
// Onglet « Vue » : lecture seule, sans code (choix d'antoine, 10/11/2026).
// Onglet « Contrôle » (1.1.0) : quelques boutons par logiciel (lecture, stop, noir…), les commandes de FDR, envoyées par la
// liaison du Tableau de bord, sans code (choix d'antoine, 10/11/2026 : seulement pour le Tableau de bord ; suite 2.27.1).
// Installé à part (zips « Lanterne-Tableau-de-bord-Installation-… »), absent de Lanterne Launcher.
// Les logiciels s'annoncent sur le port UDP 7607 (commun/tableau.js) ; le Tableau de bord se connecte au port de
// lecture donné dans l'annonce et s'abonne : {"cmd":"abonner","periode":500,"charge":true|false}.
// Page téléphone (1.4.0) : serveur web sur le port TCP 7612, ouvert par le code QR (clé dans l'adresse) : mêmes onglets Vue
// d'ensemble et Contrôle sur un téléphone du réseau local, sans rien installer. Mises à jour depuis GitHub (1.4.0) comme Banque.
// Tout l'accès au réseau se fait ici, dans le processus principal (règle macOS « Réseau local »).
const { app, BrowserWindow, ipcMain, dialog, Menu, shell, protocol } = require('electron');
const path = require('path');
const fs = require('fs');
const net = require('net');
const os = require('os');
const dgram = require('dgram');
const http = require('http');
const crypto = require('crypto');
const fsp = fs.promises;
const { execFile } = require('child_process');

app.setName('Lanterne Tableau de bord');
const isMac = process.platform === 'darwin', isWin = process.platform === 'win32';
const APP_ICON = isMac ? undefined : path.join(__dirname, 'icon.png');
if (isWin) app.setAppUserModelId('fr.lanterne.tableau');
const fiab = require('./fiabilite')({ app, ipcMain, dialog, gpu: false });
if (!app.requestSingleInstanceLock()) app.exit(0);
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } });

const TABLEAU_PORT = +process.env.LANTERNE_TABLEAU_PORT || 7607;
const PERDU_MS = 7000;   // plus d'annonce ni de liaison depuis 7 s : logiciel perdu (fermé, planté, réseau coupé)
// ordre des logiciels dans un ordinateur (et choix de celui qui mesure la charge de l'ordinateur)
const ORDRE = ['feuille', 'lanterne', 'infodecor', 'ppt', 'cam', 'titrage', 'timer', 'prompteur', 'melangeur', 'recstream', 'son', 'vp'];

/* ---------- fichiers de la page ---------- */
protocol.registerSchemesAsPrivileged([{ scheme: 'lanterne-tableau', privileges: { standard: true, secure: true, supportFetchAPI: true } }]);
const MIME = { html: 'text/html; charset=utf-8', js: 'text/javascript; charset=utf-8', css: 'text/css; charset=utf-8', png: 'image/png', json: 'application/json' };
function setupProtocol() {
  protocol.handle('lanterne-tableau', async (req) => {
    const u = new URL(req.url);
    const p = path.normalize(path.join(__dirname, decodeURIComponent(u.pathname)));
    if (u.host !== 'app' || !p.startsWith(__dirname)) return new Response('Interdit', { status: 403 });
    try {
      const data = await fs.promises.readFile(p);
      return new Response(data, { headers: { 'Content-Type': MIME[path.extname(p).slice(1)] || 'application/octet-stream' } });
    } catch (e) { return new Response('Introuvable', { status: 404 }); }
  });
}

/* ---------- préférences ---------- */
const prefsFile = () => path.join(app.getPath('userData'), 'prefs.json');
let prefs = { periode: 500, taille: 'm', perdus: true, vue: 'vue', titres: {}, ordre: { ordis: [], logs: {} }, tel: true, telCtl: true, telCle: '', telIf: '', majAuto: true };
// ordre choisi à la souris (1.3.0) : ordre.ordis = [id…] ; ordre.logs[id] = [clé du logiciel (app, app#2)…]
// titres donnés dans le Tableau de bord (1.2.0) : clé ordinateur « id », logiciel « id|app », sortie « id|app|n » → texte.
// Gardés ici seulement : les logiciels de la suite ne sont pas renommés.
function loadPrefs() { try { prefs = Object.assign(prefs, JSON.parse(fs.readFileSync(prefsFile(), 'utf8'))); } catch (e) {} if (![500, 1000, 2000].includes(+prefs.periode)) prefs.periode = 500; if (!prefs.titres || typeof prefs.titres !== 'object' || Array.isArray(prefs.titres)) prefs.titres = {}; prefs.ordre = propreOrdre(prefs.ordre); if (!['vue', 'ctl'].includes(prefs.vue)) prefs.vue = 'vue'; if (!/^[A-Za-z0-9_-]{16,64}$/.test(String(prefs.telCle || ''))) { prefs.telCle = nouvelleCle(); savePrefs(); } }
const nouvelleCle = () => crypto.randomBytes(12).toString('base64url');
function propreOrdre(o) {
  const out = { ordis: [], logs: {} };
  if (!o || typeof o !== 'object') return out;
  if (Array.isArray(o.ordis)) out.ordis = [...new Set(o.ordis.map(x => String(x).slice(0, 120)))].slice(0, 100);
  if (o.logs && typeof o.logs === 'object') for (const [k, v] of Object.entries(o.logs).slice(0, 100)) if (Array.isArray(v)) out.logs[String(k).slice(0, 120)] = [...new Set(v.map(x => String(x).slice(0, 40)))].slice(0, 40);
  return out;
}
function savePrefs() { try { fs.mkdirSync(path.dirname(prefsFile()), { recursive: true }); fiab.ecrire(prefsFile(), JSON.stringify(prefs, null, 2)); } catch (e) {} telPrefsChange(); }

/* ---------- logiciels vus ----------
   clé = <id de l'ordinateur>|<clé du logiciel>|<pid> (deux exemplaires d'un logiciel sur un ordinateur restent séparés) */
const LOG = new Map();   // clé -> { cle, id, ordi, app, nom, version, adresse, port, pid, vuAt, sock, relie, etat, vign, perduDepuis, charge }
const CHARGE = new Map();   // id ordinateur -> dernière charge
let win = null;
const toPage = (canal, ...a) => { if (win && !win.isDestroyed()) win.webContents.send(canal, ...a); versTel(canal, a); };
const locales = () => { const s = new Set(['127.0.0.1']); for (const l of Object.values(os.networkInterfaces())) for (const a of l || []) if (a.family === 'IPv4') s.add(a.address); return s; };

function resume(l) {
  return { cle: l.cle, id: l.id, ordi: l.ordi, app: l.app, nom: l.nom, version: l.version, adresse: l.adresse, local: locales().has(l.adresse), pid: l.pid,
    relie: !!l.relie, perduDepuis: l.perduDepuis || 0, fermeA: l.fermeA || 0, silence: !!l.silence, plateforme: l.plateforme || '', sorties: l.nSorties || 0, charge: !!l.chargeDemandee };
}
let pubT = null;
function publier() {
  clearTimeout(pubT);
  pubT = setTimeout(() => toPage('logiciels', [...LOG.values()].map(resume)), 60);
}

// un seul logiciel par ordinateur mesure la charge (processus et carte graphique de toute la suite) : le premier relié dans ORDRE
function choisirCharge() {
  const parOrdi = new Map();
  for (const l of LOG.values()) { if (!l.relie) continue; (parOrdi.get(l.id) || parOrdi.set(l.id, []).get(l.id)).push(l); }
  for (const l of LOG.values()) {
    const liste = parOrdi.get(l.id) || [];
    liste.sort((a, b) => (ORDRE.indexOf(a.app) + 1 || 99) - (ORDRE.indexOf(b.app) + 1 || 99) || a.pid - b.pid);
    const veut = l.relie && liste[0] === l;
    if (veut !== !!l.chargeDemandee) { l.chargeDemandee = veut; abonner(l); }
  }
}
function abonner(l) {
  if (!l.sock || !l.relie) return;
  try { l.sock.write(JSON.stringify({ cmd: 'abonner', periode: +prefs.periode || 500, charge: !!l.chargeDemandee }) + '\n'); } catch (e) {}
}

function relier(l) {
  if (l.sock || !l.port) return;
  const sock = net.connect({ host: l.viaLocal ? '127.0.0.1' : l.adresse, port: l.port });
  l.sock = sock; l.relie = false; l.chargeDemandee = false;
  sock.setNoDelay(true); sock.setEncoding('utf8');
  sock.setTimeout(10000);
  let buf = '';
  sock.on('connect', () => { l.relie = true; l.perduDepuis = 0; l.fermeA = 0; l.cache = 0; abonner(l); choisirCharge(); publier(); });
  sock.on('timeout', () => { try { sock.write('{"cmd":"ping"}\n'); } catch (e) {} if (Date.now() - (l.recuAt || 0) > 20000) sock.destroy(); });
  sock.on('data', d => {
    l.recuAt = Date.now();
    buf += d;
    if (buf.length > 16e6) { buf = ''; sock.destroy(); return; }
    let i;
    while ((i = buf.indexOf('\n')) >= 0) {
      const line = buf.slice(0, i); buf = buf.slice(i + 1);
      if (!line.trim()) continue;
      let m; try { m = JSON.parse(line); } catch (e) { continue; }
      recu(l, m);
    }
  });
  const fin = () => {
    if (l.sock !== sock) return;
    l.sock = null; l.relie = false; l.chargeDemandee = false;
    if (l.cache) { LOG.delete(l.cle); choisirCharge(); publier(); return; }
    if (!l.perduDepuis) l.perduDepuis = Date.now();
    choisirCharge(); publier();
  };
  sock.on('error', fin); sock.on('close', fin);
}
function recu(l, m) {
  switch (m.type) {
    case 'bonjour':
      l.plateforme = String(m.plateforme || ''); if (m.version) l.version = String(m.version).slice(0, 20);
      publier(); break;
    case 'etat':
      l.etat = m.etat || null; l.nSorties = +m.sorties || 0;
      toPage('etat', l.cle, l.etat, l.nSorties); break;
    case 'vignettes':
      {
        const avant = new Map((l.vign || []).map(x => [x.n, x]));
        // {meme: true} : image inchangée, la précédente est gardée
        l.vign = (Array.isArray(m.sorties) ? m.sorties.slice(0, 8) : []).map(x => (x.meme && avant.get(x.n) && avant.get(x.n).jpeg ? Object.assign({}, x, { jpeg: avant.get(x.n).jpeg, w: avant.get(x.n).w, h: avant.get(x.n).h, src: avant.get(x.n).src }) : x));
      }
      l.vignAt = Date.now();
      toPage('vignettes', l.cle, { at: Date.now(), sorties: l.vign }); break;
    case 'commande': { const w = ATTENTE.get(String(m.id || '')); if (w) w.res(m); break; }
    case 'fin':   // fermé normalement : tuile grise quelques minutes ; rendu invisible : retiré
      if (m.raison === 'invisible') { l.cache = Date.now(); } else l.fermeA = Date.now();
      publier(); break;
    case 'charge': {
      const c = { cpu: m.cpu, gpu: m.gpu, cpuAll: m.cpuAll, gpuAll: m.gpuAll, cores: m.cores, apps: Array.isArray(m.apps) ? m.apps.slice(0, 20) : [], at: Date.now() };
      CHARGE.set(l.id, c); toPage('charge', l.id, c); break;
    }
  }
}

/* ---------- écoute des annonces (UDP 7607) ---------- */
let udp = null;
function ecouter() {
  udp = dgram.createSocket({ type: 'udp4', reuseAddr: true });
  udp.on('error', (e) => { fiab.log && fiab.log('udp', String(e && e.message || e)); try { udp.close(); } catch (err) {} udp = null; setTimeout(ecouter, 5000); });
  udp.on('message', (b, ri) => {
    if (b.length > 2000) return;
    let m; try { m = JSON.parse(b.toString('utf8')); } catch (e) { return; }
    if (!m || m.lanterne !== 1 || m.tableau !== 1 || typeof m.app !== 'string' || !(+m.port > 0)) return;
    const id = String(m.id || ri.address).slice(0, 120), pid = +m.pid || 0;
    const cle = `${id}|${m.app}|${pid}`;
    let l = LOG.get(cle);
    const neuf = !l;
    if (!l) { l = { cle, id, app: String(m.app).slice(0, 30), pid }; LOG.set(cle, l); }
    // un logiciel de cet ordinateur s'annonce aussi vers 127.0.0.1 : liaison par 127.0.0.1 (ne dépend pas du Wi-Fi),
    // l'adresse du réseau est gardée pour l'affichage
    const adr = ri.address;
    if (adr === '127.0.0.1') l.viaLocal = true; else l.adresseReseau = adr;
    l.adresse = l.adresseReseau || '127.0.0.1';
    if (l.port !== +m.port) { l.port = +m.port; if (l.sock) { try { l.sock.destroy(); } catch (e) {} l.sock = null; l.relie = false; } }
    l.ordi = String(m.ordi || id).slice(0, 60); l.nom = String(m.nom || m.app).slice(0, 60);
    if (!l.version) l.version = String(m.version || '').slice(0, 20);
    l.vuAt = Date.now();
    // le même logiciel relancé sur le même ordinateur (autre pid) : l'ancien, perdu, est oublié
    for (const [k, o] of LOG) if (k !== cle && o.id === id && o.app === l.app && !o.relie && o.perduDepuis) { LOG.delete(k); publier(); }
    if (!l.sock) relier(l);
    if (neuf) publier();
    else if (l.perduDepuis && l.relie) { l.perduDepuis = 0; publier(); }
  });
  udp.bind(TABLEAU_PORT);
}
// perdus : plus d'annonce depuis 7 s et plus de liaison
setInterval(() => {
  const now = Date.now();
  let ch = false;
  for (const l of LOG.values()) {
    if (!l.relie && !l.perduDepuis && now - (l.vuAt || 0) > PERDU_MS) { l.perduDepuis = now; ch = true; }
    if (l.relie && now - (l.vuAt || 0) > PERDU_MS * 3 && l.sock) { try { l.sock.destroy(); } catch (e) {} }   // plus d'annonce : réseau coupé ?
    const sil = !!l.relie && now - (l.vuAt || 0) > PERDU_MS;   // relié, mais plus d'annonce : réseau coupé dans un sens ?
    if (sil !== !!l.silence) { l.silence = sil; ch = true; }
    // un perdu revient tout seul à la prochaine annonce ; oublié après 1 h, ou tout de suite si « Garder les logiciels perdus » est décoché
    if (l.perduDepuis && ((l.fermeA && now - l.fermeA > 600e3) || now - l.perduDepuis > 3600e3 || (prefs.perdus === false && now - l.perduDepuis > 30e3))) { LOG.delete(l.cle); ch = true; }
  }
  if (ch) publier();
}, 1000);

/* ---------- onglet Contrôle : commandes envoyées par la liaison du Tableau de bord ----------
   {"cmd":"commande","id","msgs"} sur la même connexion que l'abonnement ; commun/tableau.js (suite 2.27.1 ou plus récente)
   les remet au port de contrôle du logiciel par 127.0.0.1. Pas de code (choix d'antoine) : FDR et Companion gardent le leur. */
const ATTENTE = new Map();   // id -> { res, t }
let nId = 0;
function commande(cle, msgs) {
  const l = LOG.get(cle);
  const info = l ? { id: l.id, ordi: l.ordi, nom: l.nom } : {};
  if (!l) return Promise.resolve(Object.assign({ ok: false, raison: 'inconnu' }, info));
  if (l.perduDepuis || !l.sock || !l.relie) return Promise.resolve(Object.assign({ ok: false, raison: 'perdu' }, info));
  msgs = (Array.isArray(msgs) ? msgs : []).slice(0, 12).filter(m => m && typeof m.cmd === 'string');
  if (!msgs.length) return Promise.resolve(Object.assign({ ok: false, raison: 'inconnu' }, info));
  const id = `c${(++nId).toString(36)}${Date.now().toString(36)}`;
  return new Promise(res => {
    // pas de réponse : logiciel d'une suite plus ancienne que 2.27.1 (il ignore la commande) ou réseau coupé
    const t = setTimeout(() => { ATTENTE.delete(id); res(Object.assign({ ok: false, raison: 'ancien' }, info)); }, 3500);
    ATTENTE.set(id, { t, res: r => { clearTimeout(t); ATTENTE.delete(id); res(Object.assign({ ok: !!r.ok, raison: r.raison || '' }, info)); } });
    try { l.sock.write(JSON.stringify({ cmd: 'commande', id, msgs }) + '\n'); } catch (e) { ATTENTE.get(id).res({ ok: false, raison: 'perdu' }); }
  }).then(r => { fiab.log && fiab.log('commande', `${l.nom} (${l.ordi}) ${msgs.map(m => m.cmd).join('+')} : ${r.ok ? 'ok' : r.raison}`); return r; });
}
ipcMain.handle('commande', (_e, cle, msgs) => commande(String(cle || ''), msgs));
// plusieurs logiciels d'un coup (« Tout arrêter ») : [[cle, msgs], …]
ipcMain.handle('commandes', async (_e, liste) => Promise.all((Array.isArray(liste) ? liste : []).slice(0, 60).map(([c, m]) => commande(String(c || ''), m))));

ipcMain.handle('tout', () => ({
  logiciels: [...LOG.values()].map(resume),
  etats: Object.fromEntries([...LOG.values()].map(l => [l.cle, { etat: l.etat || null, n: l.nSorties || 0 }])),
  vignettes: Object.fromEntries([...LOG.values()].filter(l => l.vign).map(l => [l.cle, { at: l.vignAt, sorties: l.vign }])),
  charges: Object.fromEntries(CHARGE),
  ordi: (() => { try { return require('os').hostname(); } catch (e) { return ''; } })(),
}));
ipcMain.handle('prefs', () => prefs);
ipcMain.handle('set-pref', (_e, k, v) => {
  if (k === 'periode' && [500, 1000, 2000].includes(+v)) { prefs.periode = +v; for (const l of LOG.values()) abonner(l); }
  if (k === 'taille' && ['s', 'm', 'l'].includes(v)) prefs.taille = v;
  if (k === 'perdus') prefs.perdus = !!v;
  if (k === 'vue' && ['vue', 'ctl'].includes(v)) prefs.vue = v;
  savePrefs(); buildMenu();
  return prefs;
});
ipcMain.handle('set-titre', (_e, cle, texte) => {
  cle = String(cle || '').slice(0, 200); texte = String(texte || '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, 60);
  if (!cle) return prefs;
  const t = Object.assign({}, prefs.titres);
  if (texte) t[cle] = texte; else delete t[cle];
  if (Object.keys(t).length > 500) return prefs;
  prefs.titres = t; savePrefs();
  return prefs;
});
ipcMain.handle('set-ordre', (_e, o) => { prefs.ordre = propreOrdre(o); savePrefs(); return prefs; });
ipcMain.handle('oublier', (_e, cle) => { const l = LOG.get(cle); if (l && !l.relie) { LOG.delete(cle); publier(); } return true; });

/* ---------- page téléphone (1.4.0) ----------
   Un téléphone (ou une tablette) du réseau local scanne le code QR affiché par le Tableau de bord et ouvre la même page,
   avec les onglets « Vue d'ensemble » et « Contrôle ». Rien à installer ; sur iPhone, Partager › Sur l'écran d'accueil.
   Serveur web ici, dans le processus principal (règle macOS « Réseau local »), port TCP 7612 (7609 : Écran Hall ; 7610-7611 : Banque).
   La clé (prefs.telCle) est dans l'adresse du code QR : sans elle, rien n'est servi. « Nouveau code QR » change la clé et
   coupe les téléphones déjà reliés. Onglet Contrôle sur les téléphones : réglable (prefs.telCtl), refusé côté serveur si décoché.
   Le téléphone ne change ni les réglages, ni les titres, ni l'ordre du Tableau de bord : il les lit.
   /tout et /api/* : JSON ; /flux : flux d'événements (logiciels, etat, vignettes au plus une par seconde et par logiciel, charge, prefs). */
const TEL_PORT = +process.env.LANTERNE_TABLEAU_TEL_PORT || 7612;
const TEL_FICHIERS = new Set(['index.html', 'tel-pont.js', 'qrcode.js', 'icon.png']);
const TEL_MAX = 30;           // téléphones reliés en même temps
const TEL_VIGN_MS = 1000;     // une vignette par seconde et par logiciel au plus (Wi-Fi des téléphones)
const TEL_HEADERS = { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer' };
const TEL_CSP = "default-src 'self' data: blob:; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self' data: blob:";
let telSrv = null, telEtat = 'arrêtée', telLie = '';
const TELS = new Set();       // { res, ip, depuis, vign: Map(cle -> { at, attente, t }) }
let portNoms = {};
function chargerNomsPorts() {
  if (!isMac) return;
  execFile('networksetup', ['-listallhardwareports'], { timeout: 5000 }, (err, out) => {
    if (err) return;
    const n = {}; for (const m of String(out).matchAll(/Hardware Port:\s*(.+)\s*\nDevice:\s*(\S+)/g)) n[m[2]] = m[1].trim();
    portNoms = n; telChange();
  });
}
// réseaux de l'ordinateur (Wi-Fi, Ethernet…) : adresse IPv4 de chacun ; les adresses automatiques (169.254) en dernier
function reseaux() {
  const out = [];
  for (const [nom, list] of Object.entries(os.networkInterfaces())) {
    const a = (list || []).find(x => x.family === 'IPv4' && !x.internal);
    if (a) out.push({ id: nom, label: portNoms[nom] ? `${portNoms[nom]} (${nom})` : nom, adresse: a.address });
  }
  return out.sort((a, b) => (a.adresse.startsWith('169.254.') ? 1 : 0) - (b.adresse.startsWith('169.254.') ? 1 : 0));
}
function telInfo() {
  const nets = reseaux(), choisi = nets.find(n => n.id === prefs.telIf) || nets[0] || null;
  const url = (n) => `http://${n.adresse}:${TEL_PORT}/?k=${prefs.telCle}`;
  return { actif: prefs.tel !== false, ctl: prefs.telCtl !== false, port: TEL_PORT, etat: telEtat, url: choisi ? url(choisi) : '', reseau: choisi ? choisi.id : '',
    reseaux: nets.map(n => ({ id: n.id, label: n.label, adresse: n.adresse, url: url(n) })),
    tels: [...TELS].map(c => ({ ip: c.ip, depuis: c.depuis })) };
}
function telChange() { toPage('tel', telInfo()); }
// un réseau qui arrive ou change d'adresse : le code QR suit
let telSig = '';
setInterval(() => { const s = JSON.stringify(reseaux()); if (s !== telSig) { const premier = !telSig; telSig = s; if (!premier) telChange(); } }, 4000);

const telPrefs = () => ({ titres: prefs.titres, ordre: prefs.ordre, periode: prefs.periode, telCtl: prefs.telCtl !== false });
let telPrefsSig = '';
function telPrefsChange() { const p = telPrefs(), s = JSON.stringify(p); if (s === telPrefsSig) return; telPrefsSig = s; for (const c of TELS) telEcrire(c, 'prefs', p); }
function telEcrire(c, ev, data) {
  try { c.res.write(`event: ${ev}\ndata: ${JSON.stringify(data)}\n\n`); } catch (e) {}
}
// ce que reçoit la page du Tableau de bord, recopié vers les téléphones
function versTel(canal, a) {
  if (!TELS.size) return;
  if (canal === 'logiciels') for (const c of TELS) telEcrire(c, 'logiciels', a[0]);
  else if (canal === 'etat') for (const c of TELS) telEcrire(c, 'etat', { cle: a[0], etat: a[1], n: a[2] });
  else if (canal === 'charge') for (const c of TELS) telEcrire(c, 'charge', { id: a[0], c: a[1] });
  else if (canal === 'vignettes') for (const c of TELS) telVign(c, a[0]);
}
// vignettes : la dernière de chaque logiciel, au plus une par seconde ; rien si le téléphone n'arrive pas à suivre (> 1,5 Mo en attente)
function telVign(c, cle) {
  let v = c.vign.get(cle); if (!v) { v = { at: 0, t: null }; c.vign.set(cle, v); }
  if (v.t) return;
  const envoyer = () => {
    v.t = null; v.at = Date.now();
    const l = LOG.get(cle); if (!l || !l.vign) return;
    if (c.res.writableLength > 1.5e6) return;
    telEcrire(c, 'vignettes', { cle, v: { at: l.vignAt, sorties: l.vign } });
  };
  const reste = TEL_VIGN_MS - (Date.now() - v.at);
  if (reste <= 0) envoyer(); else v.t = setTimeout(envoyer, reste);
}
function telTout() {
  return {
    logiciels: [...LOG.values()].map(resume),
    etats: Object.fromEntries([...LOG.values()].map(l => [l.cle, { etat: l.etat || null, n: l.nSorties || 0 }])),
    vignettes: Object.fromEntries([...LOG.values()].filter(l => l.vign).map(l => [l.cle, { at: l.vignAt, sorties: l.vign }])),
    charges: Object.fromEntries(CHARGE),
    ordi: (() => { try { return os.hostname(); } catch (e) { return ''; } })(),
  };
}
const cleOk = (k) => { const a = Buffer.from(String(k || '')), b = Buffer.from(prefs.telCle); return a.length === b.length && crypto.timingSafeEqual(a, b); };
function lireCorps(req, max) {
  return new Promise((res, rej) => {
    let n = 0; const morceaux = [];
    req.on('data', d => { n += d.length; if (n > max) { rej(new Error('trop gros')); req.destroy(); } else morceaux.push(d); });
    req.on('end', () => { try { res(JSON.parse(Buffer.concat(morceaux).toString('utf8') || 'null')); } catch (e) { rej(e); } });
    req.on('error', rej);
  });
}
const PAGE_CLE = `<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Lanterne Tableau de bord</title>
<style>body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#0f1217;color:#e7e9ef;font:16px/1.5 -apple-system,system-ui,sans-serif;text-align:center;padding:24px;box-sizing:border-box}h1{font-size:20px}p{color:#8d94a6}</style></head>
<body><div><h1>Code QR à scanner de nouveau</h1><p>Cette adresse n’est plus valable (le code QR du Tableau de bord a été changé), ou la page téléphone est désactivée.<br>Sur l’ordinateur : Lanterne Tableau de bord › Téléphone, puis scanne le code QR affiché.</p></div></body></html>`;
function telRequete(req, res) {
  const u = new URL(req.url, 'http://x');
  const json = (code, o) => { res.writeHead(code, Object.assign({ 'Content-Type': 'application/json; charset=utf-8' }, TEL_HEADERS)); res.end(JSON.stringify(o)); };
  const ip = String(req.socket.remoteAddress || '').replace(/^::ffff:/, '');
  // icône de l'écran d'accueil (iPhone) et fichiers de la page : sans clé (rien de privé)
  const fichier = u.pathname === '/' ? 'index.html' : u.pathname === '/apple-touch-icon.png' || u.pathname === '/apple-touch-icon-precomposed.png' ? 'icon.png' : decodeURIComponent(u.pathname.slice(1));
  const estIcone = /^icones\/[a-z]+\.png$/.test(fichier);
  if (req.method === 'GET' && (TEL_FICHIERS.has(fichier) || estIcone)) {
    if (fichier === 'index.html' && !cleOk(u.searchParams.get('k'))) { res.writeHead(403, Object.assign({ 'Content-Type': 'text/html; charset=utf-8' }, TEL_HEADERS)); res.end(PAGE_CLE); return; }
    fs.readFile(path.join(__dirname, fichier), (err, data) => {
      if (err) { res.writeHead(404, TEL_HEADERS); res.end('Introuvable'); return; }
      const ext = path.extname(fichier).slice(1);
      res.writeHead(200, Object.assign({ 'Content-Type': MIME[ext] || 'application/octet-stream' }, TEL_HEADERS, ext === 'html' ? { 'Content-Security-Policy': TEL_CSP } : { 'Cache-Control': 'max-age=3600' }));
      res.end(data);
    });
    return;
  }
  if (!cleOk(u.searchParams.get('k'))) { json(403, { ok: false, raison: 'cle' }); return; }
  if (req.method === 'GET' && u.pathname === '/api/tout') { json(200, telTout()); return; }
  if (req.method === 'GET' && u.pathname === '/api/prefs') { json(200, telPrefs()); return; }
  if (req.method === 'GET' && u.pathname === '/flux') {
    if (TELS.size >= TEL_MAX) { res.writeHead(503, TEL_HEADERS); res.end(); return; }
    res.writeHead(200, Object.assign({ 'Content-Type': 'text/event-stream; charset=utf-8', Connection: 'keep-alive' }, TEL_HEADERS));
    res.write('retry: 2000\n\n');
    req.socket.setNoDelay(true);
    const c = { res, ip, depuis: Date.now(), vign: new Map() };
    TELS.add(c);
    telEcrire(c, 'prefs', telPrefs());
    const fin = () => { if (TELS.delete(c)) { for (const v of c.vign.values()) clearTimeout(v.t); telChange(); } };
    req.on('close', fin); res.on('error', fin);
    telChange();
    return;
  }
  if (req.method === 'POST' && (u.pathname === '/api/commande' || u.pathname === '/api/commandes')) {
    if (prefs.telCtl === false) { json(403, { ok: false, raison: 'telctl' }); return; }
    lireCorps(req, 64 * 1024).then(async (b) => {
      fiab.log && fiab.log('téléphone', `commande depuis ${ip}`);
      if (u.pathname === '/api/commande') json(200, await commande(String(b && b.cle || ''), b && b.msgs));
      else json(200, await Promise.all((Array.isArray(b) ? b : []).slice(0, 60).map(([c, m]) => commande(String(c || ''), m))));
    }).catch(() => json(400, { ok: false, raison: 'inconnu' }));
    return;
  }
  json(404, { ok: false });
}
function telDemarrer() {
  const ancien = telSrv; telSrv = null;
  for (const c of TELS) { try { c.res.end(); } catch (e) {} }
  TELS.clear();
  const suite = () => {
    if (prefs.tel === false) { telEtat = 'désactivée'; telLie = ''; telChange(); buildMenu(); return; }
    telEtat = 'démarrage…';
    const srv = http.createServer(telRequete);
    srv.on('error', (e) => { telEtat = e.code === 'EADDRINUSE' ? `port ${TEL_PORT} déjà utilisé` : `erreur (${e.code || e.message})`; fiab.log && fiab.log('téléphone', telEtat); telChange(); });
    srv.listen(TEL_PORT, '0.0.0.0', () => { telEtat = 'active'; telLie = '0.0.0.0'; telChange(); });
    telSrv = srv;
  };
  if (ancien) { ancien.close(suite); if (ancien.closeAllConnections) ancien.closeAllConnections(); } else suite();
}
// garde les flux ouverts à travers les box et les points d'accès
setInterval(() => { for (const c of TELS) { try { c.res.write(': ping\n\n'); } catch (e) {} } }, 15000);
ipcMain.handle('tel-info', () => telInfo());
ipcMain.handle('tel-set', (_e, k, v) => {
  if (k === 'actif') { prefs.tel = !!v; savePrefs(); telDemarrer(); }
  if (k === 'ctl') { prefs.telCtl = !!v; savePrefs(); }
  if (k === 'reseau') { prefs.telIf = String(v || '').slice(0, 80); savePrefs(); }
  if (k === 'nouvelle-cle') { prefs.telCle = nouvelleCle(); savePrefs(); telDemarrer(); }
  buildMenu(); telChange();
  return telInfo();
});

/* ---------- mises à jour (GitHub, 1.4.0) ----------
   Comme Banque : au lancement (puis toutes les 6 h), lecture de derniere.json dans la branche « tableau-mises-a-jour » du dépôt
   GitHub des mises à jour de Lanterne Spectacle (version, notes, fichier .tableaumaj, zips complets). Plus récente : le fichier
   est téléchargé et vérifié (signature Ed25519 avec la clé de Lanterne Spectacle, type « tableau-maj », empreinte de chaque
   fichier), puis un bandeau la propose. « Mettre à jour » : copie du code actuel (retour possible), écriture dans le Tableau de
   bord installé (Mac : Lanterne Tableau de bord.app/Contents/Resources/app, Info.plist à la nouvelle version, signature locale ;
   Windows : %LOCALAPPDATA%\Programs\Lanterne Tableau de bord\resources\app, DisplayVersion dans HKCU), puis redémarrage.
   Fichier fait par sources/outils/maj-tableau.js, publié par sources/outils/publier-tableau.py. Internet : seulement ici. */
const zlib = require('zlib');
const { net: enet } = require('electron');
const MAJ_CLE = 'MCowBQYDK2VwAyEAcBOKSZdO54+MqE8ytkJMn7t+ipcTpkU4Q+h1pnjiuT4=';
const MAJ_DEPOT = 'chloelucilesalignon906-sketch/lanterne-spectacle';
const MAJ_BRANCHE = 'tableau-mises-a-jour';
const majRaw = () => process.env.TABLEAU_MAJ_RAW || 'https://raw.githubusercontent.com';   // essais : serveur local
const majBase = () => `${majRaw()}/${process.env.TABLEAU_MAJ_DEPOT || MAJ_DEPOT}/${MAJ_BRANCHE}`;
const majPage = () => `https://github.com/${process.env.TABLEAU_MAJ_DEPOT || MAJ_DEPOT}/tree/${MAJ_BRANCHE}`;
const cmpVer = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d > 0 ? 1 : -1; } return 0; };
const shaHex = (b) => crypto.createHash('sha256').update(b).digest('hex');
const majSauveDir = () => path.join(app.getPath('userData'), 'maj-sauvegarde');
const majEnLigneDir = () => path.join(app.getPath('userData'), 'maj-en-ligne');
// dossier du code du Tableau de bord installé (là où la mise à jour écrit) ; null quand il tourne depuis ses sources
function codeDir() {
  const p = app.getAppPath();
  return /[\\/](Contents[\\/]Resources|resources)[\\/]app$/.test(p) ? p : null;
}
const relSur = (r) => typeof r === 'string' && r.length < 300 && !r.startsWith('/') && !/^[A-Za-z]:/.test(r) && !r.split(/[\\/]/).some(x => x === '..' || x === '.' || x === '');
// lit et vérifie un fichier .tableaumaj : { p } ou { erreur }
function lireMaj(file) {
  let d;
  try { if (fs.statSync(file).size > 50e6) return { erreur: 'Fichier trop gros pour une mise à jour du Tableau de bord.' }; d = JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch (e) { return { erreur: 'Fichier de mise à jour illisible.' }; }
  if (!d || d.type !== 'tableau-maj' || typeof d.payload !== 'string' || typeof d.sig !== 'string') return { erreur: 'Ce fichier n’est pas une mise à jour de Lanterne Tableau de bord.' };
  let ok = false;
  try { ok = crypto.verify(null, Buffer.from(d.payload, 'utf8'), crypto.createPublicKey({ key: Buffer.from(MAJ_CLE, 'base64'), format: 'der', type: 'spki' }), Buffer.from(d.sig, 'base64')); } catch (e) {}
  if (!ok) return { erreur: 'Signature refusée : ce fichier n’a pas été fait pour le Tableau de bord, ou il a été modifié. Rien n’est installé.' };
  let q; try { q = JSON.parse(d.payload); } catch (e) { return { erreur: 'Mise à jour abîmée.' }; }
  if (!q || q.type !== 'tableau-maj' || !/^\d+\.\d+\.\d+$/.test(String(q.version || '')) || !q.files || typeof q.files !== 'object' || !q.files['package.json'] || !q.files['main.js']) return { erreur: 'Mise à jour abîmée.' };
  for (const [r, f] of Object.entries(q.files)) if (!relSur(r) || !f || typeof f.gz !== 'string' || !/^[0-9a-f]{64}$/.test(String(f.h))) return { erreur: 'Mise à jour abîmée (fichier refusé).' };
  return { p: q };
}
// une mise à jour faite pour un autre moteur (numéro principal d'Electron) demande le zip complet
const moteurOk = (q) => !q.moteur || String(process.versions.electron || '').split('.')[0] === String(q.moteur).split('.')[0];
const zipDeCetOrdi = (n) => /\.zip$/i.test(n) && (isWin ? /-Windows-/i.test(n) : (isMac && process.arch === 'x64') ? /-Mac-Intel-/i.test(n) : /-Mac-\d/i.test(n));
async function majFetch(url, accept) {
  const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 60000);
  try { return await enet.fetch(url, { headers: { Accept: accept, 'User-Agent': `LanterneTableau/${app.getVersion()}` }, cache: 'no-store', signal: ctl.signal }); }
  finally { clearTimeout(t); }
}
let MAJ = { etat: 'rien' }, majCours = null, majEnCours = false;
async function majChercher() {
  let r;
  try { r = await majFetch(`${majBase()}/derniere.json?t=${Date.now()}`, 'application/json'); } catch (e) { return { etat: 'erreur', erreur: 'Pas de connexion à Internet (ou GitHub ne répond pas).', horsLigne: true }; }
  if (r.status === 404) return { etat: 'erreur', erreur: 'Aucune version du Tableau de bord publiée pour l’instant.' };
  if (!r.ok) return { etat: 'erreur', erreur: `GitHub répond ${r.status}.` };
  let j; try { j = await r.json(); } catch (e) { return { etat: 'erreur', erreur: 'Réponse de GitHub illisible.' }; }
  const version = /^\d+\.\d+\.\d+$/.test(String(j && j.version || '')) ? String(j.version) : '';
  if (!version) return { etat: 'erreur', erreur: 'Annonce de mise à jour illisible.' };
  const res = { version, date: String(j.date || ''), notes: (Array.isArray(j.notes) ? j.notes : []).map(String).filter(Boolean).slice(0, 20) };
  const z = (Array.isArray(j.zips) ? j.zips : []).find(n => typeof n === 'string' && /^[\w.-]+\.zip$/i.test(n) && zipDeCetOrdi(n));
  if (z) res.zip = `${majBase()}/${encodeURIComponent(z)}`;
  if (cmpVer(version, app.getVersion()) <= 0) return Object.assign(res, { etat: 'ajour' });
  res.etat = 'dispo';
  const f = typeof j.maj === 'string' && /^[\w.-]+\.tableaumaj$/i.test(j.maj) ? j.maj : '';
  if (!f) return Object.assign(res, { leger: false, pourquoi: 'Cette version s’installe avec le zip complet.' });
  if (!codeDir()) return Object.assign(res, { leger: false, pourquoi: 'Le Tableau de bord tourne depuis ses sources : installe le zip complet.' });
  const file = path.join(majEnLigneDir(), f);
  try {
    let deja = false; try { const m = lireMaj(file); deja = !m.erreur && m.p.version === version; } catch (e) {}
    if (!deja) {
      const g = await majFetch(`${majBase()}/${encodeURIComponent(f)}`, 'application/octet-stream');
      if (!g.ok) throw new Error(`GitHub répond ${g.status}`);
      const buf = Buffer.from(await g.arrayBuffer());
      if (buf.length > 50e6) throw new Error('fichier trop gros');
      await fsp.mkdir(majEnLigneDir(), { recursive: true });
      fiab.ecrire(file, buf);
      try { for (const n of fs.readdirSync(majEnLigneDir())) if (n !== f && !n.startsWith('.')) fs.rmSync(path.join(majEnLigneDir(), n), { force: true }); } catch (e) {}
    }
  } catch (e) { return Object.assign(res, { leger: false, pourquoi: `La mise à jour n’a pas pu être téléchargée (${e.message || e}).` }); }
  const m = lireMaj(file);
  if (m.erreur) { try { fs.rmSync(file, { force: true }); } catch (e) {} return Object.assign(res, { leger: false, pourquoi: m.erreur }); }
  if (m.p.version !== version) return Object.assign(res, { leger: false, pourquoi: `Le fichier en ligne est la version ${m.p.version}, pas ${version}.` });
  if (!moteurOk(m.p)) return Object.assign(res, { leger: false, pourquoi: `Cette version demande un nouveau moteur (Electron ${m.p.moteur}) : installe le zip complet.` });
  return Object.assign(res, { leger: true, fichier: file });
}
function majRetourInfo() {
  try {
    const d = JSON.parse(fs.readFileSync(path.join(majSauveDir(), 'derniere.json'), 'utf8'));
    return d && d.dir && d.to === app.getVersion() && fs.existsSync(path.join(d.dir, 'sauvegarde.json')) ? { from: d.from, to: d.to, dir: d.dir } : null;
  } catch (e) { return null; }
}
function vueMaj() {
  const r = majRetourInfo();
  return { etat: MAJ.etat, version: MAJ.version || '', date: MAJ.date || '', notes: MAJ.notes || [], leger: !!MAJ.leger, pourquoi: MAJ.pourquoi || '', erreur: MAJ.erreur || '',
    zip: !!MAJ.zip, installee: app.getVersion(), installable: !!codeDir(), auto: prefs.majAuto !== false, at: MAJ.at || 0, retour: r ? r.from : '', enCours: majEnCours };
}
function majVerifier(force) {
  if (majCours) return majCours;
  if (!force && MAJ.at && Date.now() - MAJ.at < 6 * 3600e3 && MAJ.etat !== 'erreur') return Promise.resolve(vueMaj());
  MAJ = Object.assign({}, MAJ, { etat: 'cherche' }); toPage('maj', vueMaj());
  majCours = majChercher().catch(e => ({ etat: 'erreur', erreur: String(e && e.message || e) })).then(r => {
    majCours = null; MAJ = Object.assign({ at: Date.now() }, r);
    if (r.etat === 'erreur' && !r.horsLigne) fiab.log && fiab.log('mise à jour', r.erreur);
    toPage('maj', vueMaj()); return vueMaj();
  });
  return majCours;
}
async function ecrireSur(dst, buf) {
  await fsp.mkdir(path.dirname(dst), { recursive: true });
  const tmp = `${dst}.maj-tmp`;
  await fsp.writeFile(tmp, buf);
  await fsp.rename(tmp, dst);
}
async function remettre(dir, bdir, info) {
  for (const rel of info.added || []) { try { await fsp.rm(path.join(dir, rel), { force: true }); } catch (e) {} }
  for (const rel of info.saved || []) { try { await ecrireSur(path.join(dir, rel), await fsp.readFile(path.join(bdir, rel))); } catch (e) {} }
}
// après l'écriture : Mac, numéro de version de l'app puis signature locale sur place ; Windows, version affichée dans Paramètres
function apresEcriture(dir, version) {
  return new Promise((res) => {
    const fin = (err) => { if (err) fiab.log && fiab.log('mise à jour', String(err.message || err)); res(); };
    if (isMac) {
      const b = dir.split('/Contents/Resources/app')[0], pl = path.join(b, 'Contents', 'Info.plist');
      if (!b.endsWith('.app') || !fs.existsSync(pl)) return res();
      execFile('plutil', ['-replace', 'CFBundleShortVersionString', '-string', version, pl], () =>
        execFile('plutil', ['-replace', 'CFBundleVersion', '-string', version, pl], () =>
          execFile('xattr', ['-cr', b], () => execFile('codesign', ['--force', '--deep', '--sign', '-', b], { timeout: 120000 }, fin))));
    } else if (isWin) execFile('reg', ['add', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\LanterneTableauDeBord', '/v', 'DisplayVersion', '/d', version, '/f'], { windowsHide: true }, () => res());
    else res();
  });
}
// le Tableau de bord redémarre sur sa nouvelle version (essais : TABLEAU_MAJ_SANS_RELANCE, il se ferme seulement)
function redemarrer() {
  setTimeout(() => {
    try { if (telSrv) telSrv.close(); for (const c of TELS) c.res.end(); } catch (e) {}
    if (!process.env.TABLEAU_MAJ_SANS_RELANCE) app.relaunch();
    app.exit(0);
  }, 1500);
}
async function majInstaller() {
  if (majEnCours) return { ok: false, erreur: 'Une mise à jour est déjà en cours.' };
  if (MAJ.etat !== 'dispo' || !MAJ.leger || !MAJ.fichier) return { ok: false, erreur: 'Aucune mise à jour prête à installer.' };
  const dir = codeDir(); if (!dir) return { ok: false, erreur: 'Le Tableau de bord tourne depuis ses sources : installe le zip complet.' };
  const m = lireMaj(MAJ.fichier); if (m.erreur) return { ok: false, erreur: m.erreur };
  const q = m.p;
  if (!moteurOk(q)) return { ok: false, erreur: `Cette version demande un nouveau moteur (Electron ${q.moteur}) : installe le zip complet.` };
  majEnCours = true; toPage('maj', vueMaj());
  const from = app.getVersion(), bdir = path.join(majSauveDir(), `${from}-${new Date().toISOString().replace(/[:.]/g, '-')}`);
  const bufs = {};
  try {
    for (const [rel, f] of Object.entries(q.files)) { const b = zlib.gunzipSync(Buffer.from(f.gz, 'base64')); if (shaHex(b) !== f.h) throw new Error(`empreinte fausse : ${rel}`); bufs[rel] = b; }
  } catch (e) { majEnCours = false; toPage('maj', vueMaj()); return { ok: false, erreur: `Mise à jour abîmée (${e.message}). Rien n’est changé.` }; }
  const info = { from, to: q.version, at: Date.now(), dir, saved: [], added: [] };
  try {
    for (const rel of Object.keys(bufs)) {
      const src = path.join(dir, rel);
      if (fs.existsSync(src)) { await fsp.mkdir(path.dirname(path.join(bdir, rel)), { recursive: true }); await fsp.copyFile(src, path.join(bdir, rel)); info.saved.push(rel); }
      else info.added.push(rel);
    }
    await fsp.mkdir(bdir, { recursive: true });
    await fsp.writeFile(path.join(bdir, 'sauvegarde.json'), JSON.stringify(info));
  } catch (e) { majEnCours = false; toPage('maj', vueMaj()); return { ok: false, erreur: `Copie de la version actuelle impossible (${e.code || e.message}). Rien n’est changé.` }; }
  try {
    for (const [rel, b] of Object.entries(bufs)) await ecrireSur(path.join(dir, rel), b);
    for (const [rel, f] of Object.entries(q.files)) if (shaHex(await fsp.readFile(path.join(dir, rel))) !== f.h) throw new Error(`vérification de ${rel}`);
  } catch (e) {
    await remettre(dir, bdir, info); majEnCours = false; toPage('maj', vueMaj());
    const droit = e && (e.code === 'EACCES' || e.code === 'EPERM');
    return { ok: false, erreur: droit ? `Pas le droit d’écrire dans ${dir} : installe le zip complet. le Tableau de bord reste en ${from}.` : `Mise à jour impossible (${e.message || e}). le Tableau de bord reste en ${from}.` };
  }
  await apresEcriture(dir, q.version);
  try { fiab.ecrire(path.join(majSauveDir(), 'derniere.json'), JSON.stringify({ dir: bdir, from, to: q.version, at: Date.now() })); } catch (e) {}
  fiab.log && fiab.log('mise à jour', `Tableau de bord ${from} → ${q.version}`);
  redemarrer();
  return { ok: true, version: q.version };
}
async function majRetour() {
  const r = majRetourInfo(); if (!r) return { ok: false, erreur: 'Aucune mise à jour à défaire.' };
  let info; try { info = JSON.parse(fs.readFileSync(path.join(r.dir, 'sauvegarde.json'), 'utf8')); } catch (e) { return { ok: false, erreur: 'La copie d’avant la mise à jour est introuvable.' }; }
  const dir = codeDir();
  if (!dir || path.resolve(dir) !== path.resolve(info.dir)) return { ok: false, erreur: 'Le Tableau de bord a été réinstallé depuis : la copie d’avant ne correspond plus.' };
  majEnCours = true;
  await remettre(dir, r.dir, info);
  await apresEcriture(dir, info.from);
  try { fs.rmSync(path.join(majSauveDir(), 'derniere.json'), { force: true }); } catch (e) {}
  fiab.log && fiab.log('mise à jour', `retour de ${info.to} à ${info.from}`);
  redemarrer();
  return { ok: true, version: info.from };
}
ipcMain.handle('maj-etat', () => vueMaj());
ipcMain.handle('maj-chercher', () => majVerifier(true));
ipcMain.handle('maj-installer', () => majInstaller());
ipcMain.handle('maj-retour', () => majRetour());
ipcMain.handle('maj-auto', (_e, v) => { prefs.majAuto = !!v; savePrefs(); return vueMaj(); });
ipcMain.handle('maj-zip', () => { const u = MAJ.zip || majPage(); if (/^https:\/\/(github\.com|raw\.githubusercontent\.com)\//.test(u) || process.env.TABLEAU_MAJ_RAW) shell.openExternal(u); return true; });

/* ---------- fenêtre ---------- */
function createWindow() {
  win = new BrowserWindow({
    width: 1360, height: 860, minWidth: 640, minHeight: 420, backgroundColor: '#0f1217', title: 'Lanterne Tableau de bord', show: false, icon: APP_ICON,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: false, backgroundThrottling: false },
  });
  win.loadURL('lanterne-tableau://app/index.html');
  win.once('ready-to-show', () => win.show());
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e, url) => { e.preventDefault(); if (/^https?:\/\//.test(url)) shell.openExternal(url); });
  fiab.watch(win);
  win.on('closed', () => { win = null; });
}

/* ---------- menus ---------- */
const send = (cmd, arg) => toPage('menu', cmd, arg);
function buildMenu() {
  const per = [[500, '0,5 s'], [1000, '1 s'], [2000, '2 s']];
  const t = [
    ...(isMac ? [{ label: 'Lanterne Tableau de bord', submenu: [
      { label: 'À propos de Lanterne Tableau de bord', role: 'about' }, { label: 'Rechercher une mise à jour…', click: () => send('maj') }, { type: 'separator' },
      { label: 'Masquer Lanterne Tableau de bord', role: 'hide' }, { label: 'Masquer les autres', role: 'hideOthers' }, { label: 'Tout afficher', role: 'unhide' },
      { type: 'separator' }, { label: 'Quitter Lanterne Tableau de bord', role: 'quit' }] }] : []),
    ...(isMac ? [] : [{ label: 'Fichier', submenu: [{ label: 'Quitter', role: 'quit' }] }]),
    { label: 'Affichage', submenu: [
      { label: 'Vue (lecture seule)', type: 'radio', checked: prefs.vue !== 'ctl', accelerator: 'CmdOrCtrl+E', click: () => { prefs.vue = 'vue'; savePrefs(); send('prefs'); } },
      { label: 'Contrôle', type: 'radio', checked: prefs.vue === 'ctl', accelerator: 'CmdOrCtrl+K', click: () => { prefs.vue = 'ctl'; savePrefs(); send('prefs'); } },
      { type: 'separator' },
      ...per.map(([v, n]) => ({ label: `Une image toutes les ${n}`, type: 'radio', checked: +prefs.periode === v, click: () => { prefs.periode = v; savePrefs(); for (const l of LOG.values()) abonner(l); send('prefs'); } })),
      { type: 'separator' },
      { label: 'Petites vignettes', type: 'radio', checked: prefs.taille === 's', accelerator: 'CmdOrCtrl+1', click: () => { prefs.taille = 's'; savePrefs(); send('prefs'); } },
      { label: 'Vignettes moyennes', type: 'radio', checked: prefs.taille === 'm', accelerator: 'CmdOrCtrl+2', click: () => { prefs.taille = 'm'; savePrefs(); send('prefs'); } },
      { label: 'Grandes vignettes', type: 'radio', checked: prefs.taille === 'l', accelerator: 'CmdOrCtrl+3', click: () => { prefs.taille = 'l'; savePrefs(); send('prefs'); } },
      { type: 'separator' },
      { label: 'Remettre les tuiles dans l’ordre d’origine', click: () => { prefs.ordre = { ordis: [], logs: {} }; savePrefs(); send('prefs'); } },
      { type: 'separator' },
      { label: 'Garder les logiciels perdus (en rouge)', type: 'checkbox', checked: prefs.perdus !== false, click: (it) => { prefs.perdus = it.checked; savePrefs(); send('prefs'); } },
      { type: 'separator' },
      { label: 'Plein écran', role: 'togglefullscreen' },
    ] },
    { label: 'Téléphone', submenu: [
      { label: 'Code QR pour un téléphone…', accelerator: 'CmdOrCtrl+T', click: () => send('tel') },
      { type: 'separator' },
      { label: 'Page téléphone active', type: 'checkbox', checked: prefs.tel !== false, click: (it) => { prefs.tel = it.checked; savePrefs(); telDemarrer(); } },
      { label: 'Autoriser l’onglet Contrôle sur les téléphones', type: 'checkbox', checked: prefs.telCtl !== false, click: (it) => { prefs.telCtl = it.checked; savePrefs(); telChange(); } },
      { type: 'separator' },
      { label: 'Nouveau code QR (déconnecte les téléphones)', click: () => { prefs.telCle = nouvelleCle(); savePrefs(); telDemarrer(); send('tel'); } },
    ] },
    { label: 'Fenêtre', submenu: [{ label: 'Réduire', role: 'minimize' }, isMac ? { label: 'Agrandir', role: 'zoom' } : { label: 'Agrandir', click: () => { if (win) (win.isMaximized() ? win.unmaximize() : win.maximize()); } }, { type: 'separator' }, { label: 'Outils de développement', role: 'toggleDevTools', accelerator: 'Alt+CmdOrCtrl+J' }] },
    { label: 'Aide', role: 'help', submenu: [{ label: 'Mode d’emploi de Lanterne Tableau de bord', click: () => send('aide') }, { label: 'Rechercher une mise à jour…', click: () => send('maj') }] },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(t));
}

app.whenReady().then(() => {
  try { app.setAboutPanelOptions({ applicationName: 'Lanterne Tableau de bord', applicationVersion: app.getVersion(), copyright: 'Vue d’ensemble des logiciels Lanterne du réseau, et commandes simples' }); } catch (e) {}
  loadPrefs();
  setupProtocol();
  buildMenu();
  createWindow();
  ecouter();
  chargerNomsPorts();
  telDemarrer();
  setTimeout(() => { if (prefs.majAuto !== false) majVerifier(false); }, 4000);
  setInterval(() => { if (prefs.majAuto !== false) majVerifier(false); }, 6 * 3600e3 + 60e3);
  app.on('activate', () => { if (!win) createWindow(); else win.show(); });
});
app.on('window-all-closed', () => app.quit());
