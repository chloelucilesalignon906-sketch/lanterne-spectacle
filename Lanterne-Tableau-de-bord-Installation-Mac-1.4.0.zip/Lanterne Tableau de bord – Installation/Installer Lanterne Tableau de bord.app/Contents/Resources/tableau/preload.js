'use strict';
// Pont entre la page de Lanterne Tableau de bord et le processus principal (onglet Contrôle : commandes passées au processus principal ;
// page téléphone et mises à jour : 1.4.0). Sur un téléphone, tel-pont.js donne la même chose par le réseau.
const { contextBridge, ipcRenderer } = require('electron');
window.addEventListener('error', e => ipcRenderer.send('fiab-log', 'erreur', `${e.message} (${e.filename}:${e.lineno})`));
window.addEventListener('unhandledrejection', e => ipcRenderer.send('fiab-log', 'promesse', String(e.reason && e.reason.stack || e.reason)));
contextBridge.exposeInMainWorld('lanterneTableau', {
  tout: () => ipcRenderer.invoke('tout'),
  prefs: () => ipcRenderer.invoke('prefs'),
  setPref: (k, v) => ipcRenderer.invoke('set-pref', k, v),
  oublier: (cle) => ipcRenderer.invoke('oublier', cle),
  setTitre: (cle, texte) => ipcRenderer.invoke('set-titre', cle, texte),
  setOrdre: (o) => ipcRenderer.invoke('set-ordre', o),
  commande: (cle, msgs) => ipcRenderer.invoke('commande', cle, msgs),
  commandes: (liste) => ipcRenderer.invoke('commandes', liste),
  onLogiciels: (fn) => ipcRenderer.on('logiciels', (_e, l) => fn(l)),
  onEtat: (fn) => ipcRenderer.on('etat', (_e, cle, st, n) => fn(cle, st, n)),
  onVignettes: (fn) => ipcRenderer.on('vignettes', (_e, cle, v) => fn(cle, v)),
  onCharge: (fn) => ipcRenderer.on('charge', (_e, id, c) => fn(id, c)),
  telInfo: () => ipcRenderer.invoke('tel-info'),
  telSet: (k, v) => ipcRenderer.invoke('tel-set', k, v),
  onTel: (fn) => ipcRenderer.on('tel', (_e, i) => fn(i)),
  majEtat: () => ipcRenderer.invoke('maj-etat'),
  majChercher: () => ipcRenderer.invoke('maj-chercher'),
  majInstaller: () => ipcRenderer.invoke('maj-installer'),
  majRetour: () => ipcRenderer.invoke('maj-retour'),
  majZip: () => ipcRenderer.invoke('maj-zip'),
  majAuto: (v) => ipcRenderer.invoke('maj-auto', v),
  onMaj: (fn) => ipcRenderer.on('maj', (_e, v) => fn(v)),
  onMenu: (fn) => ipcRenderer.on('menu', (_e, cmd, arg) => fn(cmd, arg)),
});
