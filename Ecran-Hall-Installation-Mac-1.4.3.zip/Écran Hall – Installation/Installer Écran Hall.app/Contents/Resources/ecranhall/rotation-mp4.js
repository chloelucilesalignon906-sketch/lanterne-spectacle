'use strict';
// Écran Hall 1.4.3 — rotation d'une vidéo MP4/MOV écrite dans le fichier lui-même (matrice d'affichage de la piste vidéo,
// boîte moov › trak › tkhd), sans réencodage : l'image n'est pas touchée, seul le lecteur la tourne en l'affichant.
// Utile pour les boîtiers Qeedji (Gekkota OS) : leur vidéo est dessinée à part, sous la page, et ignore la rotation CSS.
// angle = degrés dans le sens des aiguilles d'une montre (0, 90, 180, 270), comme rotate() en CSS.
const fs = require('fs');

const CONTENEURS = new Set(['moov', 'trak', 'mdia', 'minf', 'edts', 'udta']);
// matrices 16.16 (a b u / c d v / x y w) : celles qu'écrivent ffmpeg et les appareils pour 0, 90, 180, 270°
const UN = 0x10000, MOINS = -0x10000 >>> 0, W = 0x40000000;
const MATRICES = {
  0: [UN, 0, 0, 0, UN, 0, 0, 0, W],
  90: [0, UN, 0, MOINS, 0, 0, 0, 0, W],
  180: [MOINS, 0, 0, 0, MOINS, 0, 0, 0, W],
  270: [0, MOINS, 0, UN, 0, 0, 0, 0, W],
};

function lireEntete(fd, pos, fin) {
  if (pos + 8 > fin) return null;
  const h = Buffer.alloc(16);
  fs.readSync(fd, h, 0, 16, pos);
  let taille = h.readUInt32BE(0), entete = 8;
  const type = h.toString('latin1', 4, 8);
  if (taille === 1) { taille = Number(h.readBigUInt64BE(8)); entete = 16; }
  else if (taille === 0) taille = fin - pos;
  if (taille < entete || pos + taille > fin) return null;
  return { pos, taille, entete, type };
}
function enfants(fd, debut, fin) {
  const l = [];
  for (let p = debut; p < fin;) { const b = lireEntete(fd, p, fin); if (!b) break; l.push(b); p += b.taille; }
  return l;
}
// positions des matrices des pistes vidéo (hdlr 'vide')
function matricesVideo(fd, taille) {
  const moov = enfants(fd, 0, taille).find(b => b.type === 'moov');
  if (!moov) throw new Error('pas de boîte moov (fichier MP4 incomplet ?)');
  const res = [];
  for (const trak of enfants(fd, moov.pos + moov.entete, moov.pos + moov.taille).filter(b => b.type === 'trak')) {
    const dedans = enfants(fd, trak.pos + trak.entete, trak.pos + trak.taille);
    const tkhd = dedans.find(b => b.type === 'tkhd'), mdia = dedans.find(b => b.type === 'mdia');
    if (!tkhd || !mdia) continue;
    const hdlr = enfants(fd, mdia.pos + mdia.entete, mdia.pos + mdia.taille).find(b => b.type === 'hdlr');
    if (!hdlr) continue;
    const t = Buffer.alloc(4); fs.readSync(fd, t, 0, 4, hdlr.pos + hdlr.entete + 8);
    if (t.toString('latin1') !== 'vide') continue;
    const v = Buffer.alloc(1); fs.readSync(fd, v, 0, 1, tkhd.pos + tkhd.entete);
    // fullbox (4) + dates/piste/durée (20 en version 0, 32 en version 1) + réservé (8) + layer, groupe, volume, réservé (8)
    const off = tkhd.pos + tkhd.entete + 4 + (v[0] === 1 ? 32 : 20) + 16;
    if (off + 36 > tkhd.pos + tkhd.taille) continue;
    res.push(off);
  }
  if (!res.length) throw new Error('pas de piste vidéo');
  return res;
}
const normal = a => ((Math.round(+a / 90) * 90) % 360 + 360) % 360;
// angle déjà écrit dans le fichier (0 si matrice inconnue)
function angleActuel(fd, off) {
  const b = Buffer.alloc(36); fs.readSync(fd, b, 0, 36, off);
  const m = []; for (let i = 0; i < 9; i++) m.push(b.readUInt32BE(i * 4));
  for (const [a, x] of Object.entries(MATRICES)) if (x.slice(0, 4).every((y, i) => y === m[i])) return +a;
  return 0;
}
// copie src → dest avec la vidéo tournée de « angle » en plus de sa rotation d'origine ; renvoie l'angle final écrit
function copierTournee(src, dest, angle) {
  const tmp = dest + '.tmp';
  fs.copyFileSync(src, tmp, fs.constants.COPYFILE_FICLONE);
  const fd = fs.openSync(tmp, 'r+');
  let final = 0;
  try {
    const taille = fs.fstatSync(fd).size;
    for (const off of matricesVideo(fd, taille)) {
      final = normal(angleActuel(fd, off) + normal(angle));
      const b = Buffer.alloc(36); MATRICES[final].forEach((x, i) => b.writeUInt32BE(x >>> 0, i * 4));
      fs.writeSync(fd, b, 0, 36, off);
    }
  } catch (e) { fs.closeSync(fd); fs.rmSync(tmp, { force: true }); throw e; }
  fs.closeSync(fd);
  fs.renameSync(tmp, dest);
  return final;
}
const tournable = f => /\.(mp4|m4v|mov)$/i.test(f);
module.exports = { copierTournee, tournable, normal };
