'use strict';
// Écran Hall — prépare et envoie un diaporama à la télé du hall (boîtier Android TV / Google TV / Fire TV en HDMI,
// appli « Écran Hall » du boîtier), par le réseau local.
//  - choisir un PowerPoint (.pptx) ou des images, le temps par diapo, l'orientation de la télé (verticale ou paysage) ;
//  - les diapos sont transformées en images JPEG par le moteur de Lanterne PPT (copié ici : PowerPoint n'est pas nécessaire) ;
//  - envoi au boîtier, port TCP 7609 (une ligne JSON par message, comme la suite ; octets de l'image après « fichier »).
//    Le boîtier garde le dernier diaporama reçu et le montre en boucle, même quand cet ordinateur est éteint.
//  - les boîtiers s'annoncent toutes les 2 s sur le port UDP 7609 ; on peut aussi en ajouter un par son adresse.
//  - 1.2.0 : boîtiers Qeedji sous Gekkota OS (SMA300…) : envoi direct par WebDAV ou fichier .tar (voir qeedji.js).
//  - 1.4.0 : écrans Samsung Smart Signage (Tizen, sans boîtier) : l'écran ouvre la page http://<cet ordinateur>:7613/<num>/
//    (réglage URL Launcher de l'écran) ; même lecteur que le Qeedji, fichiers gardés ici (voir « écrans Samsung » plus bas).
//    Cet ordinateur doit alors rester allumé, Écran Hall ouvert.
// Logiciel à part (comme Lanterne Tableau de bord) : zips « Ecran-Hall-Installation-… », absent de Lanterne Launcher.
// Tout l'accès au réseau se fait ici, dans le processus principal (règle macOS « Réseau local »).
const { app, BrowserWindow, ipcMain, dialog, Menu, shell, protocol, safeStorage } = require('electron');
const path = require('path');
const fs = require('fs');
const net = require('net');
const os = require('os');
const dgram = require('dgram');
const http = require('http');
const qeedji = require('./qeedji');
const rotMp4 = require('./rotation-mp4');

const NOM = 'Écran Hall';
app.setName(NOM);
// dossiers posés à la main (nom avec accent : sous Linux sans langue UTF-8, Electron rangeait sinon les réglages
// directement dans le dossier des applications ; essais du 17/11/2026)
app.setPath('userData', path.join(app.getPath('appData'), NOM));
app.setAppLogsPath(process.platform === 'darwin' ? path.join(app.getPath('home'), 'Library', 'Logs', NOM) : path.join(app.getPath('userData'), 'logs'));
const isMac = process.platform === 'darwin', isWin = process.platform === 'win32';
const APP_ICON = isMac ? undefined : path.join(__dirname, 'icon.png');
if (isWin) app.setAppUserModelId('fr.lanterne.ecranhall');
const fiab = require('./fiabilite')({ app, ipcMain, dialog, gpu: false });
if (!app.requestSingleInstanceLock()) app.exit(0);
app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.show(); win.focus(); } });

const PORT = +process.env.ECRANHALL_PORT || 7609;
const VERSION = require('./package.json').version;
const PERDU_MS = 7000;   // plus d'annonce depuis 7 s : boîtier éteint ou débranché

/* ---------- préférences ---------- */
const prefsFile = () => path.join(app.getPath('userData'), 'prefs.json');
const REGLAGES = { duree: 8, orientation: 'portrait-droite', ajuste: 'contenir', fond: '#000000', transition: 'fondu', qualite: 'hd', son: false };
let prefs = { source: null, reglages: Object.assign({}, REGLAGES), diapos: {}, ecrans: {}, choisis: [], majAuto: true };
// source = { type: 'ppt', fichier } | { type: 'images', fichiers: [...] } | { type: 'liste', fichiers: [...] } (1.3.0 : PowerPoint, images et vidéos mêlés)
// diapos[n] = { d: secondes, off: true, r: 90|180|270 (vidéo tournée, 1.3.0) } (pour la source en cours) ; ecrans[id] = { nom, ip, code, manuel }
// boîtier Qeedji (1.2.0) : ecrans['qd:<ip>'] = { type: 'qeedji', nom, ip, user, mdpChiffre | mdp }
// écran Samsung (1.4.0) : ecrans['sg:<num>'] = { type: 'samsung', nom, num } ; page http://<cet ordinateur>:7613/<num>/
function loadPrefs() {
  try { Object.assign(prefs, JSON.parse(fs.readFileSync(prefsFile(), 'utf8'))); } catch (e) {}
  prefs.reglages = propresReglages(prefs.reglages);
  if (!prefs.diapos || typeof prefs.diapos !== 'object') prefs.diapos = {};
  if (!prefs.ecrans || typeof prefs.ecrans !== 'object') prefs.ecrans = {};
  if (!Array.isArray(prefs.choisis)) prefs.choisis = [];
}
function propresReglages(r) {
  const o = Object.assign({}, REGLAGES, r || {});
  o.duree = Math.max(1, Math.min(3600, +o.duree || 8));
  if (!['portrait-droite', 'portrait-gauche', 'paysage'].includes(o.orientation)) o.orientation = REGLAGES.orientation;
  if (!['contenir', 'remplir'].includes(o.ajuste)) o.ajuste = 'contenir';
  if (!/^#[0-9a-f]{6}$/i.test(o.fond)) o.fond = '#000000';
  if (!['fondu', 'coupe'].includes(o.transition)) o.transition = 'fondu';
  if (!['hd', '4k'].includes(o.qualite)) o.qualite = 'hd';
  o.son = o.son === true;
  return o;
}
function savePrefs() { try { fs.mkdirSync(path.dirname(prefsFile()), { recursive: true }); fiab.ecrire(prefsFile(), JSON.stringify(prefs, null, 2)); } catch (e) { fiab.log('prefs', fiab.raison(e)); } }

let win = null;
const toPage = (canal, ...a) => { if (win && !win.isDestroyed()) win.webContents.send(canal, ...a); };

/* ---------- fichiers servis à la page et à l'atelier ---------- */
protocol.registerSchemesAsPrivileged([{ scheme: 'ecranhall', privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true, corsEnabled: true } }]);
const MIME = { html: 'text/html; charset=utf-8', js: 'text/javascript; charset=utf-8', css: 'text/css; charset=utf-8', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', svg: 'image/svg+xml', json: 'application/json', xml: 'application/xml', ttf: 'font/ttf', otf: 'font/otf', woff: 'font/woff', woff2: 'font/woff2', emf: 'image/emf', wmf: 'image/wmf', tif: 'image/tiff', tiff: 'image/tiff', bmp: 'image/bmp', webp: 'image/webp', rels: 'application/xml', mp4: 'video/mp4', m4v: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm' };
// 1.3.0 : fichiers acceptés (les vidéos ne sont jamais converties : envoyées telles quelles)
const RE_PPT = /\.pptx$/i, RE_IMG = /\.(jpe?g|png|webp)$/i, RE_VID = /\.(mp4|m4v|mov|webm)$/i;
const elementsDe = src => !src ? [] : src.type === 'ppt' ? [src.fichier] : (src.fichiers || []);
const MAX_VIDEO = 2 * 1024 ** 3;
// 1.4.1 : format d'une vidéo, lu dans ses premiers et derniers Mo (boîte stsd du MP4/MOV) : les boîtiers lisent bien le H.264
// 8 bits (profils Baseline, Main, High) ; HEVC, AV1, ProRes et H.264 10 bits ou 4:2:2 donnent souvent un écran noir.
const CONSEIL_H264 = 'Exporte-la en MP4 H.264 : sur Mac, QuickTime Player › Fichier › Exporter en › 1080p, « Plus compatible (H.264) » ; sur Windows, Clipchamp › Exporter en 1080p.';
function codecVideo(file) {
  try {
    const fd = fs.openSync(file, 'r');
    try {
      const t = fs.fstatSync(fd).size, n = Math.min(t, 8 << 20);
      const a = Buffer.alloc(n); fs.readSync(fd, a, 0, n, 0);
      const b = Buffer.alloc(n); fs.readSync(fd, b, 0, n, Math.max(0, t - n));
      const buf = Buffer.concat([a, b]);
      if (/\.webm$/i.test(file)) return { nom: buf.includes('V_VP9') ? 'VP9' : buf.includes('V_AV1') ? 'AV1' : 'WebM', risque: buf.includes('V_AV1') };
      const i = buf.indexOf('stsd'); if (i < 0) return { nom: 'inconnu', risque: false };
      const z = buf.subarray(i, i + 400);
      const has = c => z.includes(c);
      if (has('hvc1') || has('hev1')) return { nom: 'HEVC (H.265)', risque: true };
      if (has('av01')) return { nom: 'AV1', risque: true };
      if (has('apcn') || has('apch') || has('apcs') || has('apco') || has('ap4h')) return { nom: 'ProRes', risque: true };
      if (has('avc1') || has('avc3')) {
        const j = z.indexOf('avcC'), prof = j >= 0 ? z[j + 5] : 0, niv = j >= 0 ? z[j + 7] : 0;
        const nomP = { 66: 'Baseline', 77: 'Main', 88: 'Extended', 100: 'High', 110: 'High 10 bits', 122: 'High 4:2:2', 244: 'High 4:4:4' }[prof] || (prof ? 'profil ' + prof : '');
        return { nom: `H.264${nomP ? ' ' + nomP : ''}${niv ? ' niveau ' + (niv / 10) : ''}`, risque: prof >= 110 || niv > 52 };
      }
      if (has('mp4v')) return { nom: 'MPEG-4 Part 2', risque: true };
      return { nom: 'inconnu', risque: false };
    } finally { fs.closeSync(fd); }
  } catch (e) { return { nom: 'inconnu', risque: false }; }
}
const dossierDiapo = () => path.join(app.getPath('userData'), 'diapo');          // .pptx décompressé
const dossierConv = () => path.join(app.getPath('userData'), 'conversion');      // images prêtes à envoyer
const pptUser = () => path.join(app.getPath('appData'), 'Lanterne PPT');         // polices importées dans Lanterne PPT (si installé)
const officeFiles = new Set();
const dans = (root, rel) => { const r = path.resolve(root), p = path.resolve(r, rel); return p.startsWith(r + path.sep) ? p : null; };
function route(pathname) {
  let m;
  if ((m = /^\/diapo\/(.+)$/.exec(pathname))) return dans(dossierDiapo(), m[1]);
  if ((m = /^\/conv\/([^/]+)$/.exec(pathname))) return dans(dossierConv(), m[1]);
  if ((m = /^\/convtmp\/([^/]+)$/.exec(pathname))) return dans(dossierConv() + '.tmp', m[1]);
  if ((m = /^\/ppt-polices\/([^/]+)$/.exec(pathname))) return path.join(pptUser(), 'Polices importées', path.basename(m[1]));
  if (pathname.startsWith('/ppt-office/')) { const p = pathname.slice('/ppt-office'.length); return officeFiles.has(p) ? p : null; }
  if (/\/main\.js$/.test(pathname)) return null;
  return dans(__dirname, pathname.replace(/^\/+/, ''));
}
// vidéos : lues par morceaux (Range), sans tout charger en mémoire
async function servirVideo(p, req) {
  const st = await fs.promises.stat(p);
  const type = MIME[path.extname(p).slice(1).toLowerCase()] || 'application/octet-stream', size = st.size;
  const m = /bytes=(\d*)-(\d*)/.exec(req.headers.get('range') || '');
  const { Readable } = require('stream');
  if (m && size > 0) {
    let start, end;
    if (m[1] === '' && m[2] !== '') { start = Math.max(0, size - Number(m[2])); end = size - 1; }
    else { start = Number(m[1] || 0); end = m[2] !== '' ? Math.min(Number(m[2]), size - 1) : size - 1; }
    if (start >= size || start > end) return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${size}` } });
    return new Response(Readable.toWeb(fs.createReadStream(p, { start, end })), { status: 206,
      headers: { 'Content-Type': type, 'Content-Length': String(end - start + 1), 'Content-Range': `bytes ${start}-${end}/${size}`, 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-store' } });
  }
  return new Response(Readable.toWeb(fs.createReadStream(p)), { status: 200, headers: { 'Content-Type': type, 'Content-Length': String(size), 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-store' } });
}
function setupProtocol() {
  let notes = 0;
  const noter = (quoi) => { if (notes++ < 40) fiab.log('fichier', quoi); };
  protocol.handle('ecranhall', async (req) => {
    // 1.2.1 : jamais d'exception ici (elle donnait « Failed to fetch » dans l'atelier) ; les refus sont notés dans le journal
    try {
      const u = new URL(req.url);
      if (u.host !== 'app') return new Response('Interdit', { status: 403 });
      let chemin = u.pathname; try { chemin = decodeURIComponent(u.pathname); } catch (e) {}
      const p = route(chemin);
      if (!p) { noter(`refusé : ${chemin}`); return new Response('Interdit', { status: 403 }); }
      try {
        if (RE_VID.test(p)) return await servirVideo(p, req);
        const data = await fs.promises.readFile(p);
        return new Response(data, { headers: { 'Content-Type': MIME[path.extname(p).slice(1).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-store' } });
      } catch (e) { if (!/^\/(diapo|conv)\//.test(chemin) || !/ENOENT/.test(e.code || '')) noter(`illisible : ${chemin} (${e.code || e.message})`); return new Response('Introuvable', { status: 404 }); }
    } catch (e) { noter(`erreur : ${req.url} (${e.message})`); return new Response('Erreur', { status: 500 }); }
  });
  // messages de la console de l'atelier (pièces illisibles…) dans le journal
  app.on('web-contents-created', (_e, wc) => wc.on('console-message', (ev, level, message) => {
    const m = typeof ev === 'object' && ev && ev.message !== undefined ? ev.message : message;
    const lv = typeof ev === 'object' && ev && ev.level !== undefined ? ev.level : level;
    if ((lv === 'warning' || lv === 'error' || lv >= 2) && notes++ < 80) fiab.log('atelier', String(m).slice(0, 300));
  }));
}

/* ---------- polices pour les diapos (comme le cache-bureau du Launcher) ---------- */
function officeFonts() {
  if (!isMac && !process.env.LANTERNE_OFFICE_FONTS) return [];
  const nomsPolice = require('./noms-police.js');
  const dirs = isMac ? ['Microsoft PowerPoint', 'Microsoft Word', 'Microsoft Excel', 'Microsoft Outlook'].map(a => `/Applications/${a}.app/Contents/Resources/DFonts`) : [];
  if (process.env.LANTERNE_OFFICE_FONTS) dirs.push(process.env.LANTERNE_OFFICE_FONTS);
  let idx = {}; try { idx = JSON.parse(fs.readFileSync(path.join(pptUser(), 'polices-office.json'), 'utf8')) || {}; } catch (e) {}
  // index gardé par Écran Hall aussi (1.2.0) : les polices d'Office ne sont lues qu'une fois
  const monIdx = path.join(app.getPath('userData'), 'polices-office.json');
  let mien = {}; try { mien = JSON.parse(fs.readFileSync(monIdx, 'utf8')) || {}; } catch (e) {}
  const neuf = {};
  const out = [], seen = new Set();
  for (const d of dirs) {
    let files = []; try { files = fs.readdirSync(d); } catch (e) { continue; }
    for (const f of files) {
      if (!/\.(ttf|otf)$/i.test(f) || seen.has(f.toLowerCase())) continue;
      seen.add(f.toLowerCase());
      const p = path.join(d, f);
      let st; try { st = fs.statSync(p); } catch (e) { continue; }
      const k = p + '|' + st.size;
      let face = idx[k] !== undefined ? idx[k] : mien[k];
      if (face === undefined) { try { face = nomsPolice.read(p)[0] || null; } catch (e) { face = null; } }
      neuf[k] = face;
      if (!face || !face.family) continue;
      const q = p.replace(/\\/g, '/'), qq = q.startsWith('/') ? q : '/' + q;
      officeFiles.add(qq);
      const url = 'ecranhall://app/ppt-office' + qq.split('/').map(encodeURIComponent).join('/');
      out.push({ family: face.family, legacy: face.legacy, sub: face.sub, weight: face.weight, italic: face.italic, url });
      if (face.legacy && face.legacy !== face.family) out.push({ family: face.legacy, sub: 'Regular', weight: 400, italic: face.italic, url });
    }
  }
  if (Object.keys(neuf).length && JSON.stringify(neuf) !== JSON.stringify(mien)) { try { fiab.ecrire(monIdx, JSON.stringify(neuf)); } catch (e) {} }
  return out;
}
function importedFonts() {
  let l = []; try { l = JSON.parse(fs.readFileSync(path.join(pptUser(), 'polices.json'), 'utf8')); } catch (e) {}
  const fd = path.join(pptUser(), 'Polices importées');
  return (Array.isArray(l) ? l : []).filter(f => f && f.file && fs.existsSync(path.join(fd, f.file)))
    .map(f => Object.assign({}, f, { url: 'ecranhall://app/ppt-polices/' + encodeURIComponent(f.file) }));
}

/* ---------- conversion : diapos → images JPEG à la taille de l'écran ---------- */
let atelier = null;
function getAtelier() {
  if (atelier && !atelier.isDestroyed()) return Promise.resolve(atelier);
  // 1.2.0 : rendu « hors écran » : sur Mac une fenêtre jamais montrée n'est jamais dessinée et la lecture du PowerPoint
  // pouvait attendre sans fin (essai réel du 23/11/2026, bloqué sur « Lecture du PowerPoint… »)
  atelier = new BrowserWindow({ show: false, paintWhenInitiallyHidden: true, width: 400, height: 300,
    webPreferences: { offscreen: true, contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false } });
  try { atelier.webContents.setFrameRate(10); } catch (e) {}
  atelier.on('closed', () => { atelier = null; });
  return atelier.loadURL('ecranhall://app/atelier.html').then(() => atelier);
}
// chaque étape de l'atelier a un temps maximum : plus jamais d'attente sans fin
const js = (w, code, ms = 120000, quoi = 'l’atelier') => Promise.race([w.webContents.executeJavaScript(code, true),
  new Promise((_r, ko) => setTimeout(() => ko(new Error(`${quoi} ne répond pas (plus de ${Math.round(ms / 1000)} s)`)), ms))]);
const dataUrlToBuf = u => Buffer.from(String(u).split(',')[1] || '', 'base64');
const SKIP = /\.(mp4|m4v|mov|webm|mkv|avi|wmv|mpg|mpeg|mp3|m4a|wav|aac|ogg|wma)$/i;
async function extrairePptx(file) {
  const zip = require('./zip.js');
  const root = dossierDiapo();
  await fs.promises.rm(root, { recursive: true, force: true });
  fs.mkdirSync(root, { recursive: true });
  for (const e of zip.list(file)) {
    if (e.name.endsWith('/') || SKIP.test(e.name)) continue;
    const dest = dans(root, e.name);
    if (dest) await zip.extractEntry(file, e, dest);
  }
}
// taille des images envoyées : celle de l'image vue sur la télé (verticale : 1080 × 1920 ; 4K : 2160 × 3840)
function tailleImage(r) {
  const k = r.qualite === '4k' ? 2 : 1;
  return r.orientation === 'paysage' ? { w: 1920 * k, h: 1080 * k } : { w: 1080 * k, h: 1920 * k };
}
const cleConv = (src, r) => {
  const t = tailleImage(r);
  let sig = '';
  try { const fichiers = elementsDe(src); sig = fichiers.map(f => { const s = fs.statSync(f); return `${f}|${s.size}|${s.mtimeMs}`; }).join(';'); } catch (e) { sig = 'absent'; }
  return JSON.stringify([sig, t.w, t.h, r.ajuste, r.fond]);
};
let conv = null;       // { cle, titre, w, h, diapos: [{ n, f, v, masquee, titre }], polices, at }
let travail = null;    // conversion en cours : { annule }
function lireConv() { try { conv = JSON.parse(fs.readFileSync(path.join(dossierConv(), 'conversion.json'), 'utf8')); } catch (e) { conv = null; } }
const titreSource = src => {
  if (!src) return '';
  const l = elementsDe(src), sans = f => path.basename(f).replace(/\.[^.]+$/, '');
  if (l.length === 1) return sans(l[0]);
  if (src.type === 'images') return `${l.length} images`;
  const ppt = l.filter(f => RE_PPT.test(f)), vid = l.filter(f => RE_VID.test(f)).length, img = l.filter(f => RE_IMG.test(f)).length;
  const reste = [vid ? `${vid} vidéo${vid > 1 ? 's' : ''}` : '', img ? `${img} image${img > 1 ? 's' : ''}` : ''].filter(Boolean).join(', ');
  return ppt.length ? sans(ppt[0]) + (ppt.length > 1 ? ` + ${ppt.length - 1} PowerPoint` : '') + (reste ? ` + ${reste}` : '') : reste;
};

async function convertir(force) {
  const src = prefs.source, r = prefs.reglages;
  if (!src) return { error: 'Choisis d’abord un PowerPoint, des images ou des vidéos.' };
  const cle = cleConv(src, r);
  if (!force && conv && conv.cle === cle && conv.diapos.every(d => fs.existsSync(path.join(dossierConv(), d.f)))) return { ok: true, deja: true };
  if (travail) travail.annule = true;
  const moi = travail = { annule: false };
  const t = tailleImage(r);
  const opt = { w: t.w, h: t.h, fit: r.ajuste === 'remplir' ? 'cover' : 'contain', bg: r.fond };
  const tmp = dossierConv() + '.tmp';
  await fs.promises.rm(tmp, { recursive: true, force: true });
  fs.mkdirSync(tmp, { recursive: true });
  const etat = (texte, k, n) => toPage('conversion', { texte, k, n });
  try {
    const w = await getAtelier();
    const els = elementsDe(src);
    const out = { cle, titre: titreSource(src), w: t.w, h: t.h, diapos: [], polices: [], avert: [], at: Date.now(), type: src.type };
    const plusieurs = els.length > 1;
    let num = 0;                                   // numéro du fichier image / vidéo préparé (001.jpg, 002.mp4…)
    const nomFichier = ext => `${String(++num).padStart(3, '0')}.${ext}`;
    const enregistrer = async (r2, base) => {
      const f = nomFichier('jpg'), v = `v-${f}`;
      await fiab.ecrireAsync(path.join(tmp, f), dataUrlToBuf(r2.jpg));
      await fiab.ecrireAsync(path.join(tmp, v), dataUrlToBuf(r2.vign));
      return Object.assign({ f, v }, base);
    };
    for (let e = 0; e < els.length; e++) {
      if (moi.annule) return { annule: true };
      const file = els[e], nomF = path.basename(file);
      const pre = plusieurs ? `${nomF} (${e + 1} / ${els.length}) · ` : '';
      if (!fs.existsSync(file)) throw new Error('Fichier introuvable : ' + file);
      if (RE_PPT.test(file)) {
        let t0 = Date.now();
        etat(`${pre}Lecture du PowerPoint… (décompression)`, 0, 0);
        await extrairePptx(file);
        fiab.log('conversion', `décompression ${Date.now() - t0} ms`); t0 = Date.now();
        etat(`${pre}Lecture du PowerPoint… (polices)`, 0, 0);
        let bundled = []; try { bundled = JSON.parse(fs.readFileSync(path.join(__dirname, 'fonts', 'index.json'), 'utf8')); } catch (x) {}
        const fonts = { bundled, office: officeFonts(), imported: importedFonts() };
        fiab.log('conversion', `polices Office ${fonts.office.length} en ${Date.now() - t0} ms`); t0 = Date.now();
        etat(`${pre}Lecture du PowerPoint… (diapos)`, 0, 0);
        const o = await js(w, `window.atelier.ouvrir(${JSON.stringify({ fonts, app: 'ecranhall://app/', base: 'ecranhall://app/diapo/' })})`, 180000, 'la lecture du PowerPoint');
        fiab.log('conversion', `lecture ${Date.now() - t0} ms`);
        if (!o || o.error) throw new Error((plusieurs ? nomF + ' : ' : '') + (o && o.error || 'PowerPoint illisible'));
        for (const x of o.polices || []) if (!out.polices.includes(x)) out.polices.push(x);
        out.format = out.format || { W: o.W, H: o.H };
        for (let i = 0; i < o.diapos.length; i++) {
          if (moi.annule) return { annule: true };
          etat(`${pre}Diapo ${i + 1} / ${o.diapos.length}…`, i, o.diapos.length);
          const r2 = await js(w, `window.atelier.diapo(${JSON.stringify(Object.assign({ i }, opt))})`, 90000, `la diapo ${i + 1}`);
          if (!r2 || r2.error) throw new Error(r2 && r2.error || `diapo ${i + 1} impossible à dessiner`);
          out.diapos.push(await enregistrer(r2, { n: src.type === 'ppt' ? (o.diapos[i].n || i + 1) : out.diapos.length + 1, masquee: o.diapos[i].masquee,
            titre: (plusieurs ? `${nomF} · ` : '') + (o.diapos[i].titre || '') }));
        }
        await js(w, 'window.atelier.fermer()');
      } else if (RE_VID.test(file)) {
        // vidéo : copiée telle quelle (clone instantané sur Mac), seule une vignette est fabriquée
        etat(`${pre}Vidéo…`, e, els.length);
        const st = fs.statSync(file);
        if (st.size > MAX_VIDEO) throw new Error(`Vidéo trop lourde (plus de 2 Go) : ${nomF}`);
        const ext = path.extname(file).slice(1).toLowerCase();
        const f = nomFichier(ext), v = `v-${String(num).padStart(3, '0')}.jpg`;
        await fs.promises.copyFile(file, path.join(tmp, f), fs.constants.COPYFILE_FICLONE);
        const r2 = await js(w, `window.atelier.video(${JSON.stringify({ src: 'ecranhall://app/convtmp/' + f })})`, 60000, `la vidéo ${nomF}`);
        await fiab.ecrireAsync(path.join(tmp, v), dataUrlToBuf(r2.vign));
        if (r2.illisible) out.avert.push(`${nomF} : ${r2.illisible} (format conseillé : MP4 H.264)`);
        const cod = codecVideo(file);
        if (cod.risque) out.avert.push(`${nomF} : vidéo en ${cod.nom}, que les boîtiers (Qeedji, Android, écrans Samsung) lisent mal ou pas. ${CONSEIL_H264}`);
        out.diapos.push({ codec: cod.nom, n: src.type === 'ppt' ? 1 : out.diapos.length + 1, f, v, masquee: false, titre: nomF, video: true,
          duree: Math.round((r2.duree || 0) * 10) / 10, vw: r2.vw || 0, vh: r2.vh || 0, taille: st.size });
      } else {
        etat(`Image ${e + 1} / ${els.length}…`, e, els.length);
        const b = await fs.promises.readFile(file);
        if (b.length > 120e6) throw new Error('Image trop lourde : ' + nomF);
        const ext = path.extname(file).slice(1).toLowerCase();
        const mime = ext === 'png' ? 'image/png' : ext === 'webp' ? 'image/webp' : 'image/jpeg';
        const r2 = await js(w, `window.atelier.image(${JSON.stringify(Object.assign({ src: `data:${mime};base64,${b.toString('base64')}` }, opt))})`);
        if (!r2 || r2.error) throw new Error(`${nomF} : ${r2 && r2.error || 'image illisible'}`);
        out.diapos.push(await enregistrer(r2, { n: out.diapos.length + 1, masquee: false, titre: nomF }));
      }
    }
    if (moi.annule) return { annule: true };
    if (!out.diapos.length) throw new Error('Rien à montrer dans ces fichiers.');
    await fiab.ecrireAsync(path.join(tmp, 'conversion.json'), JSON.stringify(out, null, 1));
    // remplace l'ancienne conversion d'un coup
    const old = dossierConv() + '.old';
    await fs.promises.rm(old, { recursive: true, force: true });
    if (fs.existsSync(dossierConv())) fs.renameSync(dossierConv(), old);
    fs.renameSync(tmp, dossierConv());
    await fs.promises.rm(old, { recursive: true, force: true });
    conv = out;
    etat('', 0, 0);
    const nv = out.diapos.filter(d => d.video).length;
    fiab.log('conversion', `${out.titre} : ${out.diapos.length - nv} image(s) ${t.w}×${t.h}${nv ? `, ${nv} vidéo(s)` : ''}${out.avert.length ? ' · ' + out.avert.join(' ; ') : ''}`);
    try { w.destroy(); } catch (e) {}
    return { ok: true };
  } catch (e) {
    etat('', 0, 0);
    if (atelier) { try { atelier.destroy(); } catch (x) {} }
    fiab.log('conversion', String(e && e.message || e));
    return { error: String(e && e.message || e) };
  } finally {
    if (travail === moi) travail = null;
  }
}

/* ---------- écrans du hall : annonces UDP 7609 ---------- */
const VUS = new Map();     // id -> { id, nom, ip, version, n, index, titre, vuAt }
let udp = null;
function demarrerUdp() {
  try {
    udp = dgram.createSocket({ type: 'udp4', reuseAddr: true });
    udp.on('error', e => { fiab.log('udp', String(e.message)); try { udp.close(); } catch (x) {} udp = null; setTimeout(demarrerUdp, 5000); });
    udp.on('message', (b, rinfo) => {
      let m; try { m = JSON.parse(b.toString('utf8')); } catch (e) { return; }
      if (!m || m.type !== 'ecranhall' || !m.id) return;
      const id = String(m.id).slice(0, 40);
      const ip = rinfo.address;
      VUS.set(id, { id, nom: String(m.nom || NOM).slice(0, 60), ip, version: String(m.version || ''), n: +m.n || 0, index: +m.index || 0, titre: String(m.titre || '').slice(0, 120), noir: m.noir === true, pause: m.pause === true, vuAt: Date.now() });
      // un écran ajouté à la main par son adresse prend son vrai identifiant ; de même un boîtier réinstallé
      // (nouvel identifiant, même adresse) reprend le code, le nom et la case cochée de l'ancien
      const muet = k => { const v = VUS.get(k); return !v || Date.now() - v.vuAt > PERDU_MS; };
      for (const [k, e] of Object.entries(prefs.ecrans)) if (k !== id && e.type !== 'qeedji' && e.ip === ip && (k.startsWith('ip:') || muet(k))) { prefs.ecrans[id] = Object.assign({}, e, prefs.ecrans[id] || {}); delete prefs.ecrans[k]; prefs.choisis = prefs.choisis.map(c => c === k ? id : c); savePrefs(); }
      const e = prefs.ecrans[id];
      if (!e || e.ip !== ip || e.nom !== m.nom) { prefs.ecrans[id] = Object.assign({}, e || {}, { ip, nom: String(m.nom || NOM).slice(0, 60) }); savePrefs(); }
      publierEcrans();
    });
    udp.bind(PORT, () => { try { udp.setBroadcast(true); } catch (e) {} chercher(); });
  } catch (e) { fiab.log('udp', String(e.message)); }
}
function diffusions() {
  const l = new Set(['255.255.255.255']);
  for (const arr of Object.values(os.networkInterfaces())) for (const a of arr || []) {
    if (a.family !== 'IPv4' || a.internal || !a.netmask) continue;
    const ip = a.address.split('.').map(Number), mk = a.netmask.split('.').map(Number);
    l.add(ip.map((x, i) => (x | (~mk[i] & 255)) & 255).join('.'));
  }
  return [...l];
}
function chercher() {
  if (!udp) return;
  const b = Buffer.from(JSON.stringify({ type: 'ecranhall_cherche' }));
  for (const a of diffusions()) { try { udp.send(b, PORT, a); } catch (e) {} }
  for (const e of Object.values(prefs.ecrans)) if (e.ip) { try { udp.send(b, PORT, e.ip); } catch (x) {} }
}
function listeEcrans() {
  const now = Date.now();
  return Object.entries(prefs.ecrans).map(([id, e]) => {
    if (e.type === 'samsung') {
      const q = QVUS.get(id) || {}, sv = SVUS.get(e.num) || {};
      const vu = !!sv.vuAt && now - sv.vuAt < SAMSUNG_PERDU_MS;
      return { id, type: 'samsung', nom: e.nom || 'Samsung', ip: sv.ip || '', version: '', enLigne: vu, n: q.n || 0, index: 0, titre: q.titre || '', noir: !!q.noir, pause: !!q.pause,
        ecranHall: !!q.ecranHall, erreur: '', code: true, manuel: true, choisi: prefs.choisis.includes(id), vuAt: sv.vuAt || 0, adresse: adresseSamsung(e.num) };
    }
    if (e.type === 'qeedji') {
      const q = QVUS.get(id) || {};
      return { id, type: 'qeedji', nom: e.nom || 'Qeedji', ip: e.ip, version: '', enLigne: !!q.enLigne, n: q.n || 0, index: 0, titre: q.titre || '', noir: !!q.noir, pause: !!q.pause,
        ecranHall: !!q.ecranHall, erreur: q.erreur || '', mdpRefuse: !!q.mdpRefuse, code: true, manuel: true, choisi: prefs.choisis.includes(id), vuAt: q.vuAt || 0 };
    }
    const v = VUS.get(id);
    const vu = !!v && now - v.vuAt < PERDU_MS;
    return { id, nom: (v && v.nom) || e.nom || NOM, ip: (v && v.ip) || e.ip || '', version: v ? v.version : '', enLigne: vu,
      n: v ? v.n : 0, index: v ? v.index : 0, titre: v ? v.titre : '', noir: !!(v && v.noir), pause: !!(v && v.pause), code: !!e.code, manuel: !!e.manuel, choisi: prefs.choisis.includes(id), vuAt: v ? v.vuAt : 0 };
  }).sort((a, b) => a.nom.localeCompare(b.nom, 'fr') || a.ip.localeCompare(b.ip));
}
let pubT = null;
function publierEcrans() { clearTimeout(pubT); pubT = setTimeout(() => toPage('ecrans', listeEcrans()), 80); }

/* ---------- boîtiers Qeedji (Gekkota OS) : WebDAV http://<ip>/.playout/ (1.2.0) ---------- */
const QVUS = new Map();    // id -> { enLigne, titre, n, noir, ecranHall, erreur, mdpRefuse, vuAt }
// 1.4.0 : un écran Samsung passe par le même code que le Qeedji (son « boîtier » est un dossier de cet ordinateur)
const estQeedji = id => !!(prefs.ecrans[id] && (prefs.ecrans[id].type === 'qeedji' || prefs.ecrans[id].type === 'samsung'));
const estSamsung = id => !!(prefs.ecrans[id] && prefs.ecrans[id].type === 'samsung');
const chiffrer = s => { try { if (safeStorage.isEncryptionAvailable()) return { mdpChiffre: safeStorage.encryptString(s).toString('base64') }; } catch (e) {} return { mdp: s }; };
function liaisonQ(id) {
  const e = prefs.ecrans[id];
  if (e.type === 'samsung') return { dossier: dossierSamsung(e.num), ip: 'cet ordinateur' };
  let mdp = e.mdp || '';
  if (e.mdpChiffre) { try { mdp = safeStorage.decryptString(Buffer.from(e.mdpChiffre, 'base64')); } catch (x) { mdp = ''; } }
  if (!e._c || e._c.user !== (e.user || 'admin') || e._c.mdp !== mdp || e._c.ip !== e.ip) Object.defineProperty(e, '_c', { value: { ip: e.ip, user: e.user || 'admin', mdp, defi: null }, enumerable: false, configurable: true, writable: true });
  return e._c;
}
async function avecQeedji(id, fn) {
  try { return await fn(liaisonQ(id)); }
  catch (err) {
    if (err.code === 'mdp') { QVUS.set(id, Object.assign(QVUS.get(id) || {}, { mdpRefuse: true })); publierEcrans(); return { error: err.message, besoinMdp: true }; }
    return { error: String(err && err.message || err) };
  }
}
let sondeQ = false;
async function sonderQeedji() {
  if (sondeQ) return; sondeQ = true;
  try {
    for (const id of Object.keys(prefs.ecrans).filter(estQeedji)) {
      const avant = QVUS.get(id) || {};
      try { const et = await qeedji.etat(liaisonQ(id)); QVUS.set(id, Object.assign(et, { vuAt: Date.now(), erreur: '', mdpRefuse: false })); }
      catch (err) { QVUS.set(id, { enLigne: err.code === 'mdp', mdpRefuse: err.code === 'mdp', erreur: String(err.message || err), vuAt: err.code === 'mdp' ? Date.now() : avant.vuAt || 0 }); }
    }
  } finally { sondeQ = false; publierEcrans(); }
}
const diaposEnvoyees = () => conv ? conv.diapos.filter(d => !(prefs.diapos[d.n] || {}).off && !(d.masquee && !(prefs.diapos[d.n] || {}).on)) : [];
// 1.4.3 : sur un Qeedji, la vidéo est dessinée à part et ne suit pas la rotation de la page : la rotation (télé verticale
// + ⟳ de la vidéo) est écrite dans une copie du fichier (rotation-mp4.js, sans réencodage), gardée dans <données>/qeedji-rot.
// Suppose la sortie du boîtier en paysage (Sortie › Rotation à 0°), comme conseillé. Pas pour les écrans Samsung (Chromium tourne bien).
const dossierRot = () => path.join(app.getPath('userData'), 'qeedji-rot');
const angleTele = o => o === 'portrait-droite' ? 270 : o === 'portrait-gauche' ? 90 : 0;
const rtDe = n => rotMp4.normal(angleTele(prefs.reglages.orientation) + rotDe(n));
function videoTournee(chemin, rt) {
  if (!rt || !rotMp4.tournable(chemin)) return null;
  const st = fs.statSync(chemin);
  const dest = path.join(dossierRot(), `${qeedji.empreinte(chemin)}-r${rt}${path.extname(chemin).toLowerCase()}`);
  if (fs.existsSync(dest) && fs.statSync(dest).size === st.size) return dest;
  fs.mkdirSync(dossierRot(), { recursive: true });
  try { rotMp4.copierTournee(chemin, dest, rt); return dest; }
  catch (e) { fiab.log('rotation', `${path.basename(chemin)} : ${e.message}`); return null; }
}
function paquetQeedji(etat, cuire) {
  const diapos = diaposEnvoyees();
  if (!diapos.length) throw new Error('Toutes les diapos sont décochées.');
  const gardes = new Set();
  const p = qeedji.paquet({ titre: conv.titre, version: VERSION, reglages: prefs.reglages, etat,
    diapos: diapos.map(d => {
      const chemin = path.join(dossierConv(), d.f), o = { chemin, n: d.n, d: dureeItem(d) };
      if (!d.video) return o;
      Object.assign(o, { video: true, r: rotDe(d.n) });
      if (cuire && rotMp4.tournable(chemin)) {
        const rt = rtDe(d.n), t = videoTournee(chemin, rt);
        if (t) { o.chemin = t; gardes.add(path.basename(t)); }
        if (t || !rt) o.rt = rt;
      }
      return o;
    }) });
  // copies tournées qui ne servent plus : effacées
  try { for (const n of fs.readdirSync(dossierRot())) if (!gardes.has(n)) fs.rmSync(path.join(dossierRot(), n), { force: true }); } catch (e) {}
  return p;
}
async function envoyerQeedji(id, progres) {
  if (!conv || !conv.diapos.length) return { error: 'Rien à envoyer : choisis un PowerPoint, des images ou des vidéos.' };
  return avecQeedji(id, async (c) => {
    progres(0, 'Liaison…');
    const avant = await qeedji.etat(c);   // vérifie l'adresse et le mot de passe avant d'envoyer
    const p = paquetQeedji({ noir: avant.noir, mire: 0, orientation: prefs.reglages.orientation }, !estSamsung(id));
    await qeedji.envoyer(c, p, progres);
    fiab.log('envoi', `${conv.titre} → ${estSamsung(id) ? 'Samsung' : 'Qeedji'} ${(prefs.ecrans[id] || {}).nom || id} (${p.diaporama.diapos.length} éléments, ${(p.taille / 1e6).toFixed(1)} Mo)`);
    sonderQeedji();
    return { ok: true, n: p.diaporama.diapos.length };
  });
}

/* ---------- écrans Samsung Smart Signage (1.4.0) ----------
   L'écran (Tizen, réglage « URL Launcher ») ouvre la page http://<adresse de cet ordinateur>:7613/<num>/ : le lecteur des Qeedji
   (qeedji-lecteur.html), qui relit diaporama.json et etat.json toutes les 3 s. Les fichiers de chaque écran sont gardés dans
   <données>/samsung/<num>/ (écrits par qeedji.js comme sur un boîtier) ; un écran est « en ligne » tant qu'il relit ses fichiers.
   Serveur en lecture seule, sur le réseau local, ici dans le processus principal. */
const PORT_WEB = +process.env.ECRANHALL_WEB_PORT || 7613;
const SAMSUNG_PERDU_MS = 10000;
const SVUS = new Map();   // num -> { vuAt, ip }
const dossierSamsung = num => path.join(app.getPath('userData'), 'samsung', String(num));
function adressesLocales() {
  const l = [];
  for (const [nom, as] of Object.entries(os.networkInterfaces())) for (const a of as || []) {
    if (a.family !== 'IPv4' || a.internal || /^169\.254\./.test(a.address)) continue;
    l.push({ ip: a.address, nom, prive: /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(a.address) });
  }
  // d'abord les adresses de réseau local, et les interfaces filaires / wifi avant les VPN
  return l.sort((a, b) => (b.prive - a.prive) || (/^(utun|tun|tap|ppp|zt|tailscale)/i.test(a.nom) - /^(utun|tun|tap|ppp|zt|tailscale)/i.test(b.nom)));
}
const adresseSamsung = (num, ip) => `http://${ip || (adressesLocales()[0] || {}).ip || '?'}${PORT_WEB === 80 ? '' : ':' + PORT_WEB}/${num}/`;
let web = null, webErreur = '';
function pageAccueil() {
  const l = Object.values(prefs.ecrans).filter(e => e.type === 'samsung').sort((a, b) => a.num - b.num);
  const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  return `<!DOCTYPE html><html lang="fr"><head><meta charset="UTF-8"><title>Écran Hall</title><style>body{margin:0;background:#0f1217;color:#fff;font-family:sans-serif;font-size:2.2em;padding:1.5em}a{color:#7fb3ff;display:block;margin:.6em 0}small{color:#8d94a6}</style></head><body>
<h1>Écran Hall</h1>${l.length ? l.map(e => `<a href="/${e.num}/">${e.num} · ${esc(e.nom || 'Samsung')}</a>`).join('') : '<p>Aucun écran Samsung dans Écran Hall pour l’instant : bouton « + Samsung ».</p>'}
<p><small>Dans l’écran, l’adresse à mettre est celle d’un écran ci-dessus, par exemple ${esc(adresseSamsung(l.length ? l[0].num : 1))}</small></p></body></html>`;
}
function demarrerWeb() {
  const TYPES = { html: 'text/html; charset=utf-8', json: 'application/json; charset=utf-8', jpg: 'image/jpeg', mp4: 'video/mp4', m4v: 'video/mp4', mov: 'video/quicktime', webm: 'video/webm' };
  web = http.createServer((req, res) => {
    const fin = (code, corps, h) => { res.writeHead(code, Object.assign({ 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' }, h || {})); res.end(req.method === 'HEAD' ? undefined : corps); };
    try {
      if (req.method !== 'GET' && req.method !== 'HEAD') return fin(405, 'Lecture seulement');
      const u = new URL(req.url, 'http://x');
      if (u.pathname === '/' || u.pathname === '/index.html') return fin(200, pageAccueil(), { 'Content-Type': TYPES.html });
      const m = /^\/(\d{1,3})(\/([\w.-]*))?$/.exec(u.pathname);
      const e = m && Object.values(prefs.ecrans).find(x => x.type === 'samsung' && String(x.num) === m[1]);
      if (!e) return fin(404, 'Écran inconnu dans Écran Hall');
      if (m[2] === undefined) return fin(302, '', { Location: `/${m[1]}/` });
      const nom = m[3] || 'app.html';
      if (/^(etat|diaporama)\.json$/.test(nom)) SVUS.set(e.num, { vuAt: Date.now(), ip: String(req.socket.remoteAddress || '').replace(/^::ffff:/, '') });
      // le lecteur vient toujours du code d'Écran Hall (à jour après une mise à jour) ; le reste, du dossier de l'écran
      const p = nom === 'app.html' ? path.join(__dirname, 'qeedji-lecteur.html') : path.join(dossierSamsung(e.num), nom);
      if (nom === 'manifest.xml' || /\.tmp$/.test(nom)) return fin(404, 'Introuvable');
      if (nom === 'etat.json') {   // + version du lecteur : la page se recharge d'elle-même après une mise à jour d'Écran Hall
        let o = {}; try { o = JSON.parse(fs.readFileSync(p, 'utf8')); } catch (x) {}
        return fin(200, JSON.stringify(Object.assign(o, { lecteur: VERSION })), { 'Content-Type': TYPES.json });
      }
      fs.stat(p, (err, st) => {
        if (err || !st.isFile()) return fin(404, 'Introuvable');
        const ext = path.extname(nom).slice(1).toLowerCase(), type = TYPES[ext] || 'application/octet-stream';
        const cache = /^(html|json)$/.test(ext) ? 'no-store' : 'max-age=86400';   // images et vidéos : noms uniques
        const size = st.size, r = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || '');
        let start = 0, end = size - 1, code = 200;
        if (r && size > 0) {
          if (r[1] === '' && r[2] !== '') start = Math.max(0, size - Number(r[2]));
          else { start = Number(r[1] || 0); if (r[2] !== '') end = Math.min(Number(r[2]), size - 1); }
          if (start >= size || start > end) return fin(416, '', { 'Content-Range': `bytes */${size}` });
          code = 206;
        }
        const h = { 'Content-Type': type, 'Content-Length': String(end - start + 1), 'Accept-Ranges': 'bytes', 'Cache-Control': cache };
        if (code === 206) h['Content-Range'] = `bytes ${start}-${end}/${size}`;
        res.writeHead(code, h);
        if (req.method === 'HEAD' || size === 0) return res.end();
        const flux = fs.createReadStream(p, { start, end });
        flux.on('error', () => res.destroy());
        res.on('close', () => flux.destroy());
        flux.pipe(res);
      });
    } catch (err) { try { fin(500, 'Erreur'); } catch (x) {} }
  });
  web.on('error', err => {
    webErreur = err.code === 'EADDRINUSE' ? `port ${PORT_WEB} déjà pris sur cet ordinateur` : fiab.raison(err);
    fiab.log('samsung', `serveur : ${webErreur}`);
    try { web.close(); } catch (x) {}
    web = null; setTimeout(demarrerWeb, 10000);
  });
  web.listen(PORT_WEB, '0.0.0.0', () => { webErreur = ''; fiab.log('samsung', `serveur prêt sur le port ${PORT_WEB}`); });
}
ipcMain.handle('ajouter-samsung', (_e, nom) => {
  const pris = new Set(Object.values(prefs.ecrans).filter(e => e.type === 'samsung').map(e => e.num));
  let num = 1; while (pris.has(num)) num++;
  const id = 'sg:' + num;
  prefs.ecrans[id] = { type: 'samsung', num, nom: String(nom || '').trim().slice(0, 40) || 'Samsung ' + num };
  if (!prefs.choisis.includes(id)) prefs.choisis.push(id);
  fs.mkdirSync(dossierSamsung(num), { recursive: true });
  try { fiab.ecrire(path.join(dossierSamsung(num), 'etat.json'), JSON.stringify({ noir: false, mire: 0, orientation: prefs.reglages.orientation })); } catch (e) {}
  savePrefs(); publierEcrans(); sonderQeedji();
  return { ok: true, id, num, adresse: adresseSamsung(num), adresses: adressesLocales().map(a => adresseSamsung(num, a.ip)), erreur: webErreur };
});
ipcMain.handle('adresse-samsung', (_e, id) => {
  const e = prefs.ecrans[id]; if (!e || e.type !== 'samsung') return { error: 'écran inconnu' };
  return { ok: true, num: e.num, adresse: adresseSamsung(e.num), adresses: adressesLocales().map(a => adresseSamsung(e.num, a.ip)), erreur: webErreur };
});

/* ---------- liaison avec un écran (TCP 7609) ---------- */
// ouvre une liaison, dit bonjour avec le code retenu ; fn(l) fait le travail ; la liaison est toujours refermée.
function lier(id) {
  const e = prefs.ecrans[id];
  if (!e || !e.ip) return Promise.reject(new Error('adresse de l’écran inconnue'));
  return new Promise((res, rej) => {
    const s = net.connect({ host: e.ip, port: PORT });
    let buf = '', attente = [], ferme = false;
    const l = {
      s,
      envoyer: (o) => new Promise((ok, ko) => { if (ferme) return ko(new Error('liaison fermée')); s.write(JSON.stringify(o) + '\n', err => err ? ko(err) : ok()); }),
      octets: (b) => new Promise((ok, ko) => { if (ferme) return ko(new Error('liaison fermée')); if (s.write(b)) ok(); else s.once('drain', ok); }),
      reponse: (ms = 20000) => new Promise((ok, ko) => {
        const t = setTimeout(() => { attente = attente.filter(x => x.ok !== ok); ko(new Error('l’écran ne répond pas')); }, ms);
        attente.push({ ok: m => { clearTimeout(t); ok(m); }, ko: err => { clearTimeout(t); ko(err); } });
      }),
      fermer: () => { ferme = true; try { s.end(); s.destroy(); } catch (x) {} },
    };
    const t0 = setTimeout(() => { l.fermer(); rej(new Error(`écran injoignable (${e.ip})`)); }, 6000);
    s.setNoDelay(true);
    s.on('data', d => {
      buf += d.toString('utf8');
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const ligne = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (!ligne) continue;
        let m; try { m = JSON.parse(ligne); } catch (x) { continue; }
        if (m.type === 'pong') continue;
        const w = attente.shift(); if (w) w.ok(m);
      }
    });
    s.on('error', err => { clearTimeout(t0); ferme = true; for (const w of attente.splice(0)) w.ko(err); rej(err); });
    s.on('close', () => { ferme = true; for (const w of attente.splice(0)) w.ko(new Error('liaison coupée par l’écran')); });
    s.on('connect', async () => {
      clearTimeout(t0);
      try {
        await l.envoyer({ type: 'bonjour', code: e.code || '', client: `${NOM} ${VERSION}`, ordinateur: os.hostname() });
        const m = await l.reponse(8000);
        if (m.type === 'bienvenue') { res({ l, etat: m }); return; }
        l.fermer();
        const err = new Error(m.type === 'code_faux' ? 'code faux' : m.type === 'bloque' ? `trop de codes faux : réessaie dans ${m.secondes} s` : 'code demandé');
        err.code = m.type === 'bloque' ? 'bloque' : 'code';
        rej(err);
      } catch (err) { l.fermer(); rej(err); }
    });
  });
}
async function avecEcran(id, fn) {
  let x;
  try { x = await lier(id); } catch (e) { return { error: e.message, besoinCode: e.code === 'code' }; }
  const ping = setInterval(() => x.l.envoyer({ type: 'ping' }).catch(() => {}), 5000);
  try { return await fn(x.l, x.etat); }
  catch (e) { return { error: e.message }; }
  finally { clearInterval(ping); x.l.fermer(); }
}

// envoie la conversion en cours (diapos cochées, avec leur durée) à un écran
async function envoyerA(id, progres) {
  if (!conv || !conv.diapos.length) return { error: 'Rien à envoyer : choisis un PowerPoint, des images ou des vidéos.' };
  const r = prefs.reglages;
  const diapos = diaposEnvoyees();
  if (!diapos.length) return { error: 'Toutes les diapos sont décochées.' };
  const tailles = diapos.map(d => fs.statSync(path.join(dossierConv(), d.f)).size);
  const total = tailles.reduce((a, b) => a + b, 0);
  return avecEcran(id, async (l, et) => {
    // vidéos : appli du boîtier 1.2 ou plus récente (1.3.0)
    if (diapos.some(d => d.video) && versionNum(et && et.version) < 1.2)
      throw new Error(`l’appli du boîtier (${et && et.version || 'ancienne'}) ne lit pas les vidéos : mets-la à jour avec « Boîtier TV › Installer sur le boîtier TV.command »`);
    const idDia = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
    await l.envoyer({ type: 'debut', id: idDia, titre: conv.titre, orientation: r.orientation, ajuste: 'contenir', fond: r.fond, transition: r.transition, son: r.son,
      taille: total, source: prefs.source && prefs.source.type,
      diapos: diapos.map(d => Object.assign({ f: d.f, d: dureeItem(d), n: d.n }, d.video ? { v: 1, r: rotDe(d.n) } : {})) });
    let m = await l.reponse();
    if (m.type !== 'pret') throw new Error(m.texte || 'l’écran refuse le diaporama');
    let fait = 0;
    for (let i = 0; i < diapos.length; i++) {
      const fichier = path.join(dossierConv(), diapos[i].f), quoi = diapos[i].video ? `Vidéo ${diapos[i].titre}` : `Image ${i + 1} / ${diapos.length}`;
      await l.envoyer({ type: 'fichier', nom: diapos[i].f, taille: tailles[i] });
      // par morceaux : une vidéo n'est jamais chargée en entier en mémoire
      for await (const b of fs.createReadStream(fichier, { highWaterMark: 1 << 20 })) {
        await l.octets(b);
        fait += b.length;
        progres(fait / total, quoi);
      }
      m = await l.reponse(diapos[i].video ? 180000 : 60000);
      if (m.type !== 'recu') throw new Error(m.texte || `${quoi} refusée`);
    }
    await l.envoyer({ type: 'fin', ordinateur: os.hostname() });
    m = await l.reponse(30000);
    if (m.type !== 'installe') throw new Error(m.texte || 'l’écran n’a pas pu installer le diaporama');
    fiab.log('envoi', `${conv.titre} → ${(prefs.ecrans[id] || {}).nom || id} (${diapos.length} éléments, ${(total / 1e6).toFixed(1)} Mo)`);
    return { ok: true, n: diapos.length };
  });
}
const versionNum = v => { const m = /^(\d+)\.(\d+)/.exec(String(v || '')); return m ? +m[1] + +m[2] / 10 : 0; };
// vidéo : jouée jusqu'au bout (sa durée sert seulement d'information et de garde-fou au boîtier)
const dureeItem = d => d.video ? Math.max(1, Math.ceil(d.duree || 0)) : dureeDe(d.n);
const rotDe = n => { const x = +(prefs.diapos[n] || {}).r; return [90, 180, 270].includes(x) ? x : 0; };
const dureeDe = n => { const d = (prefs.diapos[n] || {}).d; return d > 0 ? Math.min(3600, d) : prefs.reglages.duree; };

/* ---------- page ---------- */
function etatPage() {
  return { version: VERSION, plateforme: process.platform, port: PORT, source: prefs.source, titre: titreSource(prefs.source), reglages: prefs.reglages, diapos: prefs.diapos,
    conv: conv && prefs.source && conv.cle === cleConv(prefs.source, prefs.reglages) ? conv : null, ecrans: listeEcrans(), occupe: !!travail };
}
ipcMain.handle('etat', () => etatPage());
ipcMain.handle('choisir', async (_e, type) => {
  const r = await dialog.showOpenDialog(win, type === 'images'
    ? { title: 'Images ou vidéos à montrer sur l’écran du hall', properties: ['openFile', 'multiSelections'], filters: [{ name: 'Images et vidéos', extensions: ['jpg', 'jpeg', 'png', 'webp', 'mp4', 'm4v', 'mov', 'webm'] }] }
    : type === 'ajouter'
    ? { title: 'Ajouter à la suite (PowerPoint, images, vidéos)', properties: ['openFile', 'multiSelections'], filters: [{ name: 'PowerPoint, images et vidéos', extensions: ['pptx', 'jpg', 'jpeg', 'png', 'webp', 'mp4', 'm4v', 'mov', 'webm'] }] }
    : { title: 'PowerPoint à montrer sur l’écran du hall', properties: ['openFile'], filters: [{ name: 'PowerPoint', extensions: ['pptx'] }] });
  if (r.canceled || !r.filePaths.length) return null;
  return poserSource(r.filePaths, type === 'ajouter');
});
ipcMain.handle('deposer', (_e, files, ajouter) => poserSource(Array.isArray(files) ? files.map(String) : [], !!ajouter));
// 1.3.0 : un PowerPoint seul, des images seules, ou un mélange PowerPoint / images / vidéos (dans l'ordre des noms, ou à la suite)
function poserSource(files, ajouter) {
  const bons = files.filter(f => RE_PPT.test(f) || RE_IMG.test(f) || RE_VID.test(f));
  if (!bons.length) return { error: 'Choisis un PowerPoint (.pptx), des images (JPEG, PNG) ou des vidéos (MP4, MOV).' };
  const parNom = (a, b) => path.basename(a).localeCompare(path.basename(b), 'fr', { numeric: true });
  const l = (ajouter && prefs.source ? elementsDe(prefs.source).concat(bons) : bons.slice().sort(parNom)).slice(0, 500);
  const src = l.length === 1 && RE_PPT.test(l[0]) ? { type: 'ppt', fichier: l[0] }
    : l.every(f => RE_IMG.test(f)) ? { type: 'images', fichiers: l } : { type: 'liste', fichiers: l };
  const avant = prefs.source;
  const meme = JSON.stringify(src) === JSON.stringify(avant);
  prefs.source = src;
  // ajout à la suite : les réglages des éléments déjà là restent (même numérotation), sauf si on part d'un PowerPoint seul
  if (!meme && !(ajouter && avant && avant.type !== 'ppt')) prefs.diapos = {};
  savePrefs();
  return { ok: true };
}
ipcMain.handle('convertir', (_e, force) => convertir(!!force));
ipcMain.handle('reglages', (_e, r) => { prefs.reglages = propresReglages(Object.assign({}, prefs.reglages, r || {})); savePrefs(); return etatPage(); });
ipcMain.handle('diapo', (_e, n, o) => {
  const k = String(+n);
  const d = Object.assign({}, prefs.diapos[k] || {}, o || {});
  if (!(d.d > 0)) delete d.d; else d.d = Math.max(1, Math.min(3600, +d.d));
  if (!d.off) delete d.off;
  if (!d.on) delete d.on;
  if ([90, 180, 270].includes(+d.r)) d.r = +d.r; else delete d.r;
  if (Object.keys(d).length) prefs.diapos[k] = d; else delete prefs.diapos[k];
  savePrefs();
  return prefs.diapos;
});
ipcMain.handle('toutes-durees', () => { for (const k of Object.keys(prefs.diapos)) { delete prefs.diapos[k].d; if (!Object.keys(prefs.diapos[k]).length) delete prefs.diapos[k]; } savePrefs(); return prefs.diapos; });
ipcMain.handle('choisir-ecran', (_e, id, oui) => { prefs.choisis = prefs.choisis.filter(x => x !== id); if (oui) prefs.choisis.push(id); savePrefs(); publierEcrans(); return true; });
ipcMain.handle('ajouter-ecran', (_e, ip) => {
  ip = String(ip || '').trim();
  if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(ip)) return { error: 'Adresse IP attendue, par exemple 192.168.1.42 (elle s’affiche sur la télé).' };
  if (!Object.values(prefs.ecrans).some(e => e.ip === ip)) prefs.ecrans['ip:' + ip] = { ip, nom: NOM, manuel: true };
  const id = Object.keys(prefs.ecrans).find(k => prefs.ecrans[k].ip === ip);
  if (!prefs.choisis.includes(id)) prefs.choisis.push(id);
  savePrefs(); chercher(); publierEcrans();
  return { ok: true, id };
});
ipcMain.handle('oublier-ecran', (_e, id) => {
  if (estSamsung(id)) { const num = prefs.ecrans[id].num; SVUS.delete(num); QVUS.delete(id); fs.rm(dossierSamsung(num), { recursive: true, force: true }, () => {}); }
  delete prefs.ecrans[id]; VUS.delete(id); prefs.choisis = prefs.choisis.filter(x => x !== id); savePrefs(); publierEcrans(); return true; });
ipcMain.handle('code', (_e, id, code) => { if (!prefs.ecrans[id]) return false; prefs.ecrans[id].code = String(code || '').replace(/\D/g, '').slice(0, 4); savePrefs(); return true; });
ipcMain.handle('envoyer', async () => {
  if (travail) return { error: 'Conversion en cours : attends qu’elle soit finie.' };
  const c = await convertir(false);
  if (c.error) return c;
  const ids = prefs.choisis.filter(id => prefs.ecrans[id]);
  if (!ids.length) return { error: 'Coche au moins un écran (à gauche).' };
  const res = {};
  for (const id of ids) {
    toPage('envoi', { id, k: 0, texte: 'Liaison…' });
    const progres = (k, texte) => toPage('envoi', { id, k, texte });
    res[id] = estQeedji(id) ? await envoyerQeedji(id, progres) : await envoyerA(id, progres);
    toPage('envoi', { id, k: 1, fin: true, ok: !!res[id].ok, texte: res[id].ok ? `Envoyé (${res[id].n} diapos)` : res[id].error });
  }
  publierEcrans();
  return { ok: Object.values(res).every(r => r.ok), res };
});
// réglages sans renvoyer les images : orientation, transition, durées (mêmes diapos que le dernier envoi)
ipcMain.handle('appliquer', async (_e, id) => {
  const r = prefs.reglages;
  if (estQeedji(id)) return avecQeedji(id, c => qeedji.appliquer(c, r, dureeDe, rotDe, estSamsung(id) ? null : rtDe));
  const msg = { type: 'reglages', orientation: r.orientation, transition: r.transition, son: r.son };
  if (conv) {
    const diapos = diaposEnvoyees();
    msg.durees = diapos.map(dureeItem);
    msg.rotations = diapos.map(d => d.video ? rotDe(d.n) : 0);
  }
  return avecEcran(id, async (l) => { await l.envoyer(msg); const m = await l.reponse(); return m.type === 'etat' ? { ok: true, etat: m } : { error: m.texte || 'refusé' }; });
});
ipcMain.handle('test', (_e, id, orientation) => estQeedji(id)
  ? avecQeedji(id, async c => { await qeedji.changerEtat(c, { mire: Date.now(), secondes: 20, orientation: orientation || prefs.reglages.orientation }); return { ok: true }; })
  : avecEcran(id, async (l) => {
  await l.envoyer({ type: 'test', orientation: orientation || prefs.reglages.orientation, secondes: 20 });
  const m = await l.reponse(); return m.type === 'ok' ? { ok: true } : { error: m.texte || 'refusé' };
}));
function commande(id, action, extra) {
  if (estQeedji(id)) {
    // 1.4.1 : pause, lecture, suivante, précédente, diapo choisie (extra.n) : écrites dans etat.json, lues par le lecteur en 3 s au plus
    if (['pause', 'lecture', 'suivante', 'precedente', 'aller'].includes(action)) return avecQeedji(id, async c => {
      const modif = action === 'pause' || action === 'lecture' ? { pause: action === 'pause' }
        : { cmd: { id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6), action, n: extra && +extra.n || 0 } };
      const et = await qeedji.changerEtat(c, modif);
      QVUS.set(id, Object.assign(QVUS.get(id) || {}, { pause: !!et.pause })); publierEcrans();
      return { ok: true, pause: !!et.pause };
    });
    if (action !== 'noir') return Promise.resolve({ error: `commande non disponible sur ${estSamsung(id) ? 'un écran Samsung' : 'un boîtier Qeedji'}` });
    return avecQeedji(id, async c => {
      const on = extra && typeof extra.on === 'boolean' ? extra.on : !(QVUS.get(id) || {}).noir;
      const et = await qeedji.changerEtat(c, { noir: on });
      QVUS.set(id, Object.assign(QVUS.get(id) || {}, { noir: et.noir })); publierEcrans();
      return { ok: true, noir: et.noir };
    });
  }
  return avecEcran(id, async (l) => {
    await l.envoyer(Object.assign({ type: 'cmd', action: String(action) }, extra || {}));
    const m = await l.reponse();
    if (m.type !== 'ok') return { error: m.texte || 'refusé' };
    // écran noir (1.1.0) : l'état revient tout de suite, sans attendre l'annonce suivante
    if (typeof m.noir === 'boolean') { const v = VUS.get(id); if (v) v.noir = m.noir; publierEcrans(); }
    if (action === 'pause' || action === 'lecture') { const v = VUS.get(id); if (v) v.pause = action === 'pause'; publierEcrans(); }
    return { ok: true, noir: m.noir };
  });
}
ipcMain.handle('cmd', (_e, id, action, extra) => commande(id, action, extra));
// 1.4.1 : montrer tout de suite la diapo n (numéro dans Écran Hall) sur les écrans cochés, ou pause / lecture sur tous
ipcMain.handle('montrer-coches', async (_e, n) => {
  const ids = prefs.choisis.filter(id => prefs.ecrans[id]);
  if (!ids.length) return { error: 'Coche au moins un écran (à gauche).' };
  const index = diaposEnvoyees().findIndex(d => d.n === +n);
  if (index < 0) return { error: 'Cette diapo n’est pas dans le diaporama envoyé (décochée ?).' };
  const res = {};
  await Promise.all(ids.map(async id => { res[id] = await commande(id, 'aller', estQeedji(id) ? { n: +n } : { index }); }));
  return { ok: Object.values(res).every(r => r.ok), res };
});
ipcMain.handle('pause-coches', async (_e, on) => {
  const ids = prefs.choisis.filter(id => prefs.ecrans[id]);
  if (!ids.length) return { error: 'Coche au moins un écran (à gauche).' };
  const res = {};
  await Promise.all(ids.map(async id => { res[id] = await commande(id, on ? 'pause' : 'lecture'); }));
  return { ok: Object.values(res).every(r => r.ok), res };
});
// noir (on = true) ou retour à l'image (false) sur tous les écrans cochés, en même temps ; la télé reste allumée
ipcMain.handle('noir-coches', async (_e, on) => {
  const ids = prefs.choisis.filter(id => prefs.ecrans[id]);
  if (!ids.length) return { error: 'Coche au moins un écran (à gauche).' };
  const res = {};
  await Promise.all(ids.map(async id => { res[id] = await commande(id, 'noir', { on: !!on }); }));
  fiab.log('noir', `${on ? 'noir' : 'image'} : ${ids.map(id => (prefs.ecrans[id] || {}).nom || id).join(', ')}`);
  return { ok: Object.values(res).every(r => r.ok), res };
});
ipcMain.handle('renommer', (_e, id, nom) => estQeedji(id)
  ? (prefs.ecrans[id].nom = String(nom || '').slice(0, 40) || (estSamsung(id) ? 'Samsung' : 'Qeedji'), savePrefs(), publierEcrans(), { ok: true })
  : avecEcran(id, async (l) => {
  await l.envoyer({ type: 'nom', nom: String(nom || '').slice(0, 40) });
  const m = await l.reponse();
  if (m.type === 'etat') { prefs.ecrans[id].nom = m.nom; savePrefs(); const v = VUS.get(id); if (v) v.nom = m.nom; publierEcrans(); return { ok: true }; }
  return { error: m.texte || 'refusé' };
}));
ipcMain.handle('infos-ecran', (_e, id) => estQeedji(id) ? avecQeedji(id, async c => ({ ok: true, etat: await qeedji.etat(c) })) : avecEcran(id, async (l, etat) => ({ ok: true, etat })));
ipcMain.handle('ajouter-qeedji', (_e, ip, user, mdp) => {
  ip = String(ip || '').trim();
  if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(ip)) return { error: 'Adresse IP attendue, par exemple 192.168.1.3.' };
  const id = 'qd:' + ip;
  prefs.ecrans[id] = Object.assign({ type: 'qeedji', ip, nom: (prefs.ecrans[id] || {}).nom || 'Qeedji ' + ip, user: String(user || 'admin').trim() || 'admin' }, chiffrer(String(mdp || '')));
  if (!prefs.choisis.includes(id)) prefs.choisis.push(id);
  QVUS.delete(id); savePrefs(); publierEcrans(); sonderQeedji();
  return { ok: true, id };
});
ipcMain.handle('mdp-qeedji', (_e, id, user, mdp) => {
  const e = prefs.ecrans[id]; if (!e || e.type !== 'qeedji') return false;
  delete e.mdp; delete e.mdpChiffre;
  Object.assign(e, { user: String(user || e.user || 'admin').trim() || 'admin' }, chiffrer(String(mdp || '')));
  savePrefs(); sonderQeedji();
  return true;
});
// fichier .tar à glisser dans la console du boîtier (Configuration › App › Dépôt local)
ipcMain.handle('exporter-tar', async () => {
  if (travail) return { error: 'Conversion en cours : attends qu’elle soit finie.' };
  const c = await convertir(false);
  if (c.error) return c;
  let p; try { p = paquetQeedji({ noir: false, mire: 0, orientation: prefs.reglages.orientation }, true); } catch (e) { return { error: e.message }; }
  const nom = `Ecran-Hall-${(conv.titre || 'diaporama').replace(/[^\w\-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 60) || 'diaporama'}.tar`;
  const r = await dialog.showSaveDialog(win, { title: 'Fichier pour le boîtier Qeedji', defaultPath: path.join(app.getPath('desktop'), nom), filters: [{ name: 'Appli Gekkota (.tar)', extensions: ['tar'] }] });
  if (r.canceled || !r.filePath) return { annule: true };
  try { await qeedji.ecrireTarFichier(p, r.filePath); } catch (e) { return { error: 'Écriture impossible : ' + fiab.raison(e) }; }
  fiab.log('tar', `${conv.titre} → ${r.filePath} (${p.diaporama.diapos.length} diapos)`);
  shell.showItemInFolder(r.filePath);
  return { ok: true, fichier: r.filePath, n: p.diaporama.diapos.length };
});
ipcMain.handle('ouvrir-dossier', () => { const l = elementsDe(prefs.source); shell.showItemInFolder(l.length ? l[0] : dossierConv()); return true; });

/* ---------- mises à jour (GitHub, 1.4.0) ----------
   Comme Lanterne Tableau de bord et Banque : au lancement (puis toutes les 6 h), lecture de derniere.json dans la branche
   « ecranhall-mises-a-jour » du dépôt GitHub des mises à jour de Lanterne Spectacle (version, notes, fichier .ecranhallmaj,
   zips complets). Plus récente : le fichier est téléchargé et vérifié (signature Ed25519 avec la clé de Lanterne Spectacle,
   type « ecranhall-maj », empreinte de chaque fichier), puis un bandeau la propose. « Mettre à jour » : copie du code actuel
   (retour possible), écriture dans Écran Hall installé (Mac : Écran Hall.app/Contents/Resources/app, Info.plist à la nouvelle
   version, signature locale ; Windows : %LOCALAPPDATA%\Programs\Écran Hall\resources\app, DisplayVersion dans HKCU), puis
   redémarrage. Le lecteur des boîtiers Qeedji fait partie du code : il part au boîtier au prochain « Envoyer » ;
   les écrans Samsung rechargent leur page d'eux-mêmes (version du lecteur dans etat.json).
   L'appli du boîtier Android ne se met pas à jour ainsi (installation par le Mac).
   Fichier fait par sources/outils/maj/maj-ecranhall.js, publié par sources/outils/maj/publier-ecranhall.py. Internet : seulement ici. */
const zlib = require('zlib');
const crypto = require('crypto');
const fsp = fs.promises;
const { execFile } = require('child_process');
const { net: enet } = require('electron');
const MAJ_CLE = 'MCowBQYDK2VwAyEAcBOKSZdO54+MqE8ytkJMn7t+ipcTpkU4Q+h1pnjiuT4=';
const MAJ_DEPOT = 'chloelucilesalignon906-sketch/lanterne-spectacle';
const MAJ_BRANCHE = 'ecranhall-mises-a-jour';
const majRaw = () => process.env.ECRANHALL_MAJ_RAW || 'https://raw.githubusercontent.com';   // essais : serveur local
const majBase = () => `${majRaw()}/${process.env.ECRANHALL_MAJ_DEPOT || MAJ_DEPOT}/${MAJ_BRANCHE}`;
const majPage = () => `https://github.com/${process.env.ECRANHALL_MAJ_DEPOT || MAJ_DEPOT}/tree/${MAJ_BRANCHE}`;
const cmpVer = (a, b) => { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d > 0 ? 1 : -1; } return 0; };
const shaHex = (b) => crypto.createHash('sha256').update(b).digest('hex');
const majSauveDir = () => path.join(app.getPath('userData'), 'maj-sauvegarde');
const majEnLigneDir = () => path.join(app.getPath('userData'), 'maj-en-ligne');
// dossier du code d'Écran Hall installé (là où la mise à jour écrit) ; null quand il tourne depuis ses sources
function codeDir() {
  const p = app.getAppPath();
  return /[\\/](Contents[\\/]Resources|resources)[\\/]app$/.test(p) ? p : null;
}
const relSur = (r) => typeof r === 'string' && r.length < 300 && !r.startsWith('/') && !/^[A-Za-z]:/.test(r) && !r.split(/[\\/]/).some(x => x === '..' || x === '.' || x === '');
// lit et vérifie un fichier .ecranhallmaj : { p } ou { erreur }
function lireMaj(file) {
  let d;
  try { if (fs.statSync(file).size > 50e6) return { erreur: 'Fichier trop gros pour une mise à jour d’Écran Hall.' }; d = JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch (e) { return { erreur: 'Fichier de mise à jour illisible.' }; }
  if (!d || d.type !== 'ecranhall-maj' || typeof d.payload !== 'string' || typeof d.sig !== 'string') return { erreur: 'Ce fichier n’est pas une mise à jour d’Écran Hall.' };
  let ok = false;
  try { ok = crypto.verify(null, Buffer.from(d.payload, 'utf8'), crypto.createPublicKey({ key: Buffer.from(MAJ_CLE, 'base64'), format: 'der', type: 'spki' }), Buffer.from(d.sig, 'base64')); } catch (e) {}
  if (!ok) return { erreur: 'Signature refusée : ce fichier n’a pas été fait pour Écran Hall, ou il a été modifié. Rien n’est installé.' };
  let q; try { q = JSON.parse(d.payload); } catch (e) { return { erreur: 'Mise à jour abîmée.' }; }
  if (!q || q.type !== 'ecranhall-maj' || !/^\d+\.\d+\.\d+$/.test(String(q.version || '')) || !q.files || typeof q.files !== 'object' || !q.files['package.json'] || !q.files['main.js']) return { erreur: 'Mise à jour abîmée.' };
  for (const [r, f] of Object.entries(q.files)) if (!relSur(r) || !f || typeof f.gz !== 'string' || !/^[0-9a-f]{64}$/.test(String(f.h))) return { erreur: 'Mise à jour abîmée (fichier refusé).' };
  return { p: q };
}
// une mise à jour faite pour un autre moteur (numéro principal d'Electron) demande le zip complet
const moteurOk = (q) => !q.moteur || String(process.versions.electron || '').split('.')[0] === String(q.moteur).split('.')[0];
const zipDeCetOrdi = (n) => /\.zip$/i.test(n) && (isWin ? /-Windows-/i.test(n) : (isMac && process.arch === 'x64') ? /-Mac-Intel-/i.test(n) : /-Mac-\d/i.test(n));
async function majFetch(url, accept) {
  const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 60000);
  try { return await enet.fetch(url, { headers: { Accept: accept, 'User-Agent': `EcranHall/${app.getVersion()}` }, cache: 'no-store', signal: ctl.signal }); }
  finally { clearTimeout(t); }
}
let MAJ = { etat: 'rien' }, majCours = null, majEnCours = false;
async function majChercher() {
  let r;
  try { r = await majFetch(`${majBase()}/derniere.json?t=${Date.now()}`, 'application/json'); } catch (e) { return { etat: 'erreur', erreur: 'Pas de connexion à Internet (ou GitHub ne répond pas).', horsLigne: true }; }
  if (r.status === 404) return { etat: 'erreur', erreur: 'Aucune version d’Écran Hall publiée pour l’instant.' };
  if (!r.ok) return { etat: 'erreur', erreur: `GitHub répond ${r.status}.` };
  let j; try { j = await r.json(); } catch (e) { return { etat: 'erreur', erreur: 'Réponse de GitHub illisible.' }; }
  const version = /^\d+\.\d+\.\d+$/.test(String(j && j.version || '')) ? String(j.version) : '';
  if (!version) return { etat: 'erreur', erreur: 'Annonce de mise à jour illisible.' };
  const res = { version, date: String(j.date || ''), notes: (Array.isArray(j.notes) ? j.notes : []).map(String).filter(Boolean).slice(0, 20) };
  const z = (Array.isArray(j.zips) ? j.zips : []).find(n => typeof n === 'string' && /^[\w.-]+\.zip$/i.test(n) && zipDeCetOrdi(n));
  if (z) res.zip = `${majBase()}/${encodeURIComponent(z)}`;
  if (cmpVer(version, app.getVersion()) <= 0) return Object.assign(res, { etat: 'ajour' });
  res.etat = 'dispo';
  const f = typeof j.maj === 'string' && /^[\w.-]+\.ecranhallmaj$/i.test(j.maj) ? j.maj : '';
  if (!f) return Object.assign(res, { leger: false, pourquoi: 'Cette version s’installe avec le zip complet.' });
  if (!codeDir()) return Object.assign(res, { leger: false, pourquoi: 'Écran Hall tourne depuis ses sources : installe le zip complet.' });
  const file = path.join(majEnLigneDir(), f);
  try {
    let deja = false; try { const m = lireMaj(file); deja = !m.erreur && m.p.version === version; } catch (e) {}
    if (!deja) {
      const g = await majFetch(`${majBase()}/${encodeURIComponent(f)}`, 'application/octet-stream');
      if (!g.ok) throw new Error(`GitHub répond ${g.status}`);
      const buf = Buffer.from(await g.arrayBuffer());
      if (buf.length > 50e6) throw new Error('fichier trop gros');
      await fsp.mkdir(majEnLigneDir(), { recursive: true });
      fiab.ecrire(file, buf);
      try { for (const n of fs.readdirSync(majEnLigneDir())) if (n !== f && !n.startsWith('.')) fs.rmSync(path.join(majEnLigneDir(), n), { force: true }); } catch (e) {}
    }
  } catch (e) { return Object.assign(res, { leger: false, pourquoi: `La mise à jour n’a pas pu être téléchargée (${e.message || e}).` }); }
  const m = lireMaj(file);
  if (m.erreur) { try { fs.rmSync(file, { force: true }); } catch (e) {} return Object.assign(res, { leger: false, pourquoi: m.erreur }); }
  if (m.p.version !== version) return Object.assign(res, { leger: false, pourquoi: `Le fichier en ligne est la version ${m.p.version}, pas ${version}.` });
  if (!moteurOk(m.p)) return Object.assign(res, { leger: false, pourquoi: `Cette version demande un nouveau moteur (Electron ${m.p.moteur}) : installe le zip complet.` });
  return Object.assign(res, { leger: true, fichier: file });
}
function majRetourInfo() {
  try {
    const d = JSON.parse(fs.readFileSync(path.join(majSauveDir(), 'derniere.json'), 'utf8'));
    return d && d.dir && d.to === app.getVersion() && fs.existsSync(path.join(d.dir, 'sauvegarde.json')) ? { from: d.from, to: d.to, dir: d.dir } : null;
  } catch (e) { return null; }
}
function vueMaj() {
  const r = majRetourInfo();
  return { etat: MAJ.etat, version: MAJ.version || '', date: MAJ.date || '', notes: MAJ.notes || [], leger: !!MAJ.leger, pourquoi: MAJ.pourquoi || '', erreur: MAJ.erreur || '',
    zip: !!MAJ.zip, installee: app.getVersion(), installable: !!codeDir(), auto: prefs.majAuto !== false, at: MAJ.at || 0, retour: r ? r.from : '', enCours: majEnCours };
}
function majVerifier(force) {
  if (majCours) return majCours;
  if (!force && MAJ.at && Date.now() - MAJ.at < 6 * 3600e3 && MAJ.etat !== 'erreur') return Promise.resolve(vueMaj());
  MAJ = Object.assign({}, MAJ, { etat: 'cherche' }); toPage('maj', vueMaj());
  majCours = majChercher().catch(e => ({ etat: 'erreur', erreur: String(e && e.message || e) })).then(r => {
    majCours = null; MAJ = Object.assign({ at: Date.now() }, r);
    if (r.etat === 'erreur' && !r.horsLigne) fiab.log && fiab.log('mise à jour', r.erreur);
    toPage('maj', vueMaj()); return vueMaj();
  });
  return majCours;
}
async function ecrireSur(dst, buf) {
  await fsp.mkdir(path.dirname(dst), { recursive: true });
  const tmp = `${dst}.maj-tmp`;
  await fsp.writeFile(tmp, buf);
  try { await fsp.rename(tmp, dst); }
  catch (e) {
    // Windows : un fichier déjà chargé ne peut pas être remplacé, mais peut être renommé :
    // l'ancien est mis de côté (supprimé au lancement suivant), le nouveau prend sa place
    if (!isWin || !['EPERM', 'EBUSY', 'EACCES'].includes(e.code) || !fs.existsSync(dst)) throw e;
    await fsp.rename(dst, `${dst}.ancien-${Date.now()}`);
    await fsp.rename(tmp, dst);
  }
}
// fichiers mis de côté par une mise à jour précédente (Windows) : supprimés quand ils ne servent plus
function nettoyerAnciens() {
  const dir = codeDir(); if (!dir || !isWin) return;
  (function walk(d, prof) {
    let l = []; try { l = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
    for (const n of l) {
      const p = path.join(d, n.name);
      if (n.isDirectory() && prof < 3) walk(p, prof + 1);
      else if (/\.ancien-\d+$/.test(n.name)) try { fs.rmSync(p, { force: true }); } catch (e) {}
    }
  })(dir, 0);
}
async function remettre(dir, bdir, info) {
  for (const rel of info.added || []) { try { await fsp.rm(path.join(dir, rel), { force: true }); } catch (e) {} }
  for (const rel of info.saved || []) { try { await ecrireSur(path.join(dir, rel), await fsp.readFile(path.join(bdir, rel))); } catch (e) {} }
}
// après l'écriture : Mac, numéro de version de l'app puis signature locale sur place ; Windows, version affichée dans Paramètres
function apresEcriture(dir, version) {
  return new Promise((res) => {
    const fin = (err) => { if (err) fiab.log && fiab.log('mise à jour', String(err.message || err)); res(); };
    if (isMac) {
      const b = dir.split('/Contents/Resources/app')[0], pl = path.join(b, 'Contents', 'Info.plist');
      if (!b.endsWith('.app') || !fs.existsSync(pl)) return res();
      execFile('plutil', ['-replace', 'CFBundleShortVersionString', '-string', version, pl], () =>
        execFile('plutil', ['-replace', 'CFBundleVersion', '-string', version, pl], () =>
          execFile('xattr', ['-cr', b], () => execFile('codesign', ['--force', '--deep', '--sign', '-', b], { timeout: 120000 }, fin))));
    } else if (isWin) execFile('reg', ['add', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\LanterneEcranHall', '/v', 'DisplayVersion', '/d', version, '/f'], { windowsHide: true }, () => res());
    else res();
  });
}
// Écran Hall redémarre sur sa nouvelle version (essais : ECRANHALL_MAJ_SANS_RELANCE, il se ferme seulement)
function redemarrer() {
  setTimeout(() => {
    try { if (udp) udp.close(); } catch (e) {}
    if (!process.env.ECRANHALL_MAJ_SANS_RELANCE) app.relaunch();
    app.exit(0);
  }, 1500);
}
async function majInstaller() {
  if (majEnCours) return { ok: false, erreur: 'Une mise à jour est déjà en cours.' };
  if (MAJ.etat !== 'dispo' || !MAJ.leger || !MAJ.fichier) return { ok: false, erreur: 'Aucune mise à jour prête à installer.' };
  const dir = codeDir(); if (!dir) return { ok: false, erreur: 'Écran Hall tourne depuis ses sources : installe le zip complet.' };
  const m = lireMaj(MAJ.fichier); if (m.erreur) return { ok: false, erreur: m.erreur };
  const q = m.p;
  if (!moteurOk(q)) return { ok: false, erreur: `Cette version demande un nouveau moteur (Electron ${q.moteur}) : installe le zip complet.` };
  majEnCours = true; toPage('maj', vueMaj());
  const from = app.getVersion(), bdir = path.join(majSauveDir(), `${from}-${new Date().toISOString().replace(/[:.]/g, '-')}`);
  const bufs = {};
  try {
    for (const [rel, f] of Object.entries(q.files)) { const b = zlib.gunzipSync(Buffer.from(f.gz, 'base64')); if (shaHex(b) !== f.h) throw new Error(`empreinte fausse : ${rel}`); bufs[rel] = b; }
  } catch (e) { majEnCours = false; toPage('maj', vueMaj()); return { ok: false, erreur: `Mise à jour abîmée (${e.message}). Rien n’est changé.` }; }
  const info = { from, to: q.version, at: Date.now(), dir, saved: [], added: [] };
  try {
    for (const rel of Object.keys(bufs)) {
      const src = path.join(dir, rel);
      if (fs.existsSync(src)) { await fsp.mkdir(path.dirname(path.join(bdir, rel)), { recursive: true }); await fsp.copyFile(src, path.join(bdir, rel)); info.saved.push(rel); }
      else info.added.push(rel);
    }
    await fsp.mkdir(bdir, { recursive: true });
    await fsp.writeFile(path.join(bdir, 'sauvegarde.json'), JSON.stringify(info));
  } catch (e) { majEnCours = false; toPage('maj', vueMaj()); return { ok: false, erreur: `Copie de la version actuelle impossible (${e.code || e.message}). Rien n’est changé.` }; }
  try {
    for (const [rel, b] of Object.entries(bufs)) await ecrireSur(path.join(dir, rel), b);
    for (const [rel, f] of Object.entries(q.files)) if (shaHex(await fsp.readFile(path.join(dir, rel))) !== f.h) throw new Error(`vérification de ${rel}`);
  } catch (e) {
    await remettre(dir, bdir, info); majEnCours = false; toPage('maj', vueMaj());
    const droit = e && (e.code === 'EACCES' || e.code === 'EPERM');
    return { ok: false, erreur: droit ? `Pas le droit d’écrire dans ${dir} : installe le zip complet. Écran Hall reste en ${from}.` : `Mise à jour impossible (${e.message || e}). Écran Hall reste en ${from}.` };
  }
  await apresEcriture(dir, q.version);
  try { fiab.ecrire(path.join(majSauveDir(), 'derniere.json'), JSON.stringify({ dir: bdir, from, to: q.version, at: Date.now() })); } catch (e) {}
  fiab.log && fiab.log('mise à jour', `Écran Hall ${from} → ${q.version}`);
  redemarrer();
  return { ok: true, version: q.version };
}
async function majRetour() {
  const r = majRetourInfo(); if (!r) return { ok: false, erreur: 'Aucune mise à jour à défaire.' };
  let info; try { info = JSON.parse(fs.readFileSync(path.join(r.dir, 'sauvegarde.json'), 'utf8')); } catch (e) { return { ok: false, erreur: 'La copie d’avant la mise à jour est introuvable.' }; }
  const dir = codeDir();
  if (!dir || path.resolve(dir) !== path.resolve(info.dir)) return { ok: false, erreur: 'Écran Hall a été réinstallé depuis : la copie d’avant ne correspond plus.' };
  majEnCours = true;
  await remettre(dir, r.dir, info);
  await apresEcriture(dir, info.from);
  try { fs.rmSync(path.join(majSauveDir(), 'derniere.json'), { force: true }); } catch (e) {}
  fiab.log && fiab.log('mise à jour', `retour de ${info.to} à ${info.from}`);
  redemarrer();
  return { ok: true, version: info.from };
}
ipcMain.handle('maj-etat', () => vueMaj());
ipcMain.handle('maj-chercher', () => majVerifier(true));
ipcMain.handle('maj-installer', () => majInstaller());
ipcMain.handle('maj-retour', () => majRetour());
ipcMain.handle('maj-auto', (_e, v) => { prefs.majAuto = !!v; savePrefs(); return vueMaj(); });
ipcMain.handle('maj-zip', () => { const u = MAJ.zip || majPage(); if (/^https:\/\/(github\.com|raw\.githubusercontent\.com)\//.test(u) || process.env.ECRANHALL_MAJ_RAW) shell.openExternal(u); return true; });

/* ---------- fenêtre et menus ---------- */
function createWindow() {
  win = new BrowserWindow({
    width: 1180, height: 780, minWidth: 820, minHeight: 560, backgroundColor: '#0f1217', title: NOM, show: false, icon: APP_ICON,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: false },
  });
  win.loadURL('ecranhall://app/index.html');
  win.once('ready-to-show', () => win.show());
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (e, url) => { e.preventDefault(); if (/^https?:\/\//.test(url)) shell.openExternal(url); });
  fiab.watch(win);
  win.on('closed', () => { win = null; app.quit(); });
}
function buildMenu() {
  const t = [
    ...(isMac ? [{ label: NOM, submenu: [
      { label: `À propos d’${NOM}`, role: 'about' }, { label: 'Rechercher une mise à jour…', click: () => toPage('menu', 'maj') }, { type: 'separator' },
      { label: `Masquer ${NOM}`, role: 'hide' }, { label: 'Masquer les autres', role: 'hideOthers' }, { label: 'Tout afficher', role: 'unhide' },
      { type: 'separator' }, { label: `Quitter ${NOM}`, role: 'quit' }] }] : []),
    { label: 'Fichier', submenu: [
      { label: 'Choisir un PowerPoint…', accelerator: 'CmdOrCtrl+O', click: () => toPage('menu', 'ppt') },
      { label: 'Choisir des images ou des vidéos…', accelerator: 'Shift+CmdOrCtrl+O', click: () => toPage('menu', 'images') },
      { label: 'Ajouter à la suite…', accelerator: 'Alt+CmdOrCtrl+O', click: () => toPage('menu', 'ajouter-fichiers') },
      { type: 'separator' },
      { label: 'Envoyer aux écrans cochés', accelerator: 'CmdOrCtrl+Return', click: () => toPage('menu', 'envoyer') },
      { label: 'Noir sur les écrans cochés', accelerator: 'CmdOrCtrl+B', click: () => toPage('menu', 'noir') },
      { label: 'Retour à l’image sur les écrans cochés', accelerator: 'Shift+CmdOrCtrl+B', click: () => toPage('menu', 'image') },
      { label: 'Pause / reprise sur les écrans cochés', accelerator: 'CmdOrCtrl+P', click: () => toPage('menu', 'pause') },
      { type: 'separator' },
      { label: 'Ajouter un écran par son adresse…', click: () => toPage('menu', 'ajouter') },
      { label: 'Ajouter un boîtier Qeedji…', click: () => toPage('menu', 'qeedji') },
      { label: 'Ajouter un écran Samsung…', click: () => toPage('menu', 'samsung') },
      { label: 'Exporter pour un boîtier Qeedji (.tar)…', click: () => toPage('menu', 'tar') },
      { label: 'Chercher les écrans du réseau', accelerator: 'CmdOrCtrl+R', click: () => { chercher(); sonderQeedji(); publierEcrans(); } },
      ...(isMac ? [] : [{ type: 'separator' }, { label: 'Quitter', role: 'quit' }])] },
    { label: 'Édition', submenu: [{ role: 'undo', label: 'Annuler' }, { role: 'redo', label: 'Rétablir' }, { type: 'separator' }, { role: 'cut', label: 'Couper' }, { role: 'copy', label: 'Copier' }, { role: 'paste', label: 'Coller' }, { role: 'selectAll', label: 'Tout sélectionner' }] },
    { label: 'Aide', submenu: [
      { label: 'Installer l’appli sur le boîtier TV…', click: () => toPage('menu', 'aide') },
      { label: 'Boîtier Qeedji (Gekkota OS)…', click: () => toPage('menu', 'aide-qeedji') },
      { label: 'Écran Samsung (sans boîtier)…', click: () => toPage('menu', 'aide-samsung') },
      { label: 'Rechercher une mise à jour…', click: () => toPage('menu', 'maj') },
      { label: 'Ouvrir le journal', click: () => { try { shell.openPath(path.join(app.getPath('logs'), 'journal.txt')); } catch (e) {} } },
      { label: 'Outils de développement', accelerator: isMac ? 'Alt+Cmd+I' : 'Ctrl+Shift+I', click: () => { if (win) win.webContents.toggleDevTools(); } }] },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(t));
}

// 1.2.2 : « Écran Hall » (avec accent) se retrouvait dans l'identifiant du navigateur (User-Agent) ; avec Electron 44.5.1
// (moteur repris de Lanterne sur le Mac d'antoine), toute lecture d'un fichier de l'appli depuis une page échouait alors
// (« Failed to fetch », polices.js non chargé) : identifiant gardé en caractères simples
function uaSimple() {
  try { app.userAgentFallback = app.userAgentFallback.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\x20-\x7e]/g, ''); } catch (e) {}
}
uaSimple();
app.whenReady().then(() => {
  uaSimple();
  loadPrefs();
  lireConv();
  setupProtocol();
  buildMenu();
  createWindow();
  demarrerUdp();
  demarrerWeb();
  setInterval(() => { chercher(); publierEcrans(); }, 10000);
  sonderQeedji(); setInterval(sonderQeedji, 5000);
  setInterval(publierEcrans, 2000);
  setTimeout(nettoyerAnciens, 10000);
  setTimeout(() => { if (prefs.majAuto !== false) majVerifier(false); }, 4000);
  setInterval(() => { if (prefs.majAuto !== false) majVerifier(false); }, 6 * 3600e3 + 60e3);
});
app.on('window-all-closed', () => app.quit());
app.on('before-quit', () => { try { if (udp) udp.close(); } catch (e) {} try { if (web) web.close(); } catch (e) {} });
