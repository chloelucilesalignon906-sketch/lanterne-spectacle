@echo off
rem Banque : desinstallation (la banque de fichiers n est pas touchee).
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup\installer-banque.ps1" -Uninstall
