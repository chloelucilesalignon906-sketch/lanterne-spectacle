@echo off
rem Banque : installation sous Windows (double-clic). Aucun droit administrateur requis.
title Installation de Banque
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup\installer-banque.ps1" %*
if errorlevel 1 (
  echo.
  echo L installation ne s est pas terminee. Le journal est dans %LOCALAPPDATA%\Banque\installation-banque.log
  pause
)
